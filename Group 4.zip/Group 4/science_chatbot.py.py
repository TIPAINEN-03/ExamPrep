# science_chatbot.py
import os
import io
import json
import logging
from typing import List, Dict, Any, Optional
import numpy as np
from datetime import datetime

# Document processing
import PyPDF2
from pdf2image import convert_from_path
import pytesseract
from bs4 import BeautifulSoup
import ebooklib
from ebooklib import epub

# ML and embeddings
import torch
from transformers import AutoTokenizer, AutoModel, pipeline
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings

# Web framework
from flask import Flask, request, jsonify, render_template, send_file
import base64
import threading

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DocumentProcessor:
    def __init__(self):
        self.ocr_processor = None
        
    def load_pdf(self, file_content: bytes, filename: str) -> List[Dict[str, Any]]:
        """Extract text from PDF with OCR fallback"""
        documents = []
        
        try:
            # Try direct text extraction first
            pdf_file = io.BytesIO(file_content)
            pdf_reader = PyPDF2.PdfReader(pdf_file)
                
            for page_num, page in enumerate(pdf_reader.pages):
                text = page.extract_text()
                    
                # If text extraction fails, use OCR
                if not text or len(text.strip()) < 50:
                    text = self._ocr_page(file_content, page_num)
                    
                if text and len(text.strip()) > 10:
                    documents.append({
                        'content': text,
                        'metadata': {
                            'source': filename,
                            'page': page_num + 1,
                            'type': 'pdf',
                            'processed_at': datetime.now().isoformat()
                        }
                    })
                        
        except Exception as e:
            logger.error(f"Error processing PDF {filename}: {e}")
            
        return documents
    
    def _ocr_page(self, file_content: bytes, page_num: int) -> str:
        """OCR for scanned PDF pages"""
        try:
            images = convert_from_bytes(file_content, first_page=page_num+1, last_page=page_num+1)
            if images:
                return pytesseract.image_to_string(images[0])
        except Exception as e:
            logger.error(f"OCR failed for page {page_num}: {e}")
        return ""
    
    def load_text(self, file_content: bytes, filename: str) -> List[Dict[str, Any]]:
        """Extract text from plain text files"""
        try:
            text = file_content.decode('utf-8')
            return [{
                'content': text,
                'metadata': {
                    'source': filename,
                    'type': 'text',
                    'processed_at': datetime.now().isoformat()
                }
            }]
        except Exception as e:
            logger.error(f"Error processing text file {filename}: {e}")
            return []

class ScienceChunker:
    def __init__(self, chunk_size: int = 512, chunk_overlap: int = 50):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        
    def smart_chunking(self, documents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Split documents into meaningful chunks for science content"""
        chunks = []
        
        for doc in documents:
            content = doc['content']
            metadata = doc['metadata']
            
            # Split by paragraphs first
            paragraphs = [p.strip() for p in content.split('\n\n') if p.strip()]
            
            for para in paragraphs:
                if len(para) <= self.chunk_size:
                    # Paragraph is small enough to be a single chunk
                    chunks.append({
                        'content': para,
                        'metadata': metadata.copy()
                    })
                else:
                    # Split paragraph using sliding window
                    para_chunks = self._sliding_window_chunk(para, metadata)
                    chunks.extend(para_chunks)
                    
        return chunks
    
    def _sliding_window_chunk(self, text: str, metadata: Dict) -> List[Dict[str, Any]]:
        """Split long text using sliding window approach"""
        chunks = []
        start = 0
        text_length = len(text)
        
        while start < text_length:
            end = start + self.chunk_size
            
            # Try to break at sentence boundaries
            if end < text_length:
                # Look for sentence endings near the chunk end
                for break_pos in range(end, start + self.chunk_size - 100, -1):
                    if break_pos < text_length and text[break_pos] in ['.', '!', '?', '\n']:
                        end = break_pos + 1
                        break
            
            chunk_text = text[start:end].strip()
            if chunk_text:
                chunk_metadata = metadata.copy()
                chunk_metadata['chunk_id'] = f"{start}-{end}"
                chunks.append({
                    'content': chunk_text,
                    'metadata': chunk_metadata
                })
            
            start = end - self.chunk_overlap
            
        return chunks

class VectorStore:
    def __init__(self, persist_directory: str = "./chroma_db"):
        self.client = chromadb.PersistentClient(path=persist_directory)
        self.collection = self.client.get_or_create_collection(
            name="science_documents",
            metadata={"description": "Science educational content vector store"}
        )
        self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
        
    def add_documents(self, chunks: List[Dict[str, Any]]):
        """Add document chunks to vector database"""
        documents = []
        metadatas = []
        ids = []
        
        for i, chunk in enumerate(chunks):
            documents.append(chunk['content'])
            metadatas.append(chunk['metadata'])
            ids.append(f"chunk_{i}_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        
        # Generate embeddings
        embeddings = self.embedding_model.encode(documents).tolist()
        
        # Add to collection
        self.collection.add(
            embeddings=embeddings,
            documents=documents,
            metadatas=metadatas,
            ids=ids
        )
        
        logger.info(f"Added {len(documents)} chunks to vector store")
    
    def search(self, query: str, n_results: int = 5, filter_metadata: Optional[Dict] = None) -> List[Dict[str, Any]]:
        """Search for similar documents"""
        query_embedding = self.embedding_model.encode([query]).tolist()
        
        results = self.collection.query(
            query_embeddings=query_embedding,
            n_results=n_results,
            where=filter_metadata
        )
        
        formatted_results = []
        for i in range(len(results['documents'][0])):
            formatted_results.append({
                'content': results['documents'][0][i],
                'metadata': results['metadatas'][0][i],
                'distance': results['distances'][0][i] if results['distances'] else None
            })
            
        return formatted_results

class ScienceChatbot:
    def __init__(self, vector_store: VectorStore):
        self.vector_store = vector_store
        self.llm = self._initialize_llm()
        
        # Science-focused prompt templates
        self.prompt_templates = {
            'standard': """You are a helpful science tutor. Answer the question based on the provided context.

Context:
{context}

Question: {question}

Instructions:
1. Provide a clear, step-by-step explanation
2. Use appropriate scientific terminology
3. Cite relevant principles or laws when applicable
4. If the context doesn't contain enough information, say so
5. Keep explanations educational and engaging

Answer:""",

            'step_by_step': """You are a detailed science tutor. Break down the solution into clear steps.

Context:
{context}

Question: {question}

Provide your answer in this exact format:
Step 1: [First step with explanation]
Step 2: [Second step with explanation]
...
Final Answer: [Concise final answer]

Remember to:
- Show all reasoning steps
- Explain scientific concepts used
- Connect steps logically"""
        }
    
    def _initialize_llm(self):
        """Initialize the language model"""
        try:
            # Try to use a local model first
            return pipeline(
                "text-generation",
                model="microsoft/DialoGPT-medium",
                torch_dtype=torch.float16,
                device_map="auto"
            )
        except:
            logger.warning("No LLM available, using simple retrieval mode")
            return None
    
    def generate_answer(self, question: str, show_steps: bool = False) -> Dict[str, Any]:
        """Generate answer using RAG"""
        
        # Retrieve relevant context
        context_docs = self.vector_store.search(question, n_results=3)
        
        # Prepare context
        context = "\n\n".join([doc['content'] for doc in context_docs])
        
        # Select prompt template
        template_type = 'step_by_step' if show_steps else 'standard'
        prompt = self.prompt_templates[template_type].format(
            context=context,
            question=question
        )
        
        # Generate response
        if self.llm:
            response = self._call_local_llm(prompt)
        else:
            response = self._fallback_response(question, context_docs)
        
        return {
            'answer': response,
            'sources': context_docs,
            'context_used': len(context_docs) > 0
        }
    
    def _call_local_llm(self, prompt: str) -> str:
        """Call local LLM"""
        try:
            response = self.llm(
                prompt,
                max_length=512,
                num_return_sequences=1,
                temperature=0.3,
                do_sample=True
            )
            return response[0]['generated_text']
        except Exception as e:
            logger.error(f"Local LLM error: {e}")
            return self._fallback_response(prompt, [])
    
    def _fallback_response(self, question: str, context_docs: List[Dict]) -> str:
        """Fallback response when no LLM is available"""
        if context_docs:
            return f"I found some relevant information for your question '{question}'. The most relevant content mentions: {context_docs[0]['content'][:200]}..."
        else:
            return f"I don't have enough specific information to answer '{question}'. Please try rephrasing or ask about a different science topic."

class AnswerValidator:
    """Simple validator for scientific answers"""
    
    @staticmethod
    def check_numeric_accuracy(answer: str, sources: List[Dict]) -> bool:
        """Basic check for numeric consistency"""
        import re
        answer_numbers = set(re.findall(r'\b\d+\.?\d*\b', answer))
        source_numbers = set()
        
        for source in sources:
            source_numbers.update(re.findall(r'\b\d+\.?\d*\b', source['content']))
        
        if answer_numbers:
            matching_numbers = answer_numbers.intersection(source_numbers)
            return len(matching_numbers) > 0 or len(answer_numbers - source_numbers) == 0
        
        return True

# Flask Application
app = Flask(__name__)
app.secret_key = 'science_chatbot_secret_key'

# Global instances
vector_store = VectorStore()
document_processor = DocumentProcessor()
chunker = ScienceChunker()
chatbot = ScienceChatbot(vector_store)

@app.route('/')
def home():
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Science Tutor Chatbot</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                padding: 20px;
            }

            .container {
                max-width: 1200px;
                margin: 0 auto;
                background: white;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                overflow: hidden;
            }

            .header {
                background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
                color: white;
                padding: 30px;
                text-align: center;
            }

            .header h1 {
                font-size: 2.5em;
                margin-bottom: 10px;
            }

            .header p {
                font-size: 1.2em;
                opacity: 0.9;
            }

            .content {
                display: flex;
                min-height: 600px;
            }

            .sidebar {
                width: 300px;
                background: #f8f9fa;
                padding: 20px;
                border-right: 1px solid #e9ecef;
            }

            .main-content {
                flex: 1;
                display: flex;
                flex-direction: column;
            }

            .upload-section {
                background: white;
                padding: 20px;
                border-radius: 10px;
                margin-bottom: 20px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }

            .upload-section h3 {
                color: #2c3e50;
                margin-bottom: 15px;
            }

            .file-upload {
                border: 2px dashed #3498db;
                border-radius: 10px;
                padding: 20px;
                text-align: center;
                margin-bottom: 15px;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .file-upload:hover {
                background: #f8f9fa;
                border-color: #2980b9;
            }

            .file-upload input {
                display: none;
            }

            .upload-btn {
                background: #3498db;
                color: white;
                border: none;
                padding: 12px 24px;
                border-radius: 25px;
                cursor: pointer;
                font-size: 16px;
                transition: all 0.3s ease;
                width: 100%;
            }

            .upload-btn:hover {
                background: #2980b9;
                transform: translateY(-2px);
            }

            .settings-section {
                background: white;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }

            .setting-option {
                margin-bottom: 15px;
            }

            .setting-option label {
                display: flex;
                align-items: center;
                cursor: pointer;
            }

            .setting-option input[type="checkbox"] {
                margin-right: 10px;
                transform: scale(1.2);
            }

            .chat-container {
                flex: 1;
                display: flex;
                flex-direction: column;
                padding: 20px;
            }

            .chat-messages {
                flex: 1;
                overflow-y: auto;
                padding: 20px;
                background: #f8f9fa;
                border-radius: 15px;
                margin-bottom: 20px;
                max-height: 400px;
            }

            .message {
                margin-bottom: 20px;
                padding: 15px;
                border-radius: 15px;
                max-width: 80%;
                animation: fadeIn 0.3s ease;
            }

            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(10px); }
                to { opacity: 1; transform: translateY(0); }
            }

            .user-message {
                background: #3498db;
                color: white;
                margin-left: auto;
                border-bottom-right-radius: 5px;
            }

            .bot-message {
                background: white;
                color: #2c3e50;
                border: 1px solid #e9ecef;
                margin-right: auto;
                border-bottom-left-radius: 5px;
            }

            .message-content {
                margin-bottom: 10px;
            }

            .sources {
                background: #e8f4fd;
                padding: 10px;
                border-radius: 8px;
                margin-top: 10px;
                font-size: 0.9em;
            }

            .source-item {
                margin-bottom: 5px;
                padding: 5px;
                background: white;
                border-radius: 5px;
                border-left: 3px solid #3498db;
            }

            .chat-input-container {
                display: flex;
                gap: 10px;
                padding: 20px;
                background: white;
                border-top: 1px solid #e9ecef;
            }

            .chat-input {
                flex: 1;
                padding: 15px;
                border: 2px solid #e9ecef;
                border-radius: 25px;
                font-size: 16px;
                outline: none;
                transition: border-color 0.3s ease;
            }

            .chat-input:focus {
                border-color: #3498db;
            }

            .send-btn {
                background: #27ae60;
                color: white;
                border: none;
                padding: 15px 25px;
                border-radius: 25px;
                cursor: pointer;
                font-size: 16px;
                transition: all 0.3s ease;
            }

            .send-btn:hover {
                background: #219a52;
                transform: translateY(-2px);
            }

            .status {
                padding: 10px;
                text-align: center;
                background: #fff3cd;
                color: #856404;
                border-radius: 5px;
                margin-bottom: 10px;
                display: none;
            }

            .challenge-mode {
                background: white;
                padding: 20px;
                border-radius: 10px;
                margin-top: 20px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }

            .challenge-btn {
                background: #e74c3c;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 20px;
                cursor: pointer;
                margin: 5px;
                transition: all 0.3s ease;
            }

            .challenge-btn:hover {
                background: #c0392b;
                transform: translateY(-2px);
            }

            @media (max-width: 768px) {
                .content {
                    flex-direction: column;
                }
                
                .sidebar {
                    width: 100%;
                    border-right: none;
                    border-bottom: 1px solid #e9ecef;
                }
                
                .message {
                    max-width: 90%;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔬 Science Tutor Chatbot</h1>
                <p>Your personal AI science tutor with RAG capabilities</p>
            </div>
            
            <div class="content">
                <div class="sidebar">
                    <div class="upload-section">
                        <h3>📚 Upload Materials</h3>
                        <div class="file-upload" onclick="document.getElementById('file-input').click()">
                            <p>📁 Click to upload PDF or Text files</p>
                            <input type="file" id="file-input" accept=".pdf,.txt" multiple>
                        </div>
                        <button class="upload-btn" onclick="uploadFiles()">Process Documents</button>
                    </div>
                    
                    <div class="settings-section">
                        <h3>⚙️ Settings</h3>
                        <div class="setting-option">
                            <label>
                                <input type="checkbox" id="show-steps" checked>
                                Show Step-by-Step Solutions
                            </label>
                        </div>
                        <div class="setting-option">
                            <label>
                                <input type="checkbox" id="challenge-mode">
                                Challenge Mode (Quiz)
                            </label>
                        </div>
                    </div>
                    
                    <div class="challenge-mode" id="challenge-section" style="display: none;">
                        <h3>🧠 Challenge Questions</h3>
                        <button class="challenge-btn" onclick="askQuestion('Explain Newton\\'s Third Law of Motion with an example.')">Physics</button>
                        <button class="challenge-btn" onclick="askQuestion('What is the difference between covalent and ionic bonds?')">Chemistry</button>
                        <button class="challenge-btn" onclick="askQuestion('Describe the process of photosynthesis.')">Biology</button>
                        <button class="challenge-btn" onclick="askQuestion('What causes the seasons on Earth?')">Astronomy</button>
                    </div>
                </div>
                
                <div class="main-content">
                    <div class="chat-container">
                        <div class="status" id="status"></div>
                        <div class="chat-messages" id="chat-messages">
                            <div class="message bot-message">
                                <div class="message-content">
                                    Hello! I'm your Science Tutor Chatbot. I can help you with physics, chemistry, biology, and astronomy questions. 
                                    Upload your study materials or ask me anything about science!
                                </div>
                            </div>
                        </div>
                        
                        <div class="chat-input-container">
                            <input type="text" class="chat-input" id="user-input" 
                                   placeholder="Ask your science question..." 
                                   onkeypress="handleKeyPress(event)">
                            <button class="send-btn" onclick="sendMessage()">Send</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            let uploadedFiles = [];
            
            // File upload handling
            document.getElementById('file-input').addEventListener('change', function(e) {
                uploadedFiles = Array.from(e.target.files);
                const status = document.getElementById('status');
                status.style.display = 'block';
                status.textContent = `Selected ${uploadedFiles.length} file(s) for upload`;
            });
            
            // Challenge mode toggle
            document.getElementById('challenge-mode').addEventListener('change', function(e) {
                document.getElementById('challenge-section').style.display = 
                    e.target.checked ? 'block' : 'none';
            });
            
            function uploadFiles() {
                if (uploadedFiles.length === 0) {
                    alert('Please select files first');
                    return;
                }
                
                const status = document.getElementById('status');
                status.style.display = 'block';
                status.textContent = 'Processing documents...';
                
                const formData = new FormData();
                uploadedFiles.forEach(file => {
                    formData.append('files', file);
                });
                
                fetch('/upload', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        status.textContent = `Successfully processed ${data.chunks_processed} document chunks!`;
                        status.style.background = '#d4edda';
                        status.style.color = '#155724';
                    } else {
                        status.textContent = 'Error processing documents: ' + data.error;
                        status.style.background = '#f8d7da';
                        status.style.color = '#721c24';
                    }
                })
                .catch(error => {
                    status.textContent = 'Error uploading files: ' + error;
                    status.style.background = '#f8d7da';
                    status.style.color = '#721c24';
                });
            }
            
            function sendMessage() {
                const input = document.getElementById('user-input');
                const message = input.value.trim();
                
                if (message === '') return;
                
                addMessage(message, 'user');
                input.value = '';
                
                // Show typing indicator
                const typingIndicator = addMessage('Thinking...', 'bot');
                
                const showSteps = document.getElementById('show-steps').checked;
                
                fetch('/chat', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        message: message,
                        show_steps: showSteps
                    })
                })
                .then(response => response.json())
                .then(data => {
                    // Remove typing indicator
                    typingIndicator.remove();
                    
                    addMessage(data.answer, 'bot', data.sources);
                })
                .catch(error => {
                    typingIndicator.remove();
                    addMessage('Sorry, I encountered an error. Please try again.', 'bot');
                });
            }
            
            function askQuestion(question) {
                document.getElementById('user-input').value = question;
                sendMessage();
            }
            
            function handleKeyPress(event) {
                if (event.key === 'Enter') {
                    sendMessage();
                }
            }
            
            function addMessage(content, sender, sources = null) {
                const messagesContainer = document.getElementById('chat-messages');
                const messageDiv = document.createElement('div');
                messageDiv.className = `message ${sender}-message`;
                
                let messageHTML = `<div class="message-content">${content}</div>`;
                
                if (sources && sources.length > 0) {
                    messageHTML += '<div class="sources"><strong>Sources:</strong>';
                    sources.forEach(source => {
                        const sourceContent = source.content.length > 100 ? 
                            source.content.substring(0, 100) + '...' : source.content;
                        messageHTML += `<div class="source-item">${sourceContent}</div>`;
                    });
                    messageHTML += '</div>';
                }
                
                messageDiv.innerHTML = messageHTML;
                messagesContainer.appendChild(messageDiv);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
                
                return messageDiv;
            }
        </script>
    </body>
    </html>
    """

@app.route('/upload', methods=['POST'])
def upload_files():
    """Handle file uploads and processing"""
    try:
        if 'files' not in request.files:
            return jsonify({'success': False, 'error': 'No files provided'})
        
        files = request.files.getlist('files')
        all_chunks = []
        
        for file in files:
            if file.filename == '':
                continue
                
            file_content = file.read()
            filename = file.filename
            
            # Process based on file type
            if filename.lower().endswith('.pdf'):
                documents = document_processor.load_pdf(file_content, filename)
            else:
                # Assume text file
                documents = document_processor.load_text(file_content, filename)
            
            # Chunk documents
            chunks = chunker.smart_chunking(documents)
            all_chunks.extend(chunks)
        
        # Add to vector store
        if all_chunks:
            vector_store.add_documents(all_chunks)
            return jsonify({
                'success': True, 
                'chunks_processed': len(all_chunks),
                'message': f'Successfully processed {len(all_chunks)} document chunks'
            })
        else:
            return jsonify({'success': False, 'error': 'No content could be extracted'})
            
    except Exception as e:
        logger.error(f"Upload error: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/chat', methods=['POST'])
def chat():
    """Handle chat messages"""
    try:
        data = request.get_json()
        question = data.get('message', '')
        show_steps = data.get('show_steps', False)
        
        if not question:
            return jsonify({'error': 'No message provided'})
        
        # Generate response
        response_data = chatbot.generate_answer(question, show_steps=show_steps)
        
        return jsonify({
            'answer': response_data['answer'],
            'sources': response_data['sources'],
            'success': True
        })
        
    except Exception as e:
        logger.error(f"Chat error: {e}")
        return jsonify({'error': str(e), 'success': False})

@app.route('/clear', methods=['POST'])
def clear_chat():
    """Clear chat history"""
    # In a real implementation, you might want to clear session-specific chat history
    return jsonify({'success': True, 'message': 'Chat cleared'})

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs('./chroma_db', exist_ok=True)
    
    print("Starting Science Tutor Chatbot...")
    print("Access the application at: http://localhost:5000")
    
    app.run(debug=True, host='0.0.0.0', port=5000)