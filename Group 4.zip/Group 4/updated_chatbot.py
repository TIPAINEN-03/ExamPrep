# streamlit_waec_cbt_centered.py
from __future__ import annotations
import time, random, json, os, re
import streamlit as st
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any

# -------------------------
# Question model
# -------------------------
class Question:
    def __init__(self, subject: str, number: str, qtype: str, text: str,
                 options: Optional[List[str]], answer: str, explanation: str,
                 topic: Optional[str] = None):
        self.subject = subject
        self.number = number
        self.qtype = qtype
        self.text = text
        self.options = options
        self.answer = answer
        self.explanation = explanation
        self.topic = topic

# -------------------------
# Helpers
# -------------------------
def normalize_label(s: str) -> str:
    return s.strip().upper()[0] if s else ""

def compare_short(expected: str, user: str) -> bool:
    try:
        if re.fullmatch(r'[+-]?\d+(?:\.\d+)?', expected.strip()) and \
           re.fullmatch(r'[+-]?\d+(?:\.\d+)?', user.strip()):
            return abs(float(expected) - float(user)) <= 1e-6
    except:
        pass
    clean = lambda t: ''.join(ch for ch in t.lower() if ch.isalnum() or ch.isspace()).strip()
    return clean(expected) == clean(user)

# -------------------------
# Session Logger
# -------------------------
class SessionLogger:
    def __init__(self):
        self.entries: List[Dict[str,Any]] = []
        self.start = datetime.now(timezone.utc).isoformat()

    def add(self, q: Question, user: str, correct: bool, elapsed: float, timed_out: bool, allowed_time: int):
        self.entries.append({
            "subject": q.subject,
            "topic": q.topic or "General",
            "number": q.number,
            "qtype": q.qtype,
            "question": q.text,
            "answer_expected": q.answer,
            "user_input": user,
            "correct": correct,
            "elapsed": elapsed,
            "timed_out": timed_out,
            "allowed_time": allowed_time,
        })

    def save(self, preferred_dir: Optional[str] = None) -> str:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        candidates = []
        if preferred_dir:
            candidates.append(preferred_dir)
        candidates.extend(["/mnt/data", os.getcwd()])
        for base in candidates:
            try:
                os.makedirs(base, exist_ok=True)
                out = os.path.join(base, f"waec_session_{ts}.json")
                with open(out, "w", encoding="utf-8") as f:
                    json.dump({"started": self.start, "entries": self.entries}, f, ensure_ascii=False, indent=2)
                return out
            except Exception:
                continue
        out = f"waec_session_{ts}.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump({"started": self.start, "entries": self.entries}, f, ensure_ascii=False, indent=2)
        return os.path.abspath(out)

# -------------------------
# Real WAEC-style questions (sample, expandable to 50 per subject)
# -------------------------
REAL_QUESTIONS = {}

REAL_QUESTIONS["mathematics"] = [
Question("Mathematics","1","mcq","What is 25 + 36?",["A. 50","B. 61","C. 60","D. 59"],"B","25 + 36 = 61","Number & Numeration"),
Question("Mathematics","2","short","Solve 2x + 5 = 15 for x.",None,"5","2x + 5 = 15 → x = 5","Algebraic Processes"),
Question("Mathematics","3","mcq","Area of a rectangle with length 8cm and breadth 5cm?",["A. 40","B. 13","C. 20","D. 45"],"A","Area = 8 × 5 = 40","Mensuration"),
Question("Mathematics","4","mcq","Simplify: 3(2x + 5)",["A. 6x + 15","B. 6x + 8","C. 5x + 3","D. 2x + 15"],"A","Distribute 3 → 3×2x + 3×5 = 6x + 15","Algebraic Processes"),
Question("Mathematics","5","short","Solve for y: 5y - 10 = 0",None,"2","5y - 10 = 0 → 5y = 10 → y = 2","Algebraic Processes"),
Question("Mathematics","6","mcq","The value of √81 is?",["A. 7","B. 8","C. 9","D. 10"],"C","√81 = 9","Number & Numeration"),
Question("Mathematics","7","short","Factorize x^2 - 9.",None,"(x - 3)(x + 3)","x^2 - 9 = difference of squares","Algebraic Processes"),
Question("Mathematics","8","mcq","The perimeter of a square of side 7cm is?",["A. 21cm","B. 28cm","C. 49cm","D. 14cm"],"B","Perimeter = 4 × 7 = 28cm","Mensuration"),
Question("Mathematics","9","short","If f(x) = 2x + 3, find f(4).",None,"11","f(4) = 2×4 + 3 = 11","Graphs & Functions"),
Question("Mathematics","10","mcq","What is 15% of 200?",["A. 20","B. 25","C. 30","D. 35"],"C","15% of 200 = 0.15 × 200 = 30","Business Mathematics"),
Question("Mathematics","11","mcq","The sum of angles in a triangle is?",["A. 90°","B. 180°","C. 360°","D. 270°"],"B","Sum of angles in triangle = 180°","Plane Geometry"),
Question("Mathematics","12","short","Solve: 3x - 7 = 11",None,"6","3x - 7 = 11 → 3x = 18 → x = 6","Algebraic Processes"),
Question("Mathematics","13","mcq","The next number in sequence 2,4,8,16,...?",["A. 20","B. 32","C. 24","D. 30"],"B","Sequence doubles each time → next = 16×2 = 32","Sequences & Series"),
Question("Mathematics","14","short","Find the HCF of 12 and 18.",None,"6","HCF of 12 and 18 = 6","Number & Numeration"),
Question("Mathematics","15","mcq","Square root of 144 is?",["A. 11","B. 12","C. 13","D. 14"],"B","√144 = 12","Number & Numeration"),
Question("Mathematics","16","short","Express 0.75 as a fraction.",None,"3/4","0.75 = 3/4","Number & Numeration"),
Question("Mathematics","17","mcq","Solve: 5(x - 2) = 15",["A. 5","B. 6","C. 7","D. 8"],"B","5(x-2)=15 → x-2=3 → x=5","Algebraic Processes"),
Question("Mathematics","18","short","Simplify: 7x + 3x",None,"10x","Combine like terms: 7x + 3x = 10x","Algebraic Processes"),
Question("Mathematics","19","mcq","The area of a circle with radius 7cm is?",["A. 154cm²","B. 49cm²","C. 44cm²","D. 100cm²"],"A","Area = πr² = 3.14×7² ≈ 154","Mensuration"),
Question("Mathematics","20","short","Convert 150° to radians.",None,"5π/6","Radians = degrees × π/180 → 150×π/180 = 5π/6","Trigonometry"),
]

REAL_QUESTIONS["mathematics"] += [
Question("Mathematics","21","mcq","If sin θ = 1/2, then θ = ?",["A. 30°","B. 45°","C. 60°","D. 90°"],"A","sin 30° = 1/2","Trigonometry"),
Question("Mathematics","22","short","Simplify: (x^3 * x^2).",None,"x^5","Add exponents when multiplying same base","Algebraic Processes"),
Question("Mathematics","23","mcq","The mean of 2,4,6,8,10 is?",["A. 5","B. 6","C. 7","D. 8"],"B","Mean = sum/number = 30/5 = 6","Statistics & Probability"),
Question("Mathematics","24","short","Factorize x^2 + 5x + 6.",None,"(x + 2)(x + 3)","Find factors of 6 that sum to 5","Algebraic Processes"),
Question("Mathematics","25","mcq","If f(x) = x^2, then f(3) = ?",["A. 6","B. 9","C. 3","D. 12"],"B","f(3) = 3^2 = 9","Graphs & Functions"),
Question("Mathematics","26","short","Write 0.625 as a fraction.",None,"5/8","0.625 = 5/8","Number & Numeration"),
Question("Mathematics","27","mcq","Simplify: 4(3x + 2) - 5x",["A. 7x + 8","B. 7x + 2","C. 12x - 5x + 8","D. 12x + 2"],"C","4(3x+2)-5x = 12x+8-5x = 7x + 8","Algebraic Processes"),
Question("Mathematics","28","short","Solve: x/3 + 5 = 8",None,"9","x/3 + 5 = 8 → x/3 = 3 → x = 9","Algebraic Processes"),
Question("Mathematics","29","mcq","The circumference of a circle with radius 7cm is?",["A. 44cm","B. 22cm","C. 14cm","D. 28cm"],"A","Circumference = 2πr = 2×3.14×7 ≈ 44cm","Mensuration"),
Question("Mathematics","30","short","Convert 45° to radians.",None,"π/4","Radians = degrees × π/180 → 45×π/180 = π/4","Trigonometry"),
Question("Mathematics","31","mcq","The next number in sequence 1, 4, 9, 16,...?",["A. 25","B. 20","C. 30","D. 36"],"A","Sequence of squares → next = 5^2 = 25","Sequences & Series"),
Question("Mathematics","32","short","Find LCM of 12 and 18.",None,"36","LCM of 12 and 18 = 36","Number & Numeration"),
Question("Mathematics","33","mcq","Value of 7^0 is?",["A. 0","B. 1","C. 7","D. Undefined"],"B","Any non-zero number to power 0 = 1","Number & Numeration"),
Question("Mathematics","34","short","Simplify: 5x - 3x + 7",None,"2x + 7","Combine like terms","Algebraic Processes"),
Question("Mathematics","35","mcq","If tan θ = 1, then θ = ?",["A. 30°","B. 45°","C. 60°","D. 90°"],"B","tan 45° = 1","Trigonometry"),
Question("Mathematics","36","short","Factorize x^2 - 5x + 6.",None,"(x-2)(x-3)","Find factors of 6 that sum to -5","Algebraic Processes"),
Question("Mathematics","37","mcq","Probability of getting a head in a coin toss?",["A. 1","B. 1/2","C. 1/4","D. 0"],"B","Coin has 2 sides → probability = 1/2","Statistics & Probability"),
Question("Mathematics","38","short","Evaluate: 3^2 + 4^2",None,"25","3^2 + 4^2 = 9 + 16 = 25","Number & Numeration"),
Question("Mathematics","39","mcq","Solve: 2x + 7 = 15",["A. 2","B. 3","C. 4","D. 5"],"C","2x+7=15 → 2x=8 → x=4","Algebraic Processes"),
Question("Mathematics","40","short","Simplify: (x^4)/(x^2)",None,"x^2","Subtract exponents: x^(4-2)=x^2","Algebraic Processes"),
Question("Mathematics","41","mcq","The sum of angles in a quadrilateral is?",["A. 180°","B. 360°","C. 270°","D. 540°"],"B","Sum of angles in quadrilateral = 360°","Plane Geometry"),
Question("Mathematics","42","short","Convert 2/5 to percentage.",None,"40%","2/5 = 0.4 = 40%","Number & Numeration"),
Question("Mathematics","43","mcq","If f(x)=x+2, then f(5) = ?",["A. 7","B. 5","C. 10","D. 3"],"A","f(5)=5+2=7","Graphs & Functions"),
Question("Mathematics","44","short","Find HCF of 8 and 12.",None,"4","HCF = 4","Number & Numeration"),
Question("Mathematics","45","mcq","Value of 2^3 × 2^2 ?",["A. 4","B. 8","C. 16","D. 32"],"D","Add exponents: 2^(3+2)=32","Number & Numeration"),
Question("Mathematics","46","short","Solve 4x - 7 = 9",None,"4","4x -7 =9 → 4x=16 → x=4","Algebraic Processes"),
Question("Mathematics","47","mcq","A triangle has angles 50° and 60°, find the third angle.",["A. 70°","B. 80°","C. 90°","D. 60°"],"B","Sum of angles = 180° → third = 70°","Plane Geometry"),
Question("Mathematics","48","short","Simplify: 10x - 3x + 5",None,"7x + 5","Combine like terms","Algebraic Processes"),
Question("Mathematics","49","mcq","The square of 11 is?",["A. 121","B. 111","C. 112","D. 122"],"A","11^2=121","Number & Numeration"),
Question("Mathematics","50","short","Find x if x/2 = 6",None,"12","x/2=6 → x=12","Algebraic Processes"),
]


# --- Physics ---
REAL_QUESTIONS["physics"] = [
Question("Physics","1","mcq","A car moves with constant velocity. The net force on it is?",["A. Zero","B. Equal to its weight","C. Non-zero","D. Depends on friction"],"A","Constant velocity → net force = 0","Dynamics"),
Question("Physics","2","short","Define velocity.",None,"Rate of change of displacement","Velocity = displacement/time","Kinematics"),
Question("Physics","3","mcq","Unit of pressure in SI is?",["A. Pascal","B. Newton","C. Joule","D. Watt"],"A","Pressure = Force/Area → unit = N/m² = Pascal","Pressure & Fluids"),
Question("Physics","4","short","State Newton’s first law of motion.",None,"An object remains at rest or moves uniformly unless acted upon by a net force.","First law: Inertia law","Dynamics"),
Question("Physics","5","mcq","A freely falling body has acceleration?",["A. g","B. 0","C. Depends on mass","D. 9.8 N"],"A","Acceleration = g near Earth surface","Kinematics"),
Question("Physics","6","short","Define momentum.",None,"Product of mass and velocity","Momentum = mass × velocity","Momentum"),
Question("Physics","7","mcq","Unit of work in SI is?",["A. Joule","B. Newton","C. Watt","D. Pascal"],"A","Work = Force × displacement → unit = N·m = Joule","Work & Energy"),
Question("Physics","8","short","State Ohm’s law.",None,"V = IR","Voltage = Current × Resistance","Electricity"),
Question("Physics","9","mcq","If wavelength of light increases, its frequency?",["A. Decreases","B. Increases","C. Remains same","D. Doubles"],"A","c = λf → frequency decreases if wavelength increases","Waves"),
Question("Physics","10","short","Define power.",None,"Rate of doing work","Power = Work/time","Work & Energy"),
Question("Physics","11","mcq","The SI unit of energy is?",["A. Joule","B. Newton","C. Watt","D. Pascal"],"A","Energy = Work → unit = Joule","Work & Energy"),
Question("Physics","12","short","State Newton’s second law of motion.",None,"F = ma","Force = mass × acceleration","Dynamics"),
Question("Physics","13","mcq","Which of the following is a scalar quantity?",["A. Velocity","B. Force","C. Speed","D. Acceleration"],"C","Speed has magnitude only → scalar","Kinematics"),
Question("Physics","14","short","Define acceleration.",None,"Rate of change of velocity","a = Δv/Δt","Kinematics"),
Question("Physics","15","mcq","Pressure at the bottom of a liquid depends on?",["A. Depth, density, gravity","B. Mass","C. Volume","D. Temperature"],"A","P = ρgh","Pressure & Fluids"),
Question("Physics","16","short","State Newton’s third law of motion.",None,"Action = Reaction","Every action has equal and opposite reaction","Dynamics"),
Question("Physics","17","mcq","Which instrument measures electric current?",["A. Ammeter","B. Voltmeter","C. Galvanometer","D. Ohmmeter"],"A","Ammeter measures current","Electricity"),
Question("Physics","18","short","Define work done.",None,"Product of force and displacement in direction of force","Work = F × d × cosθ","Work & Energy"),
Question("Physics","19","mcq","The unit of electric charge is?",["A. Coulomb","B. Ampere","C. Volt","D. Ohm"],"A","Charge = current × time → unit = Coulomb","Electricity"),
Question("Physics","20","short","Define kinetic energy.",None,"Energy of a body due to motion","KE = 1/2 mv²","Work & Energy"),
Question("Physics","21","mcq","Unit of power in SI?",["A. Watt","B. Joule","C. Newton","D. Pascal"],"A","Power = Work/time → unit = Watt","Work & Energy"),
Question("Physics","22","short","State the principle of conservation of momentum.",None,"Total momentum of isolated system remains constant","Momentum conserved in absence of external force","Momentum"),
Question("Physics","23","mcq","Unit of frequency?",["A. Hertz","B. Joule","C. Newton","D. Pascal"],"A","Frequency = cycles per second → Hertz","Waves"),
Question("Physics","24","short","Define gravitational potential energy.",None,"Energy possessed due to height","GPE = mgh","Work & Energy"),
Question("Physics","25","mcq","Speed of sound in air is approximately?",["A. 340 m/s","B. 300 m/s","C. 150 m/s","D. 1000 m/s"],"A","Speed of sound in air ≈ 340 m/s at 20°C","Waves"),
Question("Physics","26","short","State Ohm’s law formula.",None,"V = IR","Voltage = Current × Resistance","Electricity"),
Question("Physics","27","mcq","A projectile is fired horizontally. Its vertical acceleration is?",["A. g","B. 0","C. Horizontal speed","D. Depends on mass"],"A","Vertical motion under gravity → a = g","Kinematics"),
Question("Physics","28","short","Define density.",None,"Mass per unit volume","ρ = m/V","Units & Measurements"),
Question("Physics","29","mcq","A concave mirror forms real image when object is placed?",["A. Beyond F","B. At F","C. Between F and pole","D. At infinity"],"A","Real image forms beyond focus","Waves"),
Question("Physics","30","short","Define simple harmonic motion.",None,"Oscillatory motion about mean position","Displacement varies sinusoidally","Waves"),
Question("Physics","31","mcq","Unit of magnetic flux?",["A. Weber","B. Tesla","C. Ampere","D. Coulomb"],"A","SI unit of magnetic flux = Weber","Magnetism"),
Question("Physics","32","short","Define impulse.",None,"Change in momentum","Impulse = Δp = F Δt","Momentum"),
Question("Physics","33","mcq","Which is scalar quantity?",["A. Mass","B. Force","C. Velocity","D. Acceleration"],"A","Mass has magnitude only → scalar","Kinematics"),
Question("Physics","34","short","State law of reflection.",None,"Angle of incidence = angle of reflection","Reflection: θi=θr","Waves"),
Question("Physics","35","mcq","The unit of work is?",["A. Joule","B. Watt","C. Newton","D. Pascal"],"A","Work = Force × displacement → Joule","Work & Energy"),
Question("Physics","36","short","Define amplitude of wave.",None,"Maximum displacement from mean position","Amplitude = max displacement","Waves"),
Question("Physics","37","mcq","The acceleration due to gravity on Earth?",["A. 9.8 m/s²","B. 10 m/s²","C. 9 m/s²","D. 8 m/s²"],"A","g ≈ 9.8 m/s² near Earth's surface","Kinematics"),
Question("Physics","38","short","Define Ohm.","None","Resistance = Voltage/Current","R = V/I","Electricity"),
Question("Physics","39","mcq","Unit of electric potential?",["A. Volt","B. Ampere","C. Ohm","D. Joule"],"A","Voltage unit = Volt","Electricity"),
Question("Physics","40","short","Define moment of force.","None","Moment = Force × perpendicular distance","Moment = F × d","Dynamics"),
Question("Physics","41","mcq","What is the momentum of a 2 kg object moving at 3 m/s?",["A. 6 kg·m/s","B. 5 kg·m/s","C. 2 kg·m/s","D. 3 kg·m/s"],"A","p = mv = 2*3 = 6","Momentum"),
Question("Physics","42","short","State law of inertia.","None","A body remains at rest or uniform unless acted on","Newton's first law","Dynamics"),
Question("Physics","43","mcq","Which of these is a vector quantity?",["A. Velocity","B. Speed","C. Mass","D. Energy"],"A","Velocity has magnitude & direction → vector","Kinematics"),
Question("Physics","44","short","Define efficiency of a machine.",None,"Output work/Input work × 100%","Efficiency formula","Work & Energy"),
Question("Physics","45","mcq","A body weighs 100 N on Earth. Its mass is?",["A. 10 kg","B. 100 kg","C. 50 kg","D. 25 kg"],"A","Weight = mg → m = W/g = 100/10 ≈10 kg","Units & Measurements"),
Question("Physics","46","short","Define gravitational field strength.",None,"Force per unit mass","g = F/m","Units & Measurements"),
Question("Physics","47","mcq","A body in free fall has what kind of acceleration?",["A. Constant downward","B. Zero","C. Upward","D. Varies"],"A","Acceleration = g downward","Kinematics"),
Question("Physics","48","short","Define impulse-momentum theorem.",None,"Impulse = change in momentum","FΔt = Δp","Momentum"),
Question("Physics","49","mcq","Unit of frequency?",["A. Hertz","B. Watt","C. Newton","D. Joule"],"A","Frequency unit = Hertz","Waves"),
Question("Physics","50","short","State Archimedes' principle.",None,"Upthrust on a body = weight of fluid displaced","Archimedes’ principle","Pressure & Fluids"),
]


# --- Chemistry ---
REAL_QUESTIONS["chemistry"] = [
Question("Chemistry","1","mcq","The atomic number of oxygen is?",["A. 6","B. 7","C. 8","D. 16"],"C","Atomic number = number of protons = 8","Atomic structure"),
Question("Chemistry","2","short","Define isotope.",None,"Atoms of same element with same protons but different neutrons","Isotopes have same atomic number, different mass","Atomic structure"),
Question("Chemistry","3","mcq","H2O is an example of?",["A. Element","B. Compound","C. Mixture","D. Alloy"],"B","H2O = compound of H & O","Chemical bonding"),
Question("Chemistry","4","short","State law of conservation of mass.",None,"Mass cannot be created or destroyed in a chemical reaction","Total mass of reactants = total mass of products","Stoichiometry"),
Question("Chemistry","5","mcq","NaCl is classified as?",["A. Ionic","B. Covalent","C. Metallic","D. Hydrogen bond"],"A","Na+Cl- → ionic bond","Chemical bonding"),
Question("Chemistry","6","short","Define mole.",None,"Amount of substance containing 6.022×10^23 particles","Avogadro's number definition","Moles & Calculations"),
Question("Chemistry","7","mcq","pH of neutral solution?",["A. 0","B. 7","C. 14","D. 1"],"B","Neutral solution pH =7","Acids & Bases"),
Question("Chemistry","8","short","Write formula for sulfuric acid.",None,"H2SO4","Sulfuric acid formula","Acids & Bases"),
Question("Chemistry","9","mcq","Atomic mass of carbon-12 is?",["A. 12","B. 14","C. 6","D. 1"],"A","By definition, carbon-12 mass = 12 u","Atomic structure"),
Question("Chemistry","10","short","Define covalent bond.",None,"Sharing of electron pairs between atoms","Covalent bond = electron sharing","Chemical bonding"),
Question("Chemistry","11","mcq","Which is a diatomic molecule?",["A. N2","B. O","C. H","D. C"],"A","N2 consists of two atoms → diatomic","Molecular structure"),
Question("Chemistry","12","short","Define oxidation.",None,"Loss of electrons","Oxidation = loss of electrons","Chemical reactions"),
Question("Chemistry","13","mcq","Which is a base?",["A. NaOH","B. HCl","C. H2SO4","D. CO2"],"A","NaOH accepts H+ → base","Acids & Bases"),
Question("Chemistry","14","short","Define reduction.",None,"Gain of electrons","Reduction = gain of electrons","Chemical reactions"),
Question("Chemistry","15","mcq","Mol of water in 18g H2O?",["A. 1","B. 2","C. 0.5","D. 3"],"A","Molar mass H2O=18 → 18/18=1 mol","Moles & Calculations"),
Question("Chemistry","16","short","State periodic law.",None,"Properties of elements vary periodically with atomic number","Periodic table pattern","Periodic table"),
Question("Chemistry","17","mcq","Number of protons in Na?",["A. 11","B. 23","C. 12","D. 22"],"A","Atomic number = number of protons = 11","Atomic structure"),
Question("Chemistry","18","short","Define molar mass.",None,"Mass of one mole of substance","Molar mass in g/mol","Moles & Calculations"),
Question("Chemistry","19","mcq","Which is an acid?",["A. HCl","B. NaOH","C. KOH","D. NH3"],"A","HCl donates H+ → acid","Acids & Bases"),
Question("Chemistry","20","short","Write formula for methane.",None,"CH4","Methane = CH4","Organic basics"),
Question("Chemistry","21","mcq","Atomic number of nitrogen?",["A. 6","B. 7","C. 8","D. 14"],"B","Nitrogen has 7 protons → atomic number 7","Atomic structure"),
Question("Chemistry","22","short","Define ionic bond.",None,"Transfer of electrons from metal to non-metal","Ionic bond = electron transfer","Chemical bonding"),
Question("Chemistry","23","mcq","Which is a covalent compound?",["A. H2O","B. NaCl","C. KBr","D. MgO"],"A","H2O has shared electrons → covalent","Chemical bonding"),
Question("Chemistry","24","short","Define empirical formula.",None,"Simplest ratio of atoms in compound","Empirical formula = simplest ratio","Chemical formulas"),
Question("Chemistry","25","mcq","Which has highest electronegativity?",["A. F","B. O","C. N","D. C"],"A","Fluorine most electronegative","Chemical bonding"),
Question("Chemistry","26","short","Define mole concept.","None","Amount of substance containing 6.022×10^23 particles","Mole = Avogadro's number","Moles & Calculations"),
Question("Chemistry","27","mcq","Which is a metallic element?",["A. Fe","B. H","C. O","D. Cl"],"A","Fe is metallic","Periodic table"),
Question("Chemistry","28","short","Define stoichiometry.",None,"Calculation of reactants/products in reaction","Stoichiometry = quantitative analysis","Stoichiometry"),
Question("Chemistry","29","mcq","pH of strong acid?",["A. <7","B. 7","C. >7","D. 14"],"A","Strong acid → pH<7","Acids & Bases"),
Question("Chemistry","30","short","Define electron configuration.",None,"Distribution of electrons in orbitals","Electron arrangement in shells","Atomic structure"),
Question("Chemistry","31","mcq","NaCl solution conducts electricity because?",["A. Ions","B. Molecules","C. Atoms","D. Electrons"],"A","Dissolved ions carry current","Chemical bonding"),
Question("Chemistry","32","short","Define molarity.",None,"Moles of solute per liter of solution","Molarity = moles/L","Moles & Calculations"),
Question("Chemistry","33","mcq","Which is a noble gas?",["A. He","B. O","C. N","D. H"],"A","He is inert → noble gas","Periodic table"),
Question("Chemistry","34","short","Write formula for ethane.",None,"C2H6","Ethane = C2H6","Organic basics"),
Question("Chemistry","35","mcq","Which is an alkali?",["A. NaOH","B. HCl","C. H2SO4","D. CO2"],"A","NaOH → base/alkali","Acids & Bases"),
Question("Chemistry","36","short","Define relative atomic mass.",None,"Average mass of atoms compared to 1/12 C12","Relative atomic mass = Ar","Atomic structure"),
Question("Chemistry","37","mcq","Which is soluble in water?",["A. NaCl","B. AgCl","C. PbS","D. CuO"],"A","NaCl is soluble in water","Chemical bonding"),
Question("Chemistry","38","short","Define oxidation number.",None,"Charge an atom appears to have in compound","Oxidation number = formal charge","Chemical reactions"),
Question("Chemistry","39","mcq","Which is a reducing agent?",["A. H2","B. O2","C. Cl2","D. F2"],"A","H2 loses electrons → reducing agent","Chemical reactions"),
Question("Chemistry","40","short","Define hydrocarbon.","None","Compound of H & C only","Hydrocarbon = H + C","Organic basics"),
Question("Chemistry","41","mcq","Which is amphoteric?",["A. Al(OH)3","B. NaOH","C. HCl","D. KCl"],"A","Al(OH)3 acts as acid or base","Acids & Bases"),
Question("Chemistry","42","short","Define neutralization.",None,"Reaction of acid with base forming salt and water","Neutralization reaction","Acids & Bases"),
Question("Chemistry","43","mcq","Moles in 36 g of H2O?",["A. 2","B. 1","C. 0.5","D. 3"],"A","H2O molar mass=18 → 36/18=2 mol","Moles & Calculations"),
Question("Chemistry","44","short","Define valency.","None","Combining power of an element","Valency = combining capacity","Chemical bonding"),
Question("Chemistry","45","mcq","Which is covalent network solid?",["A. Diamond","B. NaCl","C. Hg","D. Al"],"A","Diamond → covalent network","Chemical bonding"),
Question("Chemistry","46","short","Define allotrope.",None,"Different forms of same element","Allotropes = different structural forms","Atomic structure"),
Question("Chemistry","47","mcq","Molecular formula of glucose?",["A. C6H12O6","B. C2H6O","C. C12H22O11","D. CH4"],"A","Glucose formula = C6H12O6","Organic basics"),
Question("Chemistry","48","short","Define empirical formula.",None,"Simplest ratio of atoms in compound","Empirical formula = simplest ratio","Chemical formulas"),
Question("Chemistry","49","mcq","Which of the following is a strong acid?",["A. HCl","B. CH3COOH","C. H2CO3","D. HF"],"A","HCl dissociates completely → strong acid","Acids & Bases"),
Question("Chemistry","50","short","State Avogadro’s hypothesis.",None,"Equal volumes of gases at same T and P contain equal number of molecules","Avogadro’s law","Moles & Calculations"),
]


# --- Further Mathematics ---
REAL_QUESTIONS["further mathematics"] = [
Question("Further Mathematics","1","mcq","Derivative of x^2?",["A. x","B. 2x","C. x^2","D. 2"],"B","d(x^2)/dx = 2x","Differentiation"),
Question("Further Mathematics","2","short","Integrate ∫x dx.",None,"(1/2)x^2 + C","Integral of x is (1/2)x^2 + C","Integration"),
Question("Further Mathematics","3","mcq","Value of determinant |1 2; 3 4|?",["A. -2","B. 2","C. 1","D. 3"],"A","Determinant = 1*4 - 2*3 = -2","Matrices"),
Question("Further Mathematics","4","short","Find the sum of first 10 natural numbers.",None,"55","Sum = n(n+1)/2 → 10*11/2=55","Series & Sequences"),
Question("Further Mathematics","5","mcq","Solve for x: 2x + 3 = 7",["A. 2","B. 3","C. 5","D. 7"],"A","2x + 3 =7 → 2x=4 → x=2","Algebraic Processes"),
Question("Further Mathematics","6","short","Differentiate sin x.",None,"cos x","d/dx(sin x) = cos x","Differentiation"),
Question("Further Mathematics","7","mcq","The inverse of matrix [[1,0],[0,1]] is?",["A. [[1,0],[0,1]]","B. [[0,1],[1,0]]","C. [[-1,0],[0,-1]]","D. [[1,1],[1,1]]"],"A","Identity matrix is its own inverse","Matrices"),
Question("Further Mathematics","8","short","Integrate ∫2x dx.",None,"x^2 + C","∫2x dx = x^2 + C","Integration"),
Question("Further Mathematics","9","mcq","If z = 3 + 4i, find |z|?",["A. 5","B. 7","C. 1","D. 25"],"A","|z| = √(3²+4²) = 5","Complex numbers"),
Question("Further Mathematics","10","short","Find 5th term of arithmetic sequence: 2,5,...",None,"14","nth term: a + (n-1)d → 2 + 4*3 = 14","Series & Sequences"),
Question("Further Mathematics","11","mcq","Solve x^2 - 9 = 0",["A. 3","B. -3","C. ±3","D. 0"],"C","x^2 -9=0 → x=±3","Algebraic Processes"),
Question("Further Mathematics","12","short","Differentiate cos x.",None,"-sin x","d/dx(cos x) = -sin x","Differentiation"),
Question("Further Mathematics","13","mcq","Integral of 0 dx?",["A. 0","B. 1","C. x","D. C"],"D","∫0 dx = constant C","Integration"),
Question("Further Mathematics","14","short","Find the determinant of [[2,3],[1,4]].",None,"5","Det = 2*4 -3*1=5","Matrices"),
Question("Further Mathematics","15","mcq","Sum of first 20 odd numbers?",["A. 400","B. 400","C. 400","D. 400"],"D","Sum = n^2 → 20^2 = 400","Series & Sequences"),
Question("Further Mathematics","16","short","Solve for x: 3x - 7 = 11",None,"6","3x-7=11 → 3x=18 → x=6","Algebraic Processes"),
Question("Further Mathematics","17","mcq","Modulus of complex number -5 + 12i?",["A. 13","B. 7","C. 12","D. 5"],"A","|z|=√((-5)^2+12^2)=13","Complex numbers"),
Question("Further Mathematics","18","short","Integrate ∫(3x^2) dx.",None,"x^3 + C","∫3x^2 dx = x^3 + C","Integration"),
Question("Further Mathematics","19","mcq","If y = x^3, dy/dx = ?",["A. 3x^2","B. x^3","C. 3x","D. x^2"],"A","d(x^3)/dx = 3x^2","Differentiation"),
Question("Further Mathematics","20","short","Find 10th term of arithmetic sequence 4,7,10,...",None,"31","nth term = a + (n-1)d → 4+9*3=31","Series & Sequences"),
Question("Further Mathematics","21","mcq","Determinant of [[3,2],[1,5]]?",["A. 13","B. 7","C. 5","D. 0"],"A","Det = 3*5 -2*1 = 13","Matrices"),
Question("Further Mathematics","22","short","Differentiate 5x^4",None,"20x^3","d/dx(5x^4) =20x^3","Differentiation"),
Question("Further Mathematics","23","mcq","Integral of 5 dx?",["A. 5x + C","B. x^5 + C","C. 25 + C","D. 0"],"A","∫5 dx = 5x + C","Integration"),
Question("Further Mathematics","24","short","Find sum of first 15 natural numbers.",None,"120","Sum = n(n+1)/2 → 15*16/2=120","Series & Sequences"),
Question("Further Mathematics","25","mcq","If z = 1 + i, find z^2?",["A. 2i","B. 0","C. 1 + 2i","D. -1 + 2i"],"A","(1+i)^2 = 1 + 2i + i^2 = 2i","Complex numbers"),
Question("Further Mathematics","26","short","Solve 2x + 7 = 15",None,"4","2x+7=15 → 2x=8 → x=4","Algebraic Processes"),
Question("Further Mathematics","27","mcq","Derivative of x^3?",["A. 3x^2","B. x^3","C. 3x","D. x^2"],"A","d(x^3)/dx = 3x^2","Differentiation"),
Question("Further Mathematics","28","short","Integrate ∫(6x) dx",None,"3x^2 + C","∫6x dx =3x^2 + C","Integration"),
Question("Further Mathematics","29","mcq","Solve x^2 + 4x + 4 = 0",["A. -2","B. 2","C. 0","D. -1"],"A","Factor: (x+2)^2=0 → x=-2","Algebraic Processes"),
Question("Further Mathematics","30","short","Find 8th term of arithmetic series: 2,5,8,...",None,"23","nth term = a + (n-1)d → 2+7*3=23","Series & Sequences"),
Question("Further Mathematics","31","mcq","Integral of x^0 dx?",["A. x + C","B. 0","C. 1","D. Undefined"],"A","∫1 dx = x + C","Integration"),
Question("Further Mathematics","32","short","Differentiate x^5",None,"5x^4","d/dx(x^5) = 5x^4","Differentiation"),
Question("Further Mathematics","33","mcq","Modulus of 3-4i?",["A. 5","B. 7","C. 1","D. 12"],"A","|z| = √(3^2 + (-4)^2) = 5","Complex numbers"),
Question("Further Mathematics","34","short","Find sum of first 12 odd numbers.",None,"144","Sum of first n odd numbers = n^2 → 12^2 = 144","Series & Sequences"),
Question("Further Mathematics","35","mcq","Solve 3x - 9 = 0",["A. 3","B. 0","C. 6","D. -3"],"A","3x-9=0 → 3x=9 → x=3","Algebraic Processes"),
Question("Further Mathematics","36","short","Integrate ∫(4x^3) dx",None,"x^4 + C","∫4x^3 dx = x^4 + C","Integration"),
Question("Further Mathematics","37","mcq","Derivative of 7x?",["A. 7","B. x","C. 1","D. 0"],"A","d/dx(7x) =7","Differentiation"),
Question("Further Mathematics","38","short","Find 6th term of sequence: 1,4,7,10,...",None,"16","nth term = a + (n-1)d → 1+5*3=16","Series & Sequences"),
Question("Further Mathematics","39","mcq","If z = 2i, then |z|=?",["A. 2","B. 1","C. 4","D. 0"],"A","|2i|=2","Complex numbers"),
Question("Further Mathematics","40","short","Solve 5x + 3 = 18",None,"3","5x+3=18 → 5x=15 → x=3","Algebraic Processes"),
Question("Further Mathematics","41","mcq","Determinant of [[2,1],[3,2]]?",["A. 1","B. 2","C. 3","D. 4"],"A","Det = 2*2 -1*3 =1","Matrices"),
Question("Further Mathematics","42","short","Integrate ∫(7) dx",None,"7x + C","∫7 dx = 7x + C","Integration"),
Question("Further Mathematics","43","mcq","Derivative of x^4?",["A. 4x^3","B. x^4","C. 3x^4","D. x^3"],"A","d(x^4)/dx = 4x^3","Differentiation"),
Question("Further Mathematics","44","short","Find sum of first 20 natural numbers.",None,"210","Sum = n(n+1)/2 → 20*21/2 = 210","Series & Sequences"),
Question("Further Mathematics","45","mcq","Solve x^2 -16=0",["A. 4","B. -4","C. ±4","D. 0"],"C","x^2-16=0 → x=±4","Algebraic Processes"),
Question("Further Mathematics","46","short","Differentiate 3x^2",None,"6x","d/dx(3x^2)=6x","Differentiation"),
Question("Further Mathematics","47","mcq","Integral of x dx?",["A. (1/2)x^2 + C","B. x^2 + C","C. 2x + C","D. x + C"],"A","∫x dx = (1/2)x^2 + C","Integration"),
Question("Further Mathematics","48","short","Find 9th term of arithmetic series: 3,7,11,...",None,"35","nth term = a + (n-1)d → 3+8*4=35","Series & Sequences"),
Question("Further Mathematics","49","mcq","If z=1-i, find |z|?",["A. √2","B. 1","C. 2","D. √3"],"A","|1-i| = √(1^2 + (-1)^2) = √2","Complex numbers"),
Question("Further Mathematics","50","short","Solve 7x - 14 = 0",None,"2","7x-14=0 → 7x=14 → x=2","Algebraic Processes"),
]


# --- Biology ---
REAL_QUESTIONS["biology"] = [
Question("Biology","1","mcq","What is the basic unit of life?",["A. Atom","B. Cell","C. Tissue","D. Organ"],"B","Cell is the structural and functional unit of life","Cell Biology"),
Question("Biology","2","short","Define photosynthesis.",None,"Process by which plants make food using sunlight, CO2 and water","Photosynthesis = light + CO2 + H2O → glucose + O2","Plant Physiology"),
Question("Biology","3","mcq","Which organelle is known as the powerhouse of the cell?",["A. Nucleus","B. Mitochondria","C. Ribosome","D. Golgi apparatus"],"B","Mitochondria produce ATP via respiration","Cell Biology"),
Question("Biology","4","short","Define osmosis.",None,"Movement of water molecules from high to low concentration through semi-permeable membrane","Osmosis = water diffusion","Cell Transport"),
Question("Biology","5","mcq","DNA stands for?",["A. Deoxyribonucleic Acid","B. Dicarboxy Nucleic Acid","C. Deoxyribo Nucleic Amino","D. Di-nucleotide Acid"],"A","DNA = Deoxyribonucleic Acid","Genetics"),
Question("Biology","6","short","Define ecosystem.",None,"A community of organisms interacting with their environment","Ecosystem = biotic + abiotic interactions","Ecology"),
Question("Biology","7","mcq","Which blood cells fight infection?",["A. Red blood cells","B. White blood cells","C. Platelets","D. Plasma"],"B","White blood cells defend against pathogens","Human Biology"),
Question("Biology","8","short","Define respiration.",None,"Process of releasing energy from food","Respiration = glucose + O2 → CO2 + H2O + energy","Cell Biology"),
Question("Biology","9","mcq","Which macromolecule is the main source of energy?",["A. Proteins","B. Carbohydrates","C. Lipids","D. Nucleic acids"],"B","Carbohydrates are primary energy source","Biochemistry"),
Question("Biology","10","short","Define diffusion.",None,"Movement of particles from high to low concentration","Diffusion = passive movement","Cell Transport"),
Question("Biology","11","mcq","Which vitamin is synthesized in the skin by sunlight?",["A. Vitamin A","B. Vitamin B12","C. Vitamin C","D. Vitamin D"],"D","Vitamin D synthesized via UV light","Human Physiology"),
Question("Biology","12","short","Define habitat.",None,"Place where an organism lives","Habitat = natural living environment","Ecology"),
Question("Biology","13","mcq","Which part of the cell controls activities?",["A. Cytoplasm","B. Nucleus","C. Ribosome","D. Membrane"],"B","Nucleus contains DNA and regulates cell functions","Cell Biology"),
Question("Biology","14","short","Define biodiversity.",None,"Variety of living organisms in an area","Biodiversity = species variety","Ecology"),
Question("Biology","15","mcq","Which macromolecule stores genetic information?",["A. Protein","B. DNA","C. Lipid","D. Carbohydrate"],"B","DNA carries genetic code","Genetics"),
Question("Biology","16","short","Define food chain.",None,"Sequence of organisms showing who eats whom","Food chain = energy transfer sequence","Ecology"),
Question("Biology","17","mcq","Which is a prokaryotic cell?",["A. Plant cell","B. Bacterial cell","C. Fungal cell","D. Animal cell"],"B","Bacteria lack nucleus → prokaryotic","Cell Biology"),
Question("Biology","18","short","Define enzyme.",None,"Protein that catalyzes chemical reactions","Enzyme = biological catalyst","Biochemistry"),
Question("Biology","19","mcq","Which part of the plant conducts photosynthesis?",["A. Root","B. Leaf","C. Stem","D. Flower"],"B","Leaves contain chloroplasts for photosynthesis","Plant Physiology"),
Question("Biology","20","short","Define transpiration.",None,"Loss of water vapor from plant leaves","Transpiration = water evaporation from stomata","Plant Physiology"),
Question("Biology","21","mcq","Which macronutrient is used for growth and repair?",["A. Carbohydrate","B. Protein","C. Lipid","D. Vitamin"],"B","Proteins build and repair tissues","Nutrition"),
Question("Biology","22","short","Define allele.",None,"Different forms of a gene","Allele = variant of a gene","Genetics"),
Question("Biology","23","mcq","Which organism is autotrophic?",["A. Human","B. Grass","C. Lion","D. Fungi"],"B","Grass makes its own food via photosynthesis","Ecology"),
Question("Biology","24","short","Define population.",None,"Group of individuals of same species in an area","Population = species group","Ecology"),
Question("Biology","25","mcq","Which organ filters blood in humans?",["A. Heart","B. Kidney","C. Liver","D. Lungs"],"B","Kidneys remove waste from blood","Human Physiology"),
Question("Biology","26","short","Define allele frequency.",None,"Proportion of a specific allele in a population","Allele frequency = gene proportion","Genetics"),
Question("Biology","27","mcq","Which is a decomposer?",["A. Bacteria","B. Lion","C. Grass","D. Snake"],"A","Bacteria break down dead matter","Ecology"),
Question("Biology","28","short","Define genotype.",None,"Genetic makeup of an organism","Genotype = genetic composition","Genetics"),
Question("Biology","29","mcq","Which is a mammal?",["A. Frog","B. Whale","C. Lizard","D. Crocodile"],"B","Whales are warm-blooded mammals","Zoology"),
Question("Biology","30","short","Define phenotype.",None,"Observable traits of an organism","Phenotype = physical expression of genes","Genetics"),
Question("Biology","31","mcq","Which part of brain controls balance?",["A. Cerebrum","B. Cerebellum","C. Medulla","D. Hypothalamus"],"B","Cerebellum regulates balance and coordination","Human Anatomy"),
Question("Biology","32","short","Define biomagnification.",None,"Increase in toxin concentration along food chain","Biomagnification = toxin accumulation","Ecology"),
Question("Biology","33","mcq","Which hormone regulates blood sugar?",["A. Insulin","B. Adrenaline","C. Thyroxine","D. Estrogen"],"A","Insulin lowers blood glucose","Human Physiology"),
Question("Biology","34","short","Define carrying capacity.",None,"Maximum population an environment can support","Carrying capacity = max sustainable population","Ecology"),
Question("Biology","35","mcq","Which organelle is responsible for protein synthesis?",["A. Ribosome","B. Golgi body","C. Mitochondria","D. Lysosome"],"A","Ribosomes synthesize proteins","Cell Biology"),
Question("Biology","36","short","Define mutualism.",None,"Interaction where both species benefit","Mutualism = win-win species interaction","Ecology"),
Question("Biology","37","mcq","Which blood component helps clotting?",["A. Plasma","B. Platelets","C. WBC","D. RBC"],"B","Platelets form blood clots","Human Biology"),
Question("Biology","38","short","Define natural selection.",None,"Process by which organisms with favorable traits survive and reproduce","Natural selection = survival of fittest","Evolution"),
Question("Biology","39","mcq","Which is an insect?",["A. Spider","B. Butterfly","C. Crab","D. Centipede"],"B","Butterfly has 6 legs → insect","Zoology"),
Question("Biology","40","short","Define adaptation.",None,"Trait that increases survival or reproduction","Adaptation = survival trait","Evolution"),
Question("Biology","41","mcq","Which tissue connects muscles to bones?",["A. Ligament","B. Tendon","C. Cartilage","D. Epithelium"],"B","Tendons attach muscle to bone","Human Anatomy"),
Question("Biology","42","short","Define ecological niche.",None,"Role of species in ecosystem","Ecological niche = species function","Ecology"),
Question("Biology","43","mcq","Which part of cell stores DNA?",["A. Nucleus","B. Cytoplasm","C. Mitochondria","D. Ribosome"],"A","DNA located in nucleus","Cell Biology"),
Question("Biology","44","short","Define autotroph.",None,"Organism that makes its own food","Autotroph = self-feeder","Ecology"),
Question("Biology","45","mcq","Which plant tissue transports water?",["A. Phloem","B. Xylem","C. Cambium","D. Cortex"],"B","Xylem conducts water","Plant Physiology"),
Question("Biology","46","short","Define saprotroph.",None,"Organism that feeds on dead matter","Saprotroph = decomposer","Ecology"),
Question("Biology","47","mcq","Which part of neuron receives impulses?",["A. Axon","B. Dendrite","C. Soma","D. Myelin"],"B","Dendrites receive signals","Human Anatomy"),
Question("Biology","48","short","Define keystone species.",None,"Species with large impact on ecosystem","Keystone species = ecosystem regulator","Ecology"),
Question("Biology","49","mcq","Which gas is released during photosynthesis?",["A. CO2","B. O2","C. N2","D. H2"],"B","Photosynthesis releases oxygen","Plant Physiology"),
Question("Biology","50","short","State Mendel’s law of segregation.",None,"Alleles separate during gamete formation","Law of segregation = alleles separate","Genetics"),
]


# --- ICT ---
REAL_QUESTIONS["ict"] = [
Question("ICT","1","mcq","What does ICT stand for?",["A. Information and Communication Technology","B. Internet and Computer Technology","C. Integrated Computer Tech","D. Information Control Technique"],"A","ICT = Information and Communication Technology","ICT Basics"),
Question("ICT","2","short","Define hardware.",None,"Physical components of a computer","Hardware = physical computer parts","Computer Fundamentals"),
Question("ICT","3","mcq","Which is an input device?",["A. Monitor","B. Keyboard","C. Printer","D. Speaker"],"B","Keyboard is used to input data","Computer Hardware"),
Question("ICT","4","short","Define software.",None,"Programs and instructions that run on a computer","Software = computer programs","Computer Fundamentals"),
Question("ICT","5","mcq","Which is an example of an operating system?",["A. Microsoft Word","B. Windows 10","C. Chrome","D. Excel"],"B","Windows 10 is an OS","Software Types"),
Question("ICT","6","short","Define network.",None,"Connecting two or more computers to share resources","Network = connected computers","Networking"),
Question("ICT","7","mcq","Which device connects computers to the internet?",["A. Switch","B. Router","C. Printer","D. Keyboard"],"B","Router connects to the internet","Networking"),
Question("ICT","8","short","Define CPU.",None,"Central Processing Unit, the brain of the computer","CPU = Central Processing Unit","Computer Hardware"),
Question("ICT","9","mcq","Which is a storage device?",["A. RAM","B. Hard Disk","C. CPU","D. Monitor"],"B","Hard disk stores data permanently","Computer Hardware"),
Question("ICT","10","short","Define RAM.",None,"Random Access Memory, temporary storage for running programs","RAM = temporary memory","Computer Hardware"),
Question("ICT","11","mcq","Which is an output device?",["A. Mouse","B. Monitor","C. Keyboard","D. Scanner"],"B","Monitor displays output","Computer Hardware"),
Question("ICT","12","short","Define internet.",None,"Global network connecting computers","Internet = worldwide network","Networking"),
Question("ICT","13","mcq","Which is an example of application software?",["A. Linux","B. Photoshop","C. BIOS","D. Windows"],"B","Photoshop is used for tasks → application software","Software Types"),
Question("ICT","14","short","Define LAN.",None,"Local Area Network, network in small area","LAN = local network","Networking"),
Question("ICT","15","mcq","Which is a web browser?",["A. Excel","B. Chrome","C. Windows","D. Word"],"B","Chrome is used to access web pages","Internet & Web"),
Question("ICT","16","short","Define URL.",None,"Uniform Resource Locator, address of a web page","URL = website address","Internet & Web"),
Question("ICT","17","mcq","Which is a programming language?",["A. HTML","B. Python","C. Word","D. Excel"],"B","Python is a programming language","Programming"),
Question("ICT","18","short","Define database.",None,"Collection of organized data","Database = structured data storage","Database Management"),
Question("ICT","19","mcq","Which is a relational database?",["A. MySQL","B. Word","C. Excel","D. Paint"],"A","MySQL stores data in tables","Database Management"),
Question("ICT","20","short","Define malware.",None,"Malicious software that harms computer","Malware = harmful software","Cybersecurity"),
Question("ICT","21","mcq","Which is a network topology?",["A. Bus","B. Table","C. Spreadsheet","D. Document"],"A","Bus topology = network layout","Networking"),
Question("ICT","22","short","Define firewall.",None,"Security system to block unauthorized access","Firewall = network security","Cybersecurity"),
Question("ICT","23","mcq","Which device amplifies network signals?",["A. Hub","B. Repeater","C. Router","D. Switch"],"B","Repeater boosts signals","Networking"),
Question("ICT","24","short","Define cloud computing.",None,"Using remote servers to store and process data","Cloud computing = online resources","Internet & Web"),
Question("ICT","25","mcq","Which is volatile memory?",["A. Hard Disk","B. RAM","C. ROM","D. Flash"],"B","RAM loses data when power is off","Computer Hardware"),
Question("ICT","26","short","Define antivirus.",None,"Software that detects and removes viruses","Antivirus = virus protection","Cybersecurity"),
Question("ICT","27","mcq","Which is a search engine?",["A. Google","B. Excel","C. Windows","D. Python"],"A","Google searches information online","Internet & Web"),
Question("ICT","28","short","Define IP address.",None,"Unique address of a device on network","IP address = device identifier","Networking"),
Question("ICT","29","mcq","Which is secondary storage?",["A. RAM","B. ROM","C. Hard disk","D. CPU"],"C","Hard disk stores data permanently","Computer Hardware"),
Question("ICT","30","short","Define phishing.",None,"Fraudulent attempt to steal information","Phishing = online scam","Cybersecurity"),
Question("ICT","31","mcq","Which is an example of open-source software?",["A. Windows","B. Linux","C. Photoshop","D. MS Word"],"B","Linux source code is publicly available","Software Types"),
Question("ICT","32","short","Define spreadsheet.",None,"Software for organizing data in rows and columns","Spreadsheet = table data software","Application Software"),
Question("ICT","33","mcq","Which is used for video conferencing?",["A. Zoom","B. Word","C. Excel","D. Paint"],"A","Zoom enables virtual meetings","Application Software"),
Question("ICT","34","short","Define URL shortener.",None,"Service to reduce long website links","URL shortener = short link generator","Internet & Web"),
Question("ICT","35","mcq","Which protocol is used for web pages?",["A. HTTP","B. FTP","C. SMTP","D. POP3"],"A","HTTP is used for websites","Networking"),
Question("ICT","36","short","Define cloud storage.",None,"Storing data on remote servers accessed via internet","Cloud storage = online data storage","Internet & Web"),
Question("ICT","37","mcq","Which is a type of malware?",["A. Trojan","B. Firewall","C. Router","D. Switch"],"A","Trojan harms computers","Cybersecurity"),
Question("ICT","38","short","Define domain name.",None,"Readable address of a website","Domain name = website name","Internet & Web"),
Question("ICT","39","mcq","Which device is used to connect multiple devices in a network?",["A. Hub","B. Monitor","C. Keyboard","D. Mouse"],"A","Hub connects multiple computers","Networking"),
Question("ICT","40","short","Define HTML.",None,"Hypertext Markup Language, used to create web pages","HTML = web page language","Programming"),
Question("ICT","41","mcq","Which software is used for presentation?",["A. PowerPoint","B. Word","C. Excel","D. Paint"],"A","PowerPoint makes slides","Application Software"),
Question("ICT","42","short","Define URL protocol.",None,"Rules used to access websites","URL protocol = web access method","Internet & Web"),
Question("ICT","43","mcq","Which is primary storage?",["A. RAM","B. Hard Disk","C. CD-ROM","D. Flash Drive"],"A","RAM is primary memory","Computer Hardware"),
Question("ICT","44","short","Define browser cache.",None,"Temporary storage to speed up web browsing","Browser cache = temporary web data","Internet & Web"),
Question("ICT","45","mcq","Which is a vector graphics software?",["A. CorelDRAW","B. Photoshop","C. Excel","D. Word"],"A","CorelDRAW creates vector images","Application Software"),
Question("ICT","46","short","Define URL extension.",None,"Suffix indicating type of website","URL extension = .com, .org etc","Internet & Web"),
Question("ICT","47","mcq","Which is a wireless network?",["A. Wi-Fi","B. Ethernet","C. LAN cable","D. USB"],"A","Wi-Fi connects devices wirelessly","Networking"),
Question("ICT","48","short","Define data compression.",None,"Reducing file size to save space","Data compression = file size reduction","Computer Fundamentals"),
Question("ICT","49","mcq","Which programming language is used for web development?",["A. Python","B. HTML","C. C++","D. Java"],"B","HTML is used for creating web pages","Programming"),
Question("ICT","50","short","Define cybersecurity.",None,"Protection of computers and networks from attacks","Cybersecurity = IT security","Cybersecurity"),
]

# -------------------------
# CSS / layout tweaks for WAEC center UI
# -------------------------
st.set_page_config(page_title="WAEC CBT — AI FOR EDUCATION", page_icon="🎓", layout="wide")
st.markdown(
    """
    <style>
      .center-card { max-width: 900px; margin: 18px auto; border-radius:12px;
                     box-shadow: 0 6px 18px rgba(0,0,0,0.08); padding:18px; }
      .waec-timer { border-radius:10px; padding:10px; text-align:center; }
      .question-card { background: #ffffff; padding: 16px; border-radius:10px; }
      .option-btn { width:100%; text-align:left; padding:10px; margin-bottom:6px; border-radius:8px; }
      .nav-btn { min-width:120px; margin:6px; }
    </style>
    """,
    unsafe_allow_html=True
)

st.title("🏫 WAEC CBT — AI FOR EDUCATION (Centered CBT Layout)")

# -------------------------
# Sidebar: candidate info, subject, controls
# -------------------------
with st.sidebar.form("config", clear_on_submit=False):
    st.header("Exam Setup")
    candidate_name = st.text_input("Candidate name", value=st.session_state.get("candidate_name",""))
    candidate_no = st.text_input("Candidate number", value=st.session_state.get("candidate_no",""))
    subject = st.selectbox("Subject", [s.title() for s in REAL_QUESTIONS.keys()],
                           index=0)
    # per-question time settings
    qtype_choice = st.radio("Question type (filter)", ["Both","MCQ","Theory"])
    n_questions = st.number_input("Number of questions", 1, 50, 5)
    min_time = st.number_input("Min time per question (s)",3,120,6)
    max_time = st.number_input("Max time per question (s)",3,120,20)
    show_steps_default = st.checkbox("Show step-by-step toggle by default", True)
    preferred_save_dir = st.text_input("Optional: preferred save directory")
    start = st.form_submit_button("Start Quiz")

    # save candidate info in session (so we can persist)
    st.session_state.candidate_name = candidate_name
    st.session_state.candidate_no = candidate_no

# initialize session state if not present
if "running" not in st.session_state:
    st.session_state.running = False

if start:
    subject_key = subject.lower()
    pool = REAL_QUESTIONS.get(subject_key, [])
    if qtype_choice.lower() == "mcq":
        pool = [q for q in pool if q.qtype == "mcq"]
    elif qtype_choice.lower() == "theory":
        pool = [q for q in pool if q.qtype == "short"]
    pool = random.sample(pool, min(len(pool), n_questions))
    st.session_state.questions = pool
    st.session_state.index = 0
    st.session_state.score = 0
    st.session_state.total = 0
    st.session_state.missed = []
    st.session_state.elapsed = []
    st.session_state.logger = SessionLogger()
    st.session_state.min_time = min_time
    st.session_state.max_time = max_time
    st.session_state.running = True
    st.session_state.current_time_limit = random.randint(min_time, max_time)
    st.session_state.timer_start = time.time()
    st.session_state.show_steps_default = show_steps_default
    st.session_state.preferred_save_dir = preferred_save_dir.strip() or None
    st.session_state.subject_key = subject_key

if not st.session_state.running:
    st.info("Configure the exam on the left and click Start Quiz")
    st.stop()

# Top layout: centered card with three columns (left sidebar, center question, right chat/help)
left_col, center_col, right_col = st.columns([1, 2.2, 0.9])

questions: List[Question] = st.session_state.questions
idx = st.session_state.index
if idx >= len(questions): idx = len(questions)-1
q = questions[idx]
allowed = st.session_state.current_time_limit

# --- LEFT (info + timer card) ---
with left_col:
    st.markdown("<div class='center-card'>", unsafe_allow_html=True)
    st.subheader("Candidate")
    st.write(st.session_state.get("candidate_name", "—"))
    st.caption(f"No: {st.session_state.get('candidate_no','—')}")
    st.markdown("---")
    st.subheader("Question Info")
    st.write(f"Subject: **{q.subject}**")
    st.write(f"Q {idx+1} of {len(questions)}")
    st.write(f"Topic: {q.topic or 'General'}")
    st.markdown("---")
    # Timer card (animated)
    timer_placeholder = st.empty()
    # simple progress ring representation
    st.markdown("</div>", unsafe_allow_html=True)

# Live timer function (non-blocking-ish): updates visual then returns remaining.
def live_timer_update(start_time, allowed_time, placeholder):
    # We'll loop and update placeholder until either time runs out
    # or user interacts (Next/Prev/Submit) which will reset timer_start.
    # Note: this loop will block further interaction while running;
    # it's intended to run for a short period per page render and auto-advance on timeout.
    while True:
        elapsed = time.time() - start_time
        remaining = int(allowed_time - elapsed)
        if remaining <= 0:
            placeholder.markdown(
                f"<div class='waec-timer' style='background:#fff0b3;'>"
                f"<strong>⏳ Time remaining: 0s</strong></div>",
                unsafe_allow_html=True)
            return 0
        # display numeric and progress
        pct = max(0, remaining / allowed_time)
        pct_display = int(pct * 100)
        placeholder.markdown(
            f"<div class='waec-timer' style='background:#f0f7ff;'>"
            f"<div style='font-size:18px; font-weight:700;'>⏳ {remaining}s</div>"
            f"<div style='margin-top:6px;'>Progress: {pct_display}%</div>"
            f"</div>",
            unsafe_allow_html=True)
        # update every second
        time.sleep(1)

# Run the live timer (this will block briefly while updating every second)
remaining = live_timer_update(st.session_state.timer_start, allowed, timer_placeholder)
# show center progress bar
center_col.progress(max(0, remaining/allowed))

timed_out = remaining <= 0

# If time ran out, treat as automatic 'Next' with timed_out True
if timed_out:
    st.session_state.elapsed.append(time.time()-st.session_state.timer_start)
    st.session_state.total += 1
    # record no-input as user input ""
    # determine correctness: false (timed out)
    st.session_state.logger.add(q, "", False, st.session_state.elapsed[-1], True, allowed)
    st.session_state.missed.append(q)
    st.session_state.index += 1
    # reset timer for next question if any
    st.session_state.timer_start = time.time()
    if st.session_state.index < len(questions):
        st.session_state.current_time_limit = random.randint(st.session_state.min_time, st.session_state.max_time)
    # rerun to reflect next question
    # st.experimental_rerun()

# -------------------------
# CENTER: QUESTION CARD
# -------------------------
with center_col:
    st.markdown("<div class='center-card question-card'>", unsafe_allow_html=True)
    st.subheader(f"Q{idx+1} — {q.subject}")
    st.write(q.text)
    st.write("")  # spacing

    # Show options or text box
    user_answer_key = f"answer_{idx}"
    if q.qtype == "mcq" and q.options:
        # Render buttons styled vertically (radio keeps state)
        choice = st.radio("Select option", q.options, index=0, key=user_answer_key)
    else:
        # short/theory
        choice = st.text_input("Your answer", key=user_answer_key, value=st.session_state.get(user_answer_key,""))

    # show explanation toggle
    if st.checkbox("Show step-by-step / explanation", value=st.session_state.show_steps_default):
        st.info(q.explanation)

    st.markdown("</div>", unsafe_allow_html=True)

# -------------------------
# RIGHT: Chatbot / Help
# -------------------------
with right_col:
    st.markdown("<div class='center-card'>", unsafe_allow_html=True)
    st.subheader("Chatbot / Help")
    user_msg = st.text_input("Ask something:", key="chat_input_right")
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    def chatbot_response_multi(user_text: str, subject_key: str, current_q: Question) -> str:
        user_text_lower = user_text.lower()
        if any(word in user_text_lower for word in ["hint", "help", "tip", "clue"]):
            return f"Hint: Focus on the topic '{current_q.topic or 'General'}'.\n" \
                   f"Question snippet: {current_q.text[:60]}..."
        if any(word in user_text_lower for word in ["answer", "solution", "solve"]):
            return f"Answer: {current_q.answer}\nExplanation: {current_q.explanation}"
        if "missed" in user_text_lower:
            missed = st.session_state.missed
            if not missed:
                return "Great! You haven't missed any questions yet."
            return "Missed:\n" + "\n".join([f"{m.number}. {m.text} → {m.answer}" for m in missed[:5]])
        return "Try asking for a hint, the answer, or 'missed' questions."

    if st.button("Send", key="send_right") and user_msg.strip():
        resp = chatbot_response_multi(user_msg, st.session_state.subject_key, q)
        st.session_state.chat_history.append(("You", user_msg))
        st.session_state.chat_history.append(("Bot", resp))

    # display last 6 chat messages
    for speaker, msg in st.session_state.chat_history[-6:]:
        if speaker == "You":
            st.markdown(f"**You:** {msg}")
        else:
            st.markdown(f"**Bot:** {msg}")

    st.markdown("</div>", unsafe_allow_html=True)

# -------------------------
# Bottom Navigation
# -------------------------
nav_col1, nav_col2, nav_col3 = st.columns([1,1,1])

with nav_col1:
    if st.button("Previous", key="prev_btn"):
        if st.session_state.index > 0:
            st.session_state.index -= 1
            st.session_state.timer_start = time.time()
            # keep the same time limit or randomize again
            st.session_state.current_time_limit = random.randint(st.session_state.min_time, st.session_state.max_time)
            st.experimental_rerun()

with nav_col2:
    if st.button("Next", key="next_btn"):
        # record current answer
        ans = st.session_state.get(user_answer_key, "")
        st.session_state.elapsed.append(time.time()-st.session_state.timer_start)
        st.session_state.total += 1
        correct = False
        try:
            if q.qtype == "mcq" and q.options:
                correct = normalize_label(ans.split(".")[0]) == normalize_label(q.answer)
            else:
                correct = compare_short(q.answer, ans)
        except Exception:
            correct = False

        if correct:
            st.session_state.score += 1
        else:
            st.session_state.missed.append(q)

        st.session_state.logger.add(q, ans, correct, st.session_state.elapsed[-1], False, st.session_state.current_time_limit)
        st.session_state.index += 1
        st.session_state.timer_start = time.time()
        if st.session_state.index < len(questions):
            st.session_state.current_time_limit = random.randint(st.session_state.min_time, st.session_state.max_time)
        st.experimental_rerun()

with nav_col3:
    if st.button("Submit & Finish", key="submit_btn"):
        # finalize without auto-answering remaining
        st.session_state.running = False
        st.experimental_rerun()

# -------------------------
# Summary screen handling (when finished)
# -------------------------
if not st.session_state.running or st.session_state.index >= len(questions):
    # compute summary
    total = st.session_state.total
    score = st.session_state.score
    pct = 100 * score / total if total else 0
    avg = sum(st.session_state.elapsed) / len(st.session_state.elapsed) if st.session_state.elapsed else 0

    st.header("Quiz Summary")
    st.write(f"Candidate: **{st.session_state.get('candidate_name','—')}**  |  No: **{st.session_state.get('candidate_no','—')}**")
    st.write(f"Score: **{score}/{total}** ({pct:.1f}%)")
    st.write(f"Average time per question: **{avg:.1f}s**")
    st.write(f"Missed questions: **{len(st.session_state.missed)}**")

    if st.button("Save session log"):
        try:
            out = st.session_state.logger.save(st.session_state.preferred_save_dir)
            st.success(f"Saved session log to: {out}")
        except Exception as e:
            st.error(f"Could not save session log: {e}")

    if st.button("Restart exam"):
        # reset
        st.session_state.running = False
        st.session_state.index = 0
        st.session_state.score = 0
        st.session_state.total = 0
        st.session_state.missed = []
        st.session_state.elapsed = []
        st.session_state.chat_history = []
        # st.experimental_rerun()
