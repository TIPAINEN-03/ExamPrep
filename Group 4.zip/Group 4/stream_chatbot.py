import streamlit as st
import random
from collections import defaultdict
import pickle
import os
import re
from typing import List

try:
    import PyPDF2
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    import numpy as np
except ImportError:
    st.error("Installing required packages... Please refresh after installation.")
    os.system("pip install PyPDF2 scikit-learn numpy")
    st.stop()


class PDFQuestionGenerator:
    def __init__(self, data_file='pdf_quiz_data.pkl'):
        self.documents = []
        self.chunks = []
        self.vectorizer = TfidfVectorizer(stop_words='english', max_features=1000)
        self.tfidf_matrix = None
        self.data_file = data_file
        self.generated_questions = []
    
    def extract_text_from_pdf(self, pdf_file) -> str:
        """Extract text from a PDF file."""
        text = ""
        try:
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
            return text
        except Exception as e:
            st.error(f"Error reading PDF: {e}")
            return ""
    
    def chunk_text(self, text: str, chunk_size: int = 800) -> List[str]:
        """Split text into larger chunks for question generation."""
        sentences = re.split(r'[.!?]+', text)
        chunks = []
        current_chunk = ""
        
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            
            if len(current_chunk) + len(sentence) < chunk_size:
                current_chunk += sentence + ". "
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = sentence + ". "
        
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks
    
    def process_pdfs(self, pdf_files, pdf_names):
        """Process uploaded PDF documents."""
        for pdf_file, pdf_name in zip(pdf_files, pdf_names):
            text = self.extract_text_from_pdf(pdf_file)
            if text:
                self.documents.append({
                    'name': pdf_name,
                    'text': text
                })
                
                chunks = self.chunk_text(text)
                for chunk in chunks:
                    self.chunks.append({
                        'text': chunk,
                        'source': pdf_name
                    })
        
        if not self.chunks:
            return False
        
        chunk_texts = [chunk['text'] for chunk in self.chunks]
        self.tfidf_matrix = self.vectorizer.fit_transform(chunk_texts)
        
        self.save_data()
        return True
    
    def generate_questions_from_chunks(self, num_questions=10):
        """Generate quiz questions from the PDF chunks."""
        if not self.chunks:
            return []
        
        # Select random chunks to base questions on
        selected_chunks = random.sample(
            self.chunks, 
            min(num_questions, len(self.chunks))
        )
        
        questions = []
        for i, chunk in enumerate(selected_chunks):
            # Extract key information from the chunk
            sentences = [s.strip() for s in chunk['text'].split('.') if s.strip()]
            
            if len(sentences) < 2:
                continue
            
            # Use the first substantial sentence as the basis for a question
            base_sentence = sentences[0] if len(sentences[0]) > 20 else (sentences[1] if len(sentences) > 1 else sentences[0])
            
            # Generate a simple factual question
            question_text = f"Based on the document '{chunk['source']}': {base_sentence[:100]}..."
            
            # Create a question structure
            question = {
                "subject": chunk['source'],
                "question": f"What information is provided about this topic in the document?",
                "context": base_sentence[:200],
                "options": [
                    f"A. {sentences[0][:80]}..." if len(sentences) > 0 else "A. Option A",
                    f"B. {sentences[1][:80]}..." if len(sentences) > 1 else "B. Option B",
                    f"C. {sentences[2][:80]}..." if len(sentences) > 2 else "C. Option C",
                    f"D. {sentences[3][:80]}..." if len(sentences) > 3 else "D. Option D",
                ],
                "answer": "A",  # First option is always correct in this simple implementation
                "explanation": f"This information is directly stated in the document: {base_sentence}",
                "full_context": chunk['text'][:500]
            }
            
            questions.append(question)
        
        self.generated_questions = questions
        return questions
    
    def save_data(self):
        """Save processed data to disk."""
        data = {
            'documents': self.documents,
            'chunks': self.chunks,
            'vectorizer': self.vectorizer,
            'tfidf_matrix': self.tfidf_matrix,
            'generated_questions': self.generated_questions
        }
        with open(self.data_file, 'wb') as f:
            pickle.dump(data, f)
    
    def load_data(self):
        """Load processed data from disk."""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'rb') as f:
                    data = pickle.load(f)
                self.documents = data.get('documents', [])
                self.chunks = data.get('chunks', [])
                self.vectorizer = data.get('vectorizer', TfidfVectorizer())
                self.tfidf_matrix = data.get('tfidf_matrix', None)
                self.generated_questions = data.get('generated_questions', [])
                return True
            except Exception as e:
                st.error(f"Could not load data: {e}")
                return False
        return False


def initialize_state():
    """Initialize session state variables."""
    if 'app_state' not in st.session_state:
        st.session_state.app_state = "UPLOAD"
        st.session_state.score = 0
        st.session_state.current_question_index = 0
        st.session_state.questions_to_ask = []
        st.session_state.chosen_subject = None
        st.session_state.answer_submitted = False
        st.session_state.user_choice = None
        st.session_state.generator = PDFQuestionGenerator()
        st.session_state.generator.load_data()


def reset_quiz():
    """Reset quiz state to start over."""
    st.session_state.app_state = "MENU"
    st.session_state.score = 0
    st.session_state.current_question_index = 0
    st.session_state.questions_to_ask = []
    st.session_state.chosen_subject = None
    st.session_state.answer_submitted = False
    st.session_state.user_choice = None


def show_upload_page():
    """Display PDF upload and processing page."""
    st.title("📚 PDF Quiz Generator")
    st.markdown("Upload PDF documents to automatically generate quiz questions!")
    
    st.write("---")
    
    # Show currently loaded documents
    if st.session_state.generator.documents:
        st.success(f"✅ {len(st.session_state.generator.documents)} PDF(s) already loaded")
        with st.expander("View loaded documents"):
            for i, doc in enumerate(st.session_state.generator.documents, 1):
                st.text(f"{i}. {doc['name']}")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("📝 Start Quiz with Loaded PDFs", type="primary"):
                st.session_state.app_state = "MENU"
                st.rerun()
        with col2:
            if st.button("🗑️ Clear All Data"):
                st.session_state.generator = PDFQuestionGenerator()
                if os.path.exists('pdf_quiz_data.pkl'):
                    os.remove('pdf_quiz_data.pkl')
                st.success("All data cleared!")
                st.rerun()
        
        st.write("---")
        st.subheader("Or upload more PDFs below:")
    
    # Upload new PDFs
    uploaded_files = st.file_uploader(
        "Upload PDF documents",
        type=['pdf'],
        accept_multiple_files=True,
        help="Upload educational PDFs to generate quiz questions"
    )
    
    if uploaded_files:
        if st.button("🚀 Process PDFs and Generate Questions", type="primary"):
            with st.spinner("Processing PDFs and generating questions..."):
                pdf_names = [f.name for f in uploaded_files]
                success = st.session_state.generator.process_pdfs(uploaded_files, pdf_names)
                
                if success:
                    st.success(f"✅ Successfully processed {len(uploaded_files)} PDF(s)!")
                    st.success(f"📊 Total text chunks: {len(st.session_state.generator.chunks)}")
                    
                    # Generate questions
                    questions = st.session_state.generator.generate_questions_from_chunks(20)
                    st.session_state.generator.save_data()
                    st.success(f"🎯 Generated {len(questions)} questions!")
                    
                    st.balloons()
                    
                    if st.button("Continue to Quiz"):
                        st.session_state.app_state = "MENU"
                        st.rerun()
                else:
                    st.error("❌ Failed to extract text from PDFs")


def organize_questions_by_subject(questions):
    """Organize questions by PDF source."""
    organized = defaultdict(list)
    for q in questions:
        organized[q['subject']].append(q)
    return organized


def show_menu():
    """Display subject selection menu."""
    st.title("📖 Select Your Study Material")
    
    if not st.session_state.generator.generated_questions:
        st.warning("⚠️ No questions generated yet. Please upload PDFs first.")
        if st.button("← Back to Upload"):
            st.session_state.app_state = "UPLOAD"
            st.rerun()
        return
    
    questions_by_subject = organize_questions_by_subject(
        st.session_state.generator.generated_questions
    )
    
    st.markdown("Select a document to practice:")
    
    subject_map = {}
    sorted_subjects = sorted(questions_by_subject.keys())
    for i, subject in enumerate(sorted_subjects):
        key = str(i + 1)
        subject_map[key] = subject
    
    subject_options = [
        f"[{key}] {subject} ({len(questions_by_subject[subject])} questions)" 
        for key, subject in subject_map.items()
    ]
    
    display_choice = st.selectbox(
        "Available Documents:",
        ["Select a document..."] + subject_options,
        index=0
    )

    if display_choice != "Select a document...":
        selected_key = display_choice.split(']')[0][1:]
        chosen_subject = subject_map.get(selected_key)
        
        if chosen_subject and st.button(f"Start Quiz: {chosen_subject}", type="primary"):
            st.session_state.chosen_subject = chosen_subject
            questions = list(questions_by_subject[chosen_subject])
            random.shuffle(questions)
            st.session_state.questions_to_ask = questions
            st.session_state.current_question_index = 0
            st.session_state.score = 0
            st.session_state.answer_submitted = False
            st.session_state.app_state = "QUIZ"
            st.rerun()
    
    st.write("---")
    if st.button("← Back to Upload"):
        st.session_state.app_state = "UPLOAD"
        st.rerun()


def show_quiz_question():
    """Display current quiz question."""
    if st.session_state.current_question_index >= len(st.session_state.questions_to_ask):
        st.session_state.app_state = "RESULTS"
        st.rerun()
        return

    q = st.session_state.questions_to_ask[st.session_state.current_question_index]
    total_questions = len(st.session_state.questions_to_ask)
    question_number = st.session_state.current_question_index + 1

    st.subheader(f"Quiz: {st.session_state.chosen_subject}")
    st.progress(question_number / total_questions)
    st.markdown(f"**Question {question_number} / {total_questions}**")
    
    # Show context if available
    if 'context' in q:
        with st.expander("📄 Context from document"):
            st.info(q['context'])
    
    st.markdown(f"### {q['question']}")
    st.write("---")

    if st.session_state.answer_submitted:
        user_answer = st.session_state.user_choice
        correct_answer = q['answer']
        
        if user_answer == correct_answer:
            st.success("✅ Correct! Well done.")
        else:
            st.error(f"❌ Incorrect. The correct answer was {correct_answer}.")
            st.info("**Explanation:**")
            st.markdown(q['explanation'])
            
            # Show full context
            if 'full_context' in q:
                with st.expander("📖 Read full context"):
                    st.write(q['full_context'])
        
        if st.button("Next Question →", type="primary"):
            st.session_state.current_question_index += 1
            st.session_state.answer_submitted = False
            st.session_state.user_choice = None
            st.rerun()
    else:
        option_choice = st.radio(
            "Select your answer:",
            q['options'],
            key=f"q_{question_number}"
        )
        
        if st.button("Submit Answer", type="primary"):
            st.session_state.user_choice = option_choice.split('.')[0]
            st.session_state.answer_submitted = True
            
            if st.session_state.user_choice == q['answer']:
                st.session_state.score += 1
            
            st.rerun()


def show_results():
    """Display quiz results."""
    st.title("🎉 Quiz Complete!")
    st.write("---")
    
    total_questions = len(st.session_state.questions_to_ask)
    score = st.session_state.score
    
    st.subheader(f"Document: {st.session_state.chosen_subject}")
    st.subheader(f"Final Score: **{score} / {total_questions}**")
    
    if total_questions > 0:
        percentage = round((score / total_questions) * 100, 2)
        st.metric(label="Percentage", value=f"{percentage}%")
        
        if percentage >= 80:
            st.balloons()
            st.success("🌟 EXCELLENT! You have a strong understanding of the material.")
        elif percentage >= 50:
            st.info("👍 GOOD JOB! Review the missed questions to improve further.")
        else:
            st.warning("📚 KEEP STUDYING! Focus on understanding the key concepts.")
    
    st.write("---")
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("📝 Practice Another Document", type="primary"):
            reset_quiz()
            st.rerun()
    with col2:
        if st.button("📤 Upload New PDFs"):
            st.session_state.app_state = "UPLOAD"
            st.rerun()


def main():
    st.set_page_config(
        page_title="PDF Quiz Generator",
        page_icon="📚",
        layout="centered"
    )
    
    initialize_state()
    
    # State machine
    if st.session_state.app_state == "UPLOAD":
        show_upload_page()
    elif st.session_state.app_state == "MENU":
        show_menu()
    elif st.session_state.app_state == "QUIZ":
        show_quiz_question()
    elif st.session_state.app_state == "RESULTS":
        show_results()


if __name__ == "__main__":
    main()