from _future_ import annotations

import time
import random
import re
from typing import List, Optional, Tuple, Dict, Callable, Any

# -----------------------------------------------------------------------------
# Constants and configuration
# -----------------------------------------------------------------------------
DIFF: Dict[str, Dict[str, Any]] = {
    "easy": {
        "math_range": (1, 10),
        "phys_s": (50, 200),
        "phys_t": (6, 20),
        "time": 60,
    },
    "medium": {
        "math_range": (5, 20),
        "phys_s": (100, 400),
        "phys_t": (4, 16),
        "time": 45,
    },
    "hard": {
        "math_range": (10, 40),
        "phys_s": (200, 800),
        "phys_t": (3, 12),
        "time": 30,
    },
}

SUBJECT_ALIASES: Dict[str, str] = {
    "math": "mathematics",
    "make": "mathematics",
    "mat": "mathematics",
    "fmath": "further mathematics",
    "further math": "further mathematics",
    "fm": "further mathematics",
    "bio": "biology",
    "chem": "chemistry",
    "ict": "ict",
    "physics": "physics",
    "physicss": "physics",
}

GeneratorFunc = Callable[[str], List["Question"]]
SUBJECTS: Dict[str, GeneratorFunc] = {}  # populated below

# -----------------------------------------------------------------------------
# Utility helpers
# -----------------------------------------------------------------------------
def is_number(s: str) -> bool:
    try:
        float(s)
        return True
    except Exception:
        return False


def normalize_mcq_answer(ans: str) -> str:
    if not ans:
        return ""
    cleaned = ans.strip()
    if not cleaned:
        return ""
    m = re.match(r"^([A-Da-d])[\.\)]?\s*$", cleaned)
    if m:
        return m.group(1).upper()
    m2 = re.search(r"\b([A-Da-d])\b", cleaned)
    if m2 and len(cleaned) <= 3:
        return m2.group(1).upper()
    return cleaned.lower()


def compare_short_answer(expected: str, user: str) -> bool:
    e = expected.strip().lower()
    u = user.strip().lower()
    if is_number(e) and is_number(u):
        try:
            return abs(float(e) - float(u)) <= 1e-6
        except Exception:
            pass
    def clean(x: str) -> str:
        return "".join(ch for ch in x if ch.isalnum() or ch.isspace()).strip()
    return clean(e) == clean(u)


def make_mcq_options(correct: Any, wrongs: List[Any]) -> Tuple[List[str], str]:
    labels = list("ABCD")
    pool = [correct] + (wrongs[:3] if wrongs else [])
    while len(pool) < 4:
        pool.append(random.choice(pool))
    random.shuffle(pool)
    option_texts = [f"{lab}. {val}" for lab, val in zip(labels, pool)]
    for i, val in enumerate(pool):
        if val == correct:
            correct_label = labels[i]
            break
    else:
        correct_label = "A"
    return option_texts, correct_label


# -----------------------------------------------------------------------------
# Question model
# -----------------------------------------------------------------------------
class Question:
    def _init_(
        self,
        subject: str,
        year: int,
        number: str,
        qtype: str,
        text: str,
        options: Optional[List[str]],
        answer: str,
        explanation: str,
    ) -> None:
        self.subject = subject
        self.year = year
        self.number = number
        self.qtype = qtype
        self.text = text
        self.options = options
        self.answer = answer
        self.explanation = explanation

    def _repr_(self) -> str:
        return f"<Question {self.subject} #{self.number} {self.qtype}>"


# -----------------------------------------------------------------------------
# Very-detailed explanation generator
# -----------------------------------------------------------------------------
def generate_detailed_explanation(q: Question, user_input: str) -> str:
    """
    Produces a very detailed explanation for a question q when the user is wrong.
    The output contains:
      - Step-by-step worked solution (where applicable)
      - Unit checks / dimensional analysis hints (for physics/chemistry)
      - Common mistakes to watch out for
      - Quick verification (how to check the answer)
      - Short study plan / tips
    Falls back to q.explanation + study tips when pattern not recognized.
    """
    user_trim = user_input.strip()
    expected = q.answer
    lines: List[str] = []
    header = f"Expected answer: {expected}."
    # MCQ: show correct option with rationale and common distractor traps
    if q.qtype == "mcq" and q.options:
        try:
            corr_label = q.answer[0].upper()
            idx = "ABCD".index(corr_label)
            corr_text = q.options[idx].split(".", 1)[-1].strip()
        except Exception:
            corr_label = "A"
            corr_text = str(expected)
        lines.append(f"Correct option: {corr_label}. {corr_text}")
        # Give short rationale depending on known templates in text
        txt = q.text.lower()
        if "speed" in txt or "distance" in txt or "time" in txt:
            lines.append("Rationale: Use the relation speed = distance / time (v = s/t).")
            lines.append("Common mistake: mixing up units (e.g., m with km) or using v = s * t by accident.")
            lines.append("Check: Plug the candidate option into the formula and see which matches.")
        elif "photosynthesis" in txt or "chloroplast" in txt:
            lines.append("Rationale: Chloroplasts contain chlorophyll and run photosynthesis.")
            lines.append("Common mistake: confusing chloroplast (site of photosynthesis) with mitochondrion (site of respiration).")
        elif "bond" in txt or "nacl" in txt:
            lines.append("Rationale: NaCl forms ionic bonds (metal + non-metal, electron transfer).")
            lines.append("Common mistake: thinking all compounds are covalent — check metal/non-metal.")
        else:
            lines.append(f"Short rationale: {q.explanation}")
        # Add verification + study plan
        lines.append("How to verify: write the formula / definition and substitute numbers or keywords.")
        lines.append("Study tips: revisit the formula/definition in your notes and practise 3 similar problems.")
        return "\n".join([header] + lines)

    text = q.text.strip()

    # --- Linear equation pattern: "Solve for x: ax + b = c" or variants ---
    m = re.search(r"Solve\s*for\s*x[:\s]([+-]?\d+)\s*x\s([+-]\s*\d+)?\s*=\s*([+-]?\d+)", text.replace(" ", ""))
    if not m:
        # loosen pattern: detect "ax + b = c" in the text
        m = re.search(r"([+-]?\d+)x([+-]?\d+)?=([+-]?\d+)", text.replace(" ", ""))
    if m:
        try:
            a = int(m.group(1))
            b_raw = m.group(2) or "0"
            b = int(b_raw.replace(" ", ""))
            c = int(m.group(3))
            lines.append("Worked solution (linear equation):")
            lines.append(f"1) Start with: {a}x + ({b}) = {c}")
            lines.append(f"2) Subtract {b} from both sides → {a}x = {c} - ({b}) = {c - b}")
            numerator = c - b
            lines.append(f"3) Divide both sides by {a} → x = {numerator} / {a}")
            x_val = numerator / a
            if float(x_val).is_integer():
                x_display = str(int(x_val))
            else:
                x_display = str(round(x_val, 6))
            lines.append(f"Final: x = {x_display}")
            # Add checks and common mistakes
            lines.append("Check: substitute x back into the original equation to see both sides equal.")
            lines.append("Common mistakes:")
            lines.append(" - Forgetting to subtract b (sign errors).")
            lines.append(" - Dividing by zero if a = 0 (check coefficient).")
            lines.append("Quick verification: compute a*x + b and compare to c.")
            lines.append("Study plan: practise solving 10 linear equations; focus on sign handling.")
            return "\n".join([header] + lines)
        except Exception:
            pass

    # --- Arithmetic: add / sub / mul / div / power ---
    m_add = re.match(r"Evaluate:\s*([+-]?\d+)\s*\+\s*([+-]?\d+)", text)
    if m_add:
        p = int(m_add.group(1)); qv = int(m_add.group(2))
        calc = p + qv
        lines.append("Worked arithmetic (addition):")
        lines.append(f"{p} + {qv} = {calc}")
        lines.append("Common mistakes: digit-by-digit errors, not aligning place values.")
        lines.append("Check: do the reverse (result - one addend = other addend).")
        lines.append("Study plan: practise column addition and mental math.")
        return "\n".join([header] + lines)

    m_sub = re.match(r"Evaluate:\s*([+-]?\d+)\s*-\s*([+-]?\d+)", text)
    if m_sub:
        p = int(m_sub.group(1)); qv = int(m_sub.group(2))
        calc = p - qv
        lines.append("Worked arithmetic (subtraction):")
        lines.append(f"{p} - {qv} = {calc}")
        lines.append("Common mistakes: sign errors or borrowing mistakes.")
        lines.append("Check: result + subtracted = original number.")
        lines.append("Study plan: practise subtraction with negatives and borrowing.")
        return "\n".join([header] + lines)

    m_mul = re.match(r"Evaluate:\s*([+-]?\d+)\s*[×x\]\s([+-]?\d+)", text)
    if m_mul:
        p = int(m_mul.group(1)); qv = int(m_mul.group(2))
        calc = p * qv
        lines.append("Worked arithmetic (multiplication):")
        lines.append(f"{p} × {qv} = {calc}")
        lines.append("Common mistakes: misplacing zeros or multiplying digits incorrectly.")
        lines.append("Check: divide the product by one factor to retrieve the other.")
        lines.append("Study plan: practise multiplication tables and long multiplication.")
        return "\n".join([header] + lines)

    m_div = re.match(r"Evaluate:\s*([+-]?\d+)\s*[÷/]\s*([+-]?\d+)", text)
    if m_div:
        p = int(m_div.group(1)); qv = int(m_div.group(2))
        if qv == 0:
            lines.append("Division by zero is undefined. Check the question.")
            return "\n".join([header] + lines)
        calc = p / qv
        lines.append("Worked arithmetic (division):")
        if float(calc).is_integer():
            lines.append(f"{p} ÷ {qv} = {int(calc)}")
        else:
            lines.append(f"{p} ÷ {qv} = {calc} (rounded)")
        lines.append("Common mistakes: reversing dividend/divisor, losing remainders.")
        lines.append("Check: multiply quotient by divisor, add remainder (if any).")
        lines.append("Study plan: practise long division and converting remainders to decimals.")
        return "\n".join([header] + lines)

    m_pow = re.match(r"Evaluate:\s*([+-]?\d+)\s*\^\s*([+-]?\d+)", text) or re.match(r"Evaluate:\s*([+-]?\d+)\^([+-]?\d+)", text)
    if m_pow:
        base_v = int(m_pow.group(1)); exp_v = int(m_pow.group(2))
        val = base_v ** exp_v
        lines.append("Worked arithmetic (power):")
        lines.append(f"{base_v}^{exp_v} = {val}")
        lines.append("Common mistakes: wrong exponent or missing multiplication repeated.")
        lines.append("Check: multiply base by itself exponent times or use logarithms.")
        lines.append("Study plan: practise powers and exponent rules (product/power rules).")
        return "\n".join([header] + lines)

    # --- Physics templates ---
    if re.search(r"speed|distance|time", text.lower()):
        # detect numeric s,t,v patterns
        m1 = re.search(r"travels\s*([+-]?\d+)\s*m\s*in\s*([+-]?\d+)\s*s", text)
        m2 = re.search(r"moves at\s*([+-]?\d+)\s*m/s\s*for\s*([+-]?\d+)\s*s", text)
        m3 = re.search(r"covers\s*([+-]?\d+)\s*m\s*at\s*([+-]?\d+)\s*m/s", text)
        if m1:
            s = int(m1.group(1)); t = int(m1.group(2))
            v = s / t
            lines.append("Worked physics (speed):")
            lines.append("Formula: speed = distance / time (v = s/t).")
            lines.append(f"Substitute: v = {s} / {t} = {v} m/s.")
            lines.append("Units: m/s — confirm distance (m) and time (s) are consistent.")
            lines.append("Common mistakes: using s*t or forgetting to convert units.")
            lines.append("Check: multiply v × t to get back distance s.")
            lines.append("Study plan: practise v = s/t questions and unit conversions (km→m, h→s).")
            return "\n".join([header] + lines)
        if m2:
            v = int(m2.group(1)); t = int(m2.group(2))
            s = v * t
            lines.append("Worked physics (distance):")
            lines.append("Formula: distance = speed × time (s = v × t).")
            lines.append(f"Compute: s = {v} × {t} = {s} m.")
            lines.append("Check units and common mistakes (mixing km/h with m/s).")
            lines.append("Study plan: practise converting units and solving for s, v, t.")
            return "\n".join([header] + lines)
        if m3:
            s = int(m3.group(1)); v = int(m3.group(2))
            t = s / v
            lines.append("Worked physics (time):")
            lines.append("Formula: time = distance / speed (t = s / v).")
            lines.append(f"Compute: t = {s} / {v} = {round(t, 6)} s.")
            lines.append("Check by recomputing s = v × t.")
            lines.append("Common mistakes: reversing formula or unit mismatch.")
            return "\n".join([header] + lines)

    # momentum, density, acceleration, work
    if "momentum" in text.lower() or re.search(r"mass.*kg.*m/s|momentum", text.lower()):
        m = re.search(r"mass\s*([+-]?\d+)\s*kg.at\s([+-]?\d+)\s*m/s", text)
        if m:
            mv = int(m.group(1)); vv = int(m.group(2))
            p = mv * vv
            lines.append("Worked physics (momentum):")
            lines.append("Formula: momentum p = mass × velocity (p = m × v).")
            lines.append(f"Compute: p = {mv} × {vv} = {p} kg·m/s.")
            lines.append("Units: kg·m/s. Check: make sure mass in kg and velocity in m/s.")
            lines.append("Study plan: practise p = m v problems and unit checking.")
            return "\n".join([header] + lines)
    if "density" in text.lower():
        m = re.search(r"mass\s*([+-]?\d+)\s*g.volume\s([+-]?\d+)\s*cm", text)
        if m:
            mass = int(m.group(1)); vol = int(m.group(2))
            rho = round(mass / vol, 4)
            lines.append("Worked physics/chemistry (density):")
            lines.append("Formula: density = mass / volume.")
            lines.append(f"Compute: ρ = {mass} / {vol} = {rho} g/cm^3.")
            lines.append("Unit hint: mass in g and volume in cm^3 gives g/cm^3; convert if needed.")
            lines.append("Common mistakes: mixing units (g vs kg, cm^3 vs m^3).")
            lines.append("Study plan: practise unit conversions and density problems.")
            return "\n".join([header] + lines)
    if "acceleration" in text.lower() or "velocity increases" in text.lower():
        m = re.search(r"Velocity increases by\s*([+-]?\d+)\s*m/s in\s*([+-]?\d+)\s*s", text)
        if m:
            dv = int(m.group(1)); dt = int(m.group(2)); a = round(dv / dt, 6)
            lines.append("Worked physics (acceleration):")
            lines.append("Formula: acceleration = change in velocity / time (a = Δv / Δt).")
            lines.append(f"Compute: a = {dv} / {dt} = {a} m/s^2.")
            lines.append("Check: units m/s^2, and try re-multiplying a × Δt to recover Δv.")
            lines.append("Common mistakes: confusing average acceleration with instantaneous.")
            return "\n".join([header] + lines)
    if "work" in text.lower() or "force" in text.lower():
        m = re.search(r"force of\s*([+-]?\d+)\s*N.moves.?([+-]?\d+)\s*m", text)
        if m:
            F = int(m.group(1)); d = int(m.group(2)); W = F * d
            lines.append("Worked physics (work):")
            lines.append("Formula: work = force × distance (W = F × d).")
            lines.append(f"Compute: W = {F} × {d} = {W} J.")
            lines.append("Units: joules (N·m).")
            lines.append("Common mistakes: using weight instead of applied force or wrong distance units.")
            return "\n".join([header] + lines)

    # --- Chemistry: moles & balancing ---
    if "moles" in text.lower() or "molar mass" in text.lower():
        m = re.search(r"Calculate moles in\s*([+-]?\d+)\s*g.molar mass\s([+-]?\d+)", text)
        if m:
            mass = int(m.group(1)); Mr = int(m.group(2))
            n = round(mass / Mr, 6)
            lines.append("Worked chemistry (moles):")
            lines.append("Formula: moles = mass / molar mass (n = m / M).")
            lines.append(f"Compute: n = {mass} / {Mr} = {n} mol.")
            lines.append("Units: mass (g) divided by g/mol gives mol.")
            lines.append("Common mistakes: forgetting to convert mass units (kg → g) or using wrong Mr.")
            lines.append("Study plan: practise converting grams ↔ moles and calculating Mr from formula.")
            return "\n".join([header] + lines)
    if "balance" in text.lower():
        lines.append("Balancing chemical equations: identify element counts on both sides and add coefficients to equalize them.")
        lines.append("Example: 2 H2 + O2 → 2 H2O balances hydrogen and oxygen.")
        lines.append("Study plan: practise balancing simple combustion and synthesis equations.")
        return "\n".join([header] + lines)

    # --- Further mathematics: differentiation / integration / determinants ---
    if re.search(r"differentiate|dy/dx|derivative", text.lower()):
        m = re.search(r"Differentiate\s*y\s*=\s*([0-9]+)x\^([0-9]+)", text.replace(" ", ""))
        if m:
            a = int(m.group(1)); n = int(m.group(2))
            deriv = f"{a*n}x^{n-1}"
            lines.append("Worked calculus (differentiation by power rule):")
            lines.append("Rule: d/dx[x^n] = n x^(n-1).")
            lines.append(f"If y = {a}x^{n} then dy/dx = {a*n}x^{n-1}.")
            lines.append("Common mistakes: not multiplying the coefficient by n or reducing power incorrectly.")
            return "\n".join([header] + lines)
    if re.search(r"Integrate|∫", text):
        m = re.search(r"Integrate.*?([0-9]+)x\^([0-9]+)", text.replace(" ", ""))
        if m:
            a = int(m.group(1)); n = int(m.group(2))
            res = f"{a/(n+1)}x^{n+1} + C"
            lines.append("Worked calculus (integration by reverse power rule):")
            lines.append("Rule: ∫ x^n dx = x^(n+1)/(n+1) + C for n ≠ -1.")
            lines.append(f"Apply: ∫ {a}x^{n} dx = {res}.")
            lines.append("Check by differentiating the result.")
            return "\n".join([header] + lines)
    if "determinant" in text.lower():
        m = re.search(r"Find det \|([0-9]+) ([0-9]+); ([0-9]+) ([0-9]+)\|", text.replace(" ", ""))
        if m:
            a,b,c,d = map(int, m.groups())
            det = a*d - b*c
            lines.append("Worked matrices (2×2 determinant):")
            lines.append("Rule: det|a b; c d| = a·d − b·c.")
            lines.append(f"Compute: {a}×{d} − {b}×{c} = {det}.")
            lines.append("Study plan: practise determinants and matrix operations.")
            return "\n".join([header] + lines)

    # --- Biology / ICT conceptual answers ---
    if q.subject.lower() == "biology" or "define" in text.lower() or "what is" in text.lower():
        lines.append("Conceptual explanation:")
        lines.append(q.explanation if q.explanation else "Review the textbook definition and key features.")
        lines.append("Tip: for definitions use concise phrasing and include one key detail or example.")
        lines.append("Study plan: memorise core definitions and write 3 short examples each.")
        return "\n".join([header] + lines)
    if q.subject.lower() == "ict" or "ip address" in text.lower() or "file type" in text.lower():
        lines.append("Conceptual/technical explanation:")
        lines.append(q.explanation if q.explanation else "Refer to ICT notes for definitions and examples.")
        lines.append("Tip: learn short phrases (e.g., 'IP = device address', 'PDF = portable document format').")
        return "\n".join([header] + lines)

    # --- AP sum and sequences ---
    if "sum of ap" in text.lower() or "sum of ap" in q.explanation.lower() or "S_n" in text:
        m = re.search(r"a\s*=\s*([+-]?\d+).d\s=\s*([+-]?\d+).n\s=\s*([+-]?\d+)", text.replace(" ", ""))
        if m:
            a, d, n = int(m.group(1)), int(m.group(2)), int(m.group(3))
            Sn = n / 2 * (2 * a + (n - 1) * d)
            lines.append("Worked arithmetic progression (AP) sum:")
            lines.append("Formula: S_n = n/2 [2a + (n − 1)d].")
            lines.append(f"Compute: S_n = {n}/2 [2×{a} + ({n}−1)×{d}] = {Sn}.")
            lines.append("Check: compute first few terms and sum directly for small n.")
            return "\n".join([header] + lines)

    # --- Fallback: give generator explanation plus study resources ---
    lines.append("Detailed explanation (fallback):")
    if q.explanation:
        lines.append(q.explanation)
    else:
        lines.append("No worked steps available for this template; review relevant formulas.")
    lines.append("How to practice:")
    lines.append("- Re-do similar problems from your notes or past questions.")
    lines.append("- Write the formula you need on top of your working space before calculating.")
    lines.append("- Check units and substitute back to verify answers.")
    lines.append("If you'd like a step-by-step worked example for this exact problem type, ask 'explain more' or request a similar sample problem.")
    return "\n".join([header] + lines)


# -----------------------------------------------------------------------------
# Dataset generators (same as before)
# -----------------------------------------------------------------------------
def gen_mathematics(difficulty: str) -> List[Question]:
    lo, hi = DIFF[difficulty]["math_range"]  # type: ignore
    subject = "Mathematics"
    year = 2025
    pool: List[Question] = []
    for i in range(1, 301):
        a = random.randint(2, 9)
        x = random.randint(-hi, hi)
        b = random.randint(-hi, hi)
        c = a * x + b
        text = f"Solve for x: {a}x + {b} = {c}"
        correct = x
        wrongs = [x + 1, x - 1, x + 2]
        options, label = make_mcq_options(correct, wrongs)
        pool.append(Question(subject, year, str(i), "mcq", text, options, label, "Rearrange and solve for x."))
    for i in range(301, 601):
        kind = random.choice(["add", "sub", "mul", "div", "pow"])
        if kind == "add":
            p = random.randint(lo, hi * 2)
            q = random.randint(lo, hi * 2)
            text = f"Evaluate: {p} + {q}"
            answer = str(p + q)
            expl = f"{p} + {q} = {p + q}"
        elif kind == "sub":
            p = random.randint(lo, hi * 2)
            q = random.randint(1, hi)
            text = f"Evaluate: {p} - {q}"
            answer = str(p - q)
            expl = f"{p} - {q} = {p - q}"
        elif kind == "mul":
            p = random.randint(2, hi)
            q = random.randint(2, hi)
            text = f"Evaluate: {p} × {q}"
            answer = str(p * q)
            expl = f"{p} × {q} = {p * q}"
        elif kind == "div":
            q = random.randint(2, 12)
            a = random.randint(2, 12)
            p = q * a
            text = f"Evaluate: {p} ÷ {q}"
            answer = str(a)
            expl = f"{p} ÷ {q} = {a}"
        else:
            base = random.randint(2, 6)
            exp = random.randint(2, 4 if difficulty != "hard" else 5)
            text = f"Evaluate: {base}^{exp}"
            answer = str(base ** exp)
            expl = f"{base}^{exp} = {base ** exp}"
        pool.append(Question(subject, year, str(i), "short", text, None, answer, expl))
    return pool


def gen_physics(difficulty: str) -> List[Question]:
    s_lo, s_hi = DIFF[difficulty]["phys_s"]  # type: ignore
    t_lo, t_hi = DIFF[difficulty]["phys_t"]  # type: ignore
    subject = "Physics"
    year = 2025
    pool: List[Question] = []
    for i in range(1, 301):
        mode = random.choice(["v", "s", "t"])
        if mode == "v":
            s = random.randint(s_lo, s_hi)
            t = random.randint(t_lo, t_hi)
            v = round(s / t, 2)
            text = f"A body travels {s} m in {t} s. What is its speed (m/s)?"
            correct = v
            wrongs = [round(v + d, 2) for d in (1.0, -1.0, 2.0)]
            options, label = make_mcq_options(correct, wrongs)
            expl = "v = s / t"
        elif mode == "s":
            v = random.randint(2, 50)
            t = random.randint(t_lo, t_hi)
            s = v * t
            text = f"An object moves at {v} m/s for {t} s. Distance (m)?"
            correct = s
            wrongs = [s + 10, s - 10, s + 20]
            options, label = make_mcq_options(correct, wrongs)
            expl = "s = v × t"
        else:
            s = random.randint(s_lo, s_hi)
            v = random.randint(2, 50)
            t = round(s / v, 2)
            text = f"A runner covers {s} m at {v} m/s. Time (s)?"
            correct = t
            wrongs = [round(t + d, 2) for d in (1.0, -1.0, 2.0)]
            options, label = make_mcq_options(correct, wrongs)
            expl = "t = s / v"
        pool.append(Question(subject, year, str(i), "mcq", text, options, label, expl))
    for i in range(301, 601):
        typ = random.choice(["unit", "momentum", "density", "acceleration", "work"])
        if typ == "unit":
            qname, unit = random.choice(
                [
                    ("force", "newton"),
                    ("work", "joule"),
                    ("power", "watt"),
                    ("energy", "joule"),
                    ("charge", "coulomb"),
                    ("current", "ampere"),
                    ("voltage", "volt"),
                    ("resistance", "ohm"),
                    ("frequency", "hertz"),
                    ("pressure", "pascal"),
                    ("temperature", "kelvin"),
                ]
            )
            text = f"State the SI unit of {qname}."
            answer = unit
            expl = f"The SI unit of {qname} is the {unit}."
        elif typ == "momentum":
            m = random.randint(1, 20)
            v = random.randint(1, 30)
            p = m * v
            text = f"A body of mass {m} kg moves at {v} m/s. Compute its momentum (kg·m/s)."
            answer = str(p)
            expl = f"p = m v = {m} × {v} = {p}"
        elif typ == "density":
            mass = random.randint(100, 2000)
            vol = random.randint(50, 500)
            rho = round(mass / vol, 2)
            text = f"A material has mass {mass} g and volume {vol} cm^3. Compute its density (g/cm^3)."
            answer = str(rho)
            expl = f"ρ = m / V = {mass} / {vol} = {rho}"
        elif typ == "acceleration":
            dv = random.randint(2, 30)
            dt = random.randint(1, 10)
            a = round(dv / dt, 2)
            text = f"Velocity increases by {dv} m/s in {dt} s. Calculate acceleration (m/s^2)."
            answer = str(a)
            expl = f"a = Δv / Δt = {dv} / {dt} = {a}"
        else:
            F = random.randint(5, 80)
            d = random.randint(1, 20)
            w = F * d
            text = f"A force of {F} N moves an object {d} m. Work done (J)?"
            answer = str(w)
            expl = f"W = F d = {F} × {d} = {w}"
        pool.append(Question(subject, year, str(i), "short", text, None, answer, expl))
    return pool


def gen_ict(_: str) -> List[Question]:
    subject = "ICT"
    year = 2025
    pool: List[Question] = []
    for i in range(1, 301):
        kind = random.choice(["unit", "network", "file", "storage", "email"])
        if kind == "unit":
            name, desc = random.choice(
                [
                    ("bit", "smallest unit of data"),
                    ("byte", "8 bits"),
                    ("kilobyte", "1024 bytes"),
                    ("megabyte", "1024 KB"),
                    ("gigabyte", "1024 MB"),
                ]
            )
            text = f"What best describes '{name}' in computing?"
            options, label = make_mcq_options(desc, ["a malware type", "programming language", "temporary register"])
            expl = f"{name} → {desc}."
        elif kind == "network":
            abbrev, meaning = random.choice([("LAN", "local area network"), ("WAN", "wide area network"), ("MAN", "metropolitan area network")])
            text = f"In networking, {abbrev} stands for what?"
            options, label = make_mcq_options(meaning, ["wireless access node", "wide adapter network", "multiple access network"])
            expl = f"{abbrev}: {meaning}."
        elif kind == "file":
            ext, desc = random.choice([("docx", "Word document"), ("xlsx", "Spreadsheet"), ("pptx", "Presentation"), ("jpg", "Image"), ("pdf", "Portable document")])
            text = f"Which best describes the .{ext} file type?"
            options, label = make_mcq_options(desc, ["Database", "Executable", "Audio"])
            expl = f".{ext} → {desc}."
        elif kind == "storage":
            text = "Which is an optical storage device?"
            options, label = make_mcq_options("DVD", ["SSD", "HDD", "Flash drive"])
            expl = "DVD uses optical media."
        else:
            text = "Unsolicited bulk email messages are commonly called __."
            options, label = make_mcq_options("Spam", ["Cache", "Cookie", "Phishing"])
            expl = "Spam = unwanted bulk email."
        pool.append(Question(subject, year, str(i), "mcq", text, options, label, expl))
    for i in range(301, 601):
        typ = random.choice(["ip", "sum", "db", "security", "cellref"])
        if typ == "ip":
            text = "State the purpose of an IP address."
            answer = "Uniquely identifies a device on a network"
            expl = "IP addresses enable routing between devices."
        elif typ == "sum":
            text = "Spreadsheet formula to add A1 through A10."
            answer = "=SUM(A1:A10)"
            expl = "SUM(range) adds the values in that range."
        elif typ == "db":
            text = "One advantage of using a database over a spreadsheet."
            answer = "Better data integrity / relationships"
            expl = "Databases support constraints and relationships."
        elif typ == "security":
            text = "State one method to secure a computer."
            answer = "Use strong passwords / antivirus / firewall"
            expl = "Multiple methods reduce risk of compromise."
        else:
            text = "What is a cell reference in a spreadsheet?"
            answer = "Address of a cell (e.g., B2)"
            expl = "References identify the location of data."
        pool.append(Question(subject, year, str(i), "short", text, None, answer, expl))
    return pool


def gen_further_mathematics(difficulty: str) -> List[Question]:
    subject = "Further Mathematics"
    year = 2025
    pool: List[Question] = []
    for i in range(1, 301):
        typ = random.choice(["differentiate", "integrate", "determinant", "dot"])
        if typ == "differentiate":
            a = random.randint(1, 6)
            n = random.randint(2, (5 if difficulty != "hard" else 6))
            text = f"Differentiate y = {a}x^{n}."
            correct = f"{a * n}x^{n - 1}"
            options, label = make_mcq_options(correct, [f"{a}x^{n-1}", f"{a}x^{n}", f"{a*(n+1)}x^{n}"])
            expl = "Power rule: d/dx x^n = n x^{n-1}"
        elif typ == "integrate":
            a = random.randint(1, 6)
            n = random.randint(1, 4 if difficulty == "easy" else 5)
            text = f"Integrate ∫ {a}x^{n} dx."
            correct = f"{a / (n + 1)}x^{n + 1} + C"
            options, label = make_mcq_options(correct, [f"{a*n}x^{n-1}+C", f"{a}ln x + C", f"{a}x^{n}+C"])
            expl = "Reverse power rule"
        elif typ == "determinant":
            p, q, r, s = [random.randint(1, 7) for _ in range(4)]
            det = p * s - q * r
            text = f"Find det |{p} {q}; {r} {s}|."
            correct = str(det)
            options, label = make_mcq_options(correct, [str(det + 1), str(det - 1), str(det + 2)])
            expl = "Determinant of 2x2 matrix: ad - bc"
        else:
            ax, ay, bx, by = [random.randint(-5, 5) for _ in range(4)]
            dot = ax * bx + ay * by
            text = f"a = ({ax},{ay}), b = ({bx},{by}). What is a·b?"
            correct = str(dot)
            options, label = make_mcq_options(correct, [str(dot + 1), str(dot - 1), str(dot + 2)])
            expl = "Dot product = ax*bx + ay*by"
        pool.append(Question(subject, year, str(i), "mcq", text, options, label, expl))
    for i in range(301, 601):
        typ = random.choice(["gradient", "vector_sum", "ap_sum"])
        if typ == "gradient":
            a = random.randint(1, 6)
            n = random.randint(2, 6)
            text = f"If y = {a}x^{n}, find dy/dx."
            answer = f"{a * n}x^{n - 1}"
            expl = "Use power rule"
        elif typ == "vector_sum":
            ax, ay, bx, by = [random.randint(-6, 6) for _ in range(4)]
            sx, sy = ax + bx, ay + by
            text = f"If a = ({ax},{ay}) and b = ({bx},{by}), find a + b."
            answer = f"({sx}, {sy})"
            expl = "Add components"
        else:
            a = random.randint(1, 5)
            d = random.randint(1, 5)
            n = random.randint(3, 8)
            Sn = n / 2 * (2 * a + (n - 1) * d)
            text = f"Sum of AP with a = {a}, d = {d}, n = {n}. Find S_n."
            answer = str(Sn)
            expl = "Use S_n = n/2 [2a + (n-1)d]"
        pool.append(Question(subject, year, str(i), "short", text, None, answer, expl))
    return pool


def gen_chemistry(difficulty: str) -> List[Question]:
    subject = "Chemistry"
    year = 2025
    pool: List[Question] = []
    for i in range(1, 301):
        typ = random.choice(["bond", "acid", "group"])
        if typ == "bond":
            text = "What type of bond exists in NaCl?"
            options, label = make_mcq_options("Ionic", ["Covalent", "Metallic", "Hydrogen"])
            expl = "NaCl is ionic (Na+ Cl-)"
        elif typ == "acid":
            text = "Which of these is a strong acid?"
            options, label = make_mcq_options("HCl", ["CH3COOH", "NH3", "H2O"])
            expl = "HCl is a strong acid"
        else:
            text = "Noble gases belong to which group?"
            options, label = make_mcq_options("Group 18", ["Group 1", "Group 7", "Group 2"])
            expl = "Noble gases are in Group 18"
        pool.append(Question(subject, year, str(i), "mcq", text, options, label, expl))
    for i in range(301, 601):
        typ = random.choice(["moles", "valency", "ph", "balance"])
        if typ == "moles":
            m = random.randint(10, 100)
            Mr = random.choice([18, 44, 58])
            n = round(m / Mr, 2)
            text = f"Calculate moles in {m} g with molar mass {Mr} g/mol."
            answer = str(n)
            expl = f"n = m / M = {m} / {Mr} = {n}"
        elif typ == "valency":
            el, va = random.choice([("O", "2"), ("N", "3"), ("Cl", "1")])
            text = f"State the valency of {el}."
            answer = va
            expl = f"{el} commonly has valency {va}"
        elif typ == "ph":
            text = "Define pH."
            answer = "Measure of hydrogen ion concentration"
            expl = "pH indicates acidity/alkalinity"
        else:
            text = "Balance: _ H2 + _ O2 → _ H2O"
            answer = "2, 1, 2"
            expl = "2H2 + O2 → 2H2O"
        pool.append(Question(subject, year, str(i), "short", text, None, answer, expl))
    return pool


def gen_biology(difficulty: str) -> List[Question]:
    subject = "Biology"
    year = 2025
    pool: List[Question] = []
    for i in range(1, 301):
        typ = random.choice(["cell", "photo", "resp", "eco"])
        if typ == "cell":
            text = "Powerhouse of the cell is the __."
            options, label = make_mcq_options("Mitochondrion", ["Nucleus", "Ribosome", "Golgi body"])
            expl = "Mitochondria release energy via respiration"
        elif typ == "photo":
            text = "Photosynthesis occurs mainly in the __."
            options, label = make_mcq_options("Chloroplast", ["Mitochondrion", "Nucleus", "Lysosome"])
            expl = "Chloroplasts contain chlorophyll"
        elif typ == "resp":
            text = "End products of aerobic respiration include __."
            options, label = make_mcq_options("CO2 and H2O", ["Alcohol only", "Lactic acid only", "O2 and glucose"])
            expl = "Aerobic respiration yields carbon dioxide and water"
        else:
            text = "A feeding relationship showing who eats whom is a __."
            options, label = make_mcq_options("Food chain", ["Trophic level", "Habitat", "Niche"])
            expl = "A food chain shows feeding relationships"
        pool.append(Question(subject, year, str(i), "mcq", text, options, label, expl))
    for i in range(301, 601):
        typ = random.choice(["diff", "osmosis", "transpiration", "classification"])
        if typ == "diff":
            text = "Define diffusion."
            answer = "Movement of particles from high to low concentration"
            expl = "Occurs down a concentration gradient"
        elif typ == "osmosis":
            text = "Define osmosis."
            answer = "Movement of water through a semipermeable membrane from dilute to concentrated solution"
            expl = "Water moves along water potential gradient"
        elif typ == "transpiration":
            text = "What is transpiration?"
            answer = "Loss of water vapour from plant leaves"
            expl = "Occurs via stomata and cuticle"
        else:
            text = "Name the five kingdoms."
            answer = "Monera, Protista, Fungi, Plantae, Animalia"
            expl = "Five-kingdom classification"
        pool.append(Question(subject, year, str(i), "short", text, None, answer, expl))
    return pool


# register generators
SUBJECTS = {
    "mathematics": gen_mathematics,
    "physics": gen_physics,
    "ict": gen_ict,
    "further mathematics": gen_further_mathematics,
    "chemistry": gen_chemistry,
    "biology": gen_biology,
}


# -----------------------------------------------------------------------------
# Tutor engine (unchanged aside from using the new generate_detailed_explanation)
# -----------------------------------------------------------------------------
class Tutor:
    def _init_(self, questions: List[Question], time_limit_s: int) -> None:
        self.questions = questions
        self.time_limit = time_limit_s
        self.score = 0
        self.total = 0
        self.missed: List[Question] = []
        self.elapsed_times: List[float] = []
        self.timed_out = 0

    def pick_questions(self, mcq_count: int, theory_count: int) -> Optional[List[Question]]:
        mcq_pool = [q for q in self.questions if q.qtype == "mcq"]
        short_pool = [q for q in self.questions if q.qtype == "short"]
        if mcq_count > len(mcq_pool) or theory_count > len(short_pool):
            print(f"Not enough questions available: MCQ available={len(mcq_pool)}, theory available={len(short_pool)}.")
            return None
        random.shuffle(mcq_pool)
        random.shuffle(short_pool)
        return mcq_pool[:mcq_count] + short_pool[:theory_count]

    def run_quiz(self, selected: List[Question]) -> None:
        print("\nQuiz started. Commands: 'hint' (MCQ), 'skip', 'quit'\n")
        for i, q in enumerate(selected, start=1):
            print(f"Q{i}. [{q.subject} #{q.number}] {q.text}")
            if q.qtype == "mcq" and q.options:
                for opt in q.options:
                    print("  " + opt)
            start = time.time()
            user_input = input("Your answer: ").strip()
            elapsed = time.time() - start
            self.elapsed_times.append(elapsed)
            if user_input.lower() in ("quit", "exit"):
                print("Quiz aborted by user.")
                break
            if elapsed > self.time_limit:
                print(f"⏱ Time up! You took {elapsed:.1f}s > limit {self.time_limit}s.")
                print(generate_detailed_explanation(q, ""))
                self.total += 1
                self.timed_out += 1
                self.missed.append(q)
                continue
            if user_input.lower() == "skip":
                print(f"Skipped. Correct: {q.answer}\nExplanation: {q.explanation}\n")
                self.total += 1
                self.missed.append(q)
                continue
            if user_input.lower() == "hint":
                if q.qtype == "mcq" and q.options:
                    correct_label = q.answer[0].upper()
                    wrong_labels = [lbl for lbl in "ABCD" if lbl != correct_label]
                    print(f"Hint: Option {random.choice(wrong_labels)} is incorrect.")
                else:
                    print("Hint: Write the relevant formula or definition first, then compute.")
                user_input = input("Your answer: ").strip()
            correct = False
            if q.qtype == "mcq":
                normalized = normalize_mcq_answer(user_input)
                correct_label = q.answer[0].upper()
                if normalized in ("A", "B", "C", "D"):
                    correct = (normalized == correct_label)
                else:
                    try:
                        idx = "ABCD".index(correct_label)
                        correct_text = q.options[idx].split(".", 1)[-1].strip().lower()
                        correct = normalized == correct_text
                    except Exception:
                        correct = False
            else:
                correct = compare_short_answer(q.answer, user_input)
            self.total += 1
            if correct:
                print("✅ Correct!\n")
                self.score += 1
            else:
                print("❌ Incorrect.")
                print(generate_detailed_explanation(q, user_input) + "\n")
                self.missed.append(q)
        self._show_summary()

    def _show_summary(self) -> None:
        avg_time = sum(self.elapsed_times) / len(self.elapsed_times) if self.elapsed_times else 0.0
        pct = (100.0 * self.score / self.total) if self.total else 0.0
        print("\n========== QUIZ SUMMARY ==========")
        print(f"Score: {self.score}/{self.total} ({pct:.1f}%)")
        print(f"Average time per question: {avg_time:.1f}s")
        print(f"Timed out: {self.timed_out}")
        print(f"Missed questions: {len(self.missed)}")
        if self.missed:
            choice = input("Type 'review' to retry missed questions now, or press Enter to finish: ").strip().lower()
            if choice == "review":
                self._review_missed()

    def _review_missed(self) -> None:
        pool = self.missed[:]
        self.missed.clear()
        print("\n--- Review of missed questions ---")
        for i, q in enumerate(pool, start=1):
            print(f"\nReview {i}/{len(pool)}: {q.text}")
            if q.qtype == "mcq" and q.options:
                for opt in q.options:
                    print("  " + opt)
            start = time.time()
            ans = input("Your answer: ").strip()
            elapsed = time.time() - start
            if elapsed > self.time_limit:
                print(f"⏱ Time up! ({elapsed:.1f}s). Still missed.")
                self.total += 1
                self.timed_out += 1
                self.missed.append(q)
                continue
            if q.qtype == "mcq":
                normalized = normalize_mcq_answer(ans)
                corr = q.answer[0].upper()
                if normalized in ("A", "B", "C", "D"):
                    ok = (normalized == corr)
                else:
                    try:
                        ok = (normalized == q.options["ABCD".index(corr)].split(".", 1)[-1].strip().lower())
                    except Exception:
                        ok = False
            else:
                ok = compare_short_answer(q.answer, ans)
            self.total += 1
            if ok:
                print("✅ Correct this time!")
                self.score += 1
            else:
                print(f"❌ Still off. {generate_detailed_explanation(q, ans)}")
                self.missed.append(q)
        print("\nReview complete.")


# -----------------------------------------------------------------------------
# CLI entrypoint with simple alias support and retries
# -----------------------------------------------------------------------------
def prompt_subject() -> Optional[str]:
    subjects_list = sorted(SUBJECTS.keys())
    while True:
        print("Available subjects:", ", ".join(s.title() for s in subjects_list))
        subject_raw = input("Choose a subject (or type 'quit' to exit): ").strip().lower()
        if subject_raw in ("quit", "exit"):
            return None
        if subject_raw in SUBJECTS:
            return subject_raw
        if subject_raw in SUBJECT_ALIASES:
            mapped = SUBJECT_ALIASES[subject_raw]
            if mapped in SUBJECTS:
                print(f"Interpreting '{subject_raw}' as '{mapped}'.")
                return mapped
        matches = [s for s in SUBJECTS if s.startswith(subject_raw)]
        if len(matches) == 1:
            print(f"Interpreting '{subject_raw}' as '{matches[0]}'.")
            return matches[0]
        print("Invalid subject. Try again (or type 'quit' to exit).")


def prompt_difficulty() -> Optional[str]:
    while True:
        diff = input("Choose difficulty (easy / medium / hard) or 'quit' to exit: ").strip().lower()
        if diff in ("quit", "exit"):
            return None
        if diff in DIFF:
            return diff
        print("Invalid difficulty. Please type 'easy', 'medium', or 'hard' (or 'quit').")


def main() -> None:
    print("WAEC Tutor — Subjects, Difficulty, Timer & Scoring\n")
    subject = prompt_subject()
    if subject is None:
        print("Goodbye.")
        return
    difficulty = prompt_difficulty()
    if difficulty is None:
        print("Goodbye.")
        return
    default_time = DIFF[difficulty]["time"]  # type: ignore
    time_input = input(f"Time per question in seconds [press Enter for {default_time}s]: ").strip()
    if time_input:
        try:
            time_limit = max(5, int(time_input))
        except ValueError:
            print("Invalid time; using default.")
            time_limit = default_time  # type: ignore
    else:
        time_limit = default_time  # type: ignore
    try:
        mcq_count = int(input("How many MCQ questions? ").strip())
        theory_count = int(input("How many Theory (short-answer) questions? ").strip())
    except ValueError:
        print("Invalid number entered. Exiting.")
        return
    generator = SUBJECTS[subject]
    question_pool = generator(difficulty)
    tutor = Tutor(question_pool, time_limit)
    selected = tutor.pick_questions(mcq_count, theory_count)
    if selected is None:
        return
    tutor.run_quiz(selected)


if _name_ == "_main_":
    main()