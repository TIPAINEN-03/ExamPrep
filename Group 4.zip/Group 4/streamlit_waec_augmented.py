# streamlit_waec_augmented.py
from __future__ import annotations
import time, random, json, os, re
import streamlit as st
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
import matplotlib.pyplot as plt

# -------------------------
# Topic lists per subject
# -------------------------
MATH_TOPICS = ["Number & Numeration", "Algebraic Processes", "Plane Geometry", "Mensuration",
               "Trigonometry", "Statistics & Probability", "Coordinate Geometry",
               "Vectors & Transformations", "Calculus (Intro)", "Graphs & Functions",
               "Sets & Logic", "Business Mathematics"]

FMATH_TOPICS = ["Differentiation", "Integration", "Matrices", "Vectors (advanced)",
                "Complex numbers", "Series & Sequences"]

PHYSICS_TOPICS = ["Kinematics", "Dynamics", "Work & Energy", "Waves", "Electricity",
                  "Units & Measurements", "Momentum", "Pressure & Fluids"]

CHEMISTRY_TOPICS = ["Atomic structure", "Periodic table", "Stoichiometry", "Acids & Bases",
                     "Chemical bonding", "Organic basics", "Moles & Calculations"]

BIOLOGY_TOPICS = ["Cells & Organelles", "Photosynthesis", "Respiration", "Genetics",
                  "Ecology", "Human physiology", "Classification"]

ICT_TOPICS = ["Data units", "Networks", "File types", "Databases", "Security", "Spreadsheets"]

SUBJECT_TOPICS = {
    "mathematics": MATH_TOPICS,
    "further mathematics": FMATH_TOPICS,
    "physics": PHYSICS_TOPICS,
    "chemistry": CHEMISTRY_TOPICS,
    "biology": BIOLOGY_TOPICS,
    "ict": ICT_TOPICS,
}

# -------------------------
# Question model
# -------------------------
class Question:
    def __init__(self, subject: str, number: str, qtype: str, text: str,
                 options: Optional[List[str]], answer: str, explanation: str,
                 worked: Optional[str] = None, topic: Optional[str] = None):
        self.subject = subject
        self.number = number
        self.qtype = qtype
        self.text = text
        self.options = options
        self.answer = answer
        self.explanation = explanation
        self.worked = worked
        self.topic = topic

# -------------------------
# Utilities
# -------------------------
def normalize_label(s: str) -> str:
    return s.strip().upper()[0] if s else ""

def compare_short(expected: str, user: str) -> bool:
    try:
        if re.fullmatch(r'[+-]?\d+(?:\.\d+)?', expected.strip()) and \
           re.fullmatch(r'[+-]?\d+(?:\.\d+)?', user.strip()):
            return abs(float(expected) - float(user)) <= 1e-6
    except:
        pass
    clean = lambda t: ''.join(ch for ch in t.lower() if ch.isalnum() or ch.isspace()).strip()
    return clean(expected) == clean(user)

# -------------------------
# Session logger
# -------------------------
class SessionLogger:
    def __init__(self):
        self.entries: List[Dict[str,Any]] = []
        self.start = datetime.now(timezone.utc).isoformat()

    def add(self, q: Question, user: str, correct: bool, elapsed: float, timed_out: bool, allowed_time: int):
        self.entries.append({
            "subject": q.subject,
            "topic": q.topic,
            "number": q.number,
            "qtype": q.qtype,
            "question": q.text,
            "answer_expected": q.answer,
            "user_input": user,
            "correct": correct,
            "elapsed": elapsed,
            "timed_out": timed_out,
            "allowed_time": allowed_time,
        })

    def save(self, preferred_dir: Optional[str] = None) -> str:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        candidates = [preferred_dir] if preferred_dir else []
        candidates.extend(["/mnt/data", os.getcwd()])
        last_exc = None
        for base in candidates:
            try:
                if base: os.makedirs(base, exist_ok=True)
                out = os.path.join(base, f"waec_session_{ts}.json") if base else f"waec_session_{ts}.json"
                with open(out, "w", encoding="utf-8") as f:
                    json.dump({"started": self.start, "entries": self.entries}, f, ensure_ascii=False, indent=2)
                return out
            except Exception as e:
                last_exc = e
        raise last_exc or Exception("Could not save session log")

# -------------------------
# Subject generators
# (short versions, 50 extra questions to each subject)
# -------------------------
def gen_sample_questions(subject: str, topics: List[str], per_topic: int=10) -> List[Question]:
    pool = []
    idx = 1
    for topic in topics:
        for _ in range(per_topic):
            text = f"Sample {subject.title()} Q{idx} on {topic}?"
            ans = f"Answer{idx}"
            pool.append(Question(subject.title(), str(idx), "short", text, None, ans, f"Explanation {idx}", worked=f"Worked {idx}", topic=topic))
            idx += 1
    random.shuffle(pool)
    return pool

SUBJECT_GENERATORS = {subj: lambda topics, per_topic=10, subj=subj: gen_sample_questions(subj, topics, per_topic) for subj in SUBJECT_TOPICS.keys()}

# -------------------------
# Streamlit UI
# -------------------------
st.set_page_config(page_title="WAEC Tutor — Augmented", layout="centered")
st.title("WAEC Tutor — Topic-aware Practice (All Subjects)")

# Sidebar
with st.sidebar.form("config"):
    subject = st.selectbox("Subject", options=[s.title() for s in SUBJECT_GENERATORS.keys()])
    subject_key = subject.lower()
    topics_for_subject = SUBJECT_TOPICS.get(subject_key, [])
    chosen_topics = st.multiselect("Pick topics", options=topics_for_subject, default=topics_for_subject[:2])
    mcq_count = st.number_input("Total MCQ count", min_value=0, max_value=100, value=5)
    theory_count = st.number_input("Total short-answer count", min_value=0, max_value=100, value=5)
    min_time = st.number_input("Min time per question (s)", min_value=3, value=6)
    max_time = st.number_input("Max time per question (s)", min_value=3, value=20)
    show_steps_default = st.checkbox("Show step-by-step toggle by default", value=True)
    preferred_save_dir = st.text_input("Preferred save directory (optional)")
    start = st.form_submit_button("Start quiz")

# Init session
if 'running' not in st.session_state:
    st.session_state.running = False

if start:
    gen = SUBJECT_GENERATORS.get(subject_key)
    topics = chosen_topics or SUBJECT_TOPICS.get(subject_key, [])
    pool = gen(topics, per_topic=50)  # +50 per subject
    mcqs = [q for q in pool if q.qtype == "mcq"][:mcq_count]
    shorts = [q for q in pool if q.qtype == "short"][:theory_count]
    final = mcqs + shorts
    random.shuffle(final)
    st.session_state.questions = final
    st.session_state.index = 0
    st.session_state.score = 0
    st.session_state.total = 0
    st.session_state.missed = []
    st.session_state.elapsed = []
    st.session_state.logger = SessionLogger()
    st.session_state.min_time = min_time
    st.session_state.max_time = max_time
    st.session_state.running = True
    st.session_state.current_time_limit = random.randint(min_time, max_time)
    st.session_state.start_time = time.time()
    st.session_state.show_steps_default = show_steps_default
    st.session_state.preferred_save_dir = preferred_save_dir.strip() or None

if not st.session_state.running:
    st.info("Configure a quiz and click Start.")
    st.stop()

# Quiz loop
questions = st.session_state.questions
idx = st.session_state.index
if idx >= len(questions):
    st.header("Quiz Summary")
    st.write(f"Score: {st.session_state.score}/{st.session_state.total}")
    if st.button("Save session log"):
        out = st.session_state.logger.save(st.session_state.preferred_save_dir)
        st.success(f"Saved to {out}")
    st.stop()

q = questions[idx]
allowed = st.session_state.current_time_limit
st.subheader(f"Q{idx+1}: [{q.subject}] Topic: {q.topic} - {q.text}")
st.info(f"Time allowed: {allowed}s")

# Short answer path
with st.form("short"):
    ans = st.text_input("Your answer")
    submit = st.form_submit_button("Submit")
    skip = st.form_submit_button("Skip")

if skip:
    elapsed = time.time() - st.session_state.start_time
    st.session_state.elapsed.append(elapsed)
    st.session_state.total += 1
    st.session_state.missed.append(q)
    st.session_state.logger.add(q, "skip", False, elapsed, False, allowed)
    st.session_state.index += 1
    st.session_state.current_time_limit = random.randint(st.session_state.min_time, st.session_state.max_time)
    st.session_state.start_time = time.time()
    st.experimental_rerun()

if submit:
    elapsed = time.time() - st.session_state.start_time
    st.session_state.elapsed.append(elapsed)
    st.session_state.total += 1
    correct = compare_short(q.answer, ans)
    if elapsed > allowed:
        st.warning(f"⏱ Time up! Took {elapsed:.1f}s > {allowed}s")
        st.session_state.missed.append(q)
        st.session_state.logger.add(q, ans, False, elapsed, True, allowed)
    elif correct:
        st.success("✅ Correct!")
        st.session_state.score += 1
        st.session_state.logger.add(q, ans, True, elapsed, False, allowed)
    else:
        st.error(f"❌ Incorrect. Correct: {q.answer}")
        st.session_state.missed.append(q)
        st.session_state.logger.add(q, ans, False, elapsed, False, allowed)
    st.session_state.index += 1
    st.session_state.current_time_limit = random.randint(st.session_state.min_time, st.session_state.max_time)
    st.session_state.start_time = time.time()
    st.experimental_rerun()