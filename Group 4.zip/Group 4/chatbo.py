import streamlit as st
import random
import textwrap
import re
import time

# --- Configuration and Headers ---
st.set_page_config(page_title="WAEC Science Tutor ", page_icon="😛", layout="centered")
st.title("🎓 WAEC Tutor — Science & Math")
st.write("Subjects: Physics, Chemistry, Biology, Mathematics. Each has 50 objective/50 theory questions (total 400).")
st.write("App uses random selection. Objective questions give detailed explanations. Theory questions show model answers.")
st.write("---")

# --------------------------
# Timer session state
# --------------------------
if "quiz_start_time" not in st.session_state:
    st.session_state.quiz_start_time = None
if "quiz_elapsed" not in st.session_state:
    st.session_state.quiz_elapsed = 0

def start_timer():
    if st.session_state.quiz_start_time is None:
        st.session_state.quiz_start_time = time.time()
    st.session_state.quiz_elapsed = int(time.time() - st.session_state.quiz_start_time)

def display_timer():
    start_timer()
    minutes, seconds = divmod(st.session_state.quiz_elapsed, 60)
    st.sidebar.markdown(f"⏱️ **Time elapsed:** {minutes:02d}:{seconds:02d}")

# --------------------------
# Programmatic question generator (Unchanged)
# --------------------------
def build_objective(subject, topics, start_index=1):
    objs = []
    i = start_index
    tcount = len(topics)
    while len(objs) < 50:
        topic = topics[len(objs) % tcount]
        qnum = len(objs) + 1
        templates = [
            (f"Which of the following best defines {topic['short']} in the context of {subject}?", topic['options'], topic['answer'], topic['explanation']),
            (f"What is the correct result of applying the principle of {topic['short']}?", topic['options'], topic['answer'], topic['explanation']),
            (f"Select the correct option regarding {topic['short']}:", topic['options'], topic['answer'], topic['explanation']),
            (f"{subject}: Choose the right answer about {topic['short']}.", topic['options'], topic['answer'], topic['explanation']),
        ]
        tpl = templates[len(objs) % len(templates)]
        qtext, options, correct, expl = tpl
        opts = options.copy()
        random.seed(qnum * len(subject)) 
        random.shuffle(opts)
        random.seed(None) 
        letters = ["A", "B", "C", "D"]
        opt_map = {letters[idx]: opts[idx] for idx in range(4)}
        correct_text = correct
        correct_letter = None
        for k, v in opt_map.items():
            if v == correct_text:
                correct_letter = k
                break
        if not correct_letter:
            correct_letter = "A"
            opt_map["A"] = correct_text
        objs.append({
            "id": f"{subject[:3].upper()}-OBJ-{qnum}",
            "subject": subject,
            "type": "OBJ",
            "question": qtext,
            "options": opt_map,
            "correct": correct_letter,
            "explanation": expl
        })
        i += 1
    return objs

def build_theory(subject, topics):
    theor = []
    tcount = len(topics)
    idx = 1
    while len(theor) < 50:
        topic = topics[len(theor) % tcount]
        if 'model' not in topic or 'explanation_long' not in topic:
            model_ans = f"Model answer for {topic['short']}."
            expl_long = f"Detailed explanation for {topic['short']}."
        else:
            model_ans = topic['model']
            expl_long = topic['explanation_long']
        templates = [
            (f"Explain {topic['short']} and its importance.", model_ans, expl_long),
            (f"Describe {topic['short']} with examples.", model_ans, expl_long),
            (f"Discuss {topic['short']} and give any two examples or applications.", model_ans, expl_long),
            (f"What is {topic['short']}? Explain briefly.", model_ans, expl_long),
        ]
        tpl = templates[len(theor) % len(templates)]
        qtext, model, expl_long = tpl
        theor.append({
            "id": f"{subject[:3].upper()}-TH-{idx}",
            "subject": subject,
            "type": "Theory",
            "question": qtext,
            "model_answer": model,
            "explanation": expl_long
        })
        idx += 1
    return theor

# --- PHYSICS TOPICS (Truncated for space) ---
physics_topics = [
    {
        "short": "force",
        "options": ["A push or pull", "Energy stored in a body", "Rate of change of speed", "Mass per unit volume"],
        "answer": "A push or pull",
        "explanation": "A force is any interaction that changes the motion of an object; commonly described as a push or a pull.",
        "model": "Force is an external agent that changes or tends to change the state of rest or uniform motion of a body.",
        "explanation_long": "Forces are vector quantities (magnitude and direction). The SI unit is the Newton (N)."
    },
    {
        "short": "velocity",
        "options": ["Speed with direction", "Rate of doing work", "Distance per time only", "Magnitude of displacement"],
        "answer": "Speed with direction",
        "explanation": "Velocity describes how fast and in which direction an object is moving (speed + direction).",
        "model": "Velocity is the rate of change of displacement with respect to time. It is a vector quantity.",
        "explanation_long": "Velocity is calculated as $\\frac{\\text{displacement}}{\\text{time taken}}$. The SI unit is $\\text{m/s}$."
    },
    # ... (18 more Physics topics assumed here) ...
]

# --- CHEMISTRY TOPICS (Truncated for space) ---
chemistry_topics = [
    {
        "short": "atom",
        "options": ["Smallest unit of an element", "Mixture of elements", "A molecule of gas", "A compound"],
        "answer": "Smallest unit of an element",
        "explanation": "An atom is the smallest particle of an element that retains chemical properties.",
        "model": "The atom is the smallest unit of an element that can take part in a chemical reaction. It consists of a nucleus containing protons and neutrons, orbited by electrons.",
        "explanation_long": "Atoms are electrically neutral because the number of protons equals the number of electrons. The atomic number defines the element."
    },
    {
        "short": "ionic bond",
        "options": ["Transfer of electrons between atoms", "Sharing of electrons", "Physical attraction", "Covalent bonding"],
        "answer": "Transfer of electrons between atoms",
        "explanation": "Ionic bonds form when electrons are transferred and ions attract (e.g., NaCl).",
        "model": "An ionic bond is formed by the complete transfer of one or more valence electrons from one atom to another.",
        "explanation_long": "This creates positive ions (cations) and negative ions (anions) held together by strong electrostatic forces."
    },
    # ... (18 more Chemistry topics assumed here) ...
]

# --- BIOLOGY TOPICS (Truncated for space) ---
biology_topics = [
    {
        "short": "cell",
        "options": ["Basic unit of life", "Organ of digestion", "Type of tissue", "Simple machine"],
        "answer": "Basic unit of life",
        "explanation": "Cells are the smallest structural and functional units of living organisms.",
        "model": "The cell is the basic structural, functional, and biological unit of all known organisms. It is the smallest unit of life.",
        "explanation_long": "Cells contain cytoplasm enclosed by a membrane. Organisms can be unicellular or multicellular."
    },
    {
        "short": "photosynthesis",
        "options": ["Process making food from $\\text{CO}_2$, water and sunlight", "Breathing process", "Protein digestion", "Seed germination"],
        "answer": "Process making food from $\\text{CO}_2$, water and sunlight",
        "explanation": "Photosynthesis produces glucose and oxygen using chlorophyll and sunlight.",
        "model": "Photosynthesis is the process used by plants, algae, and certain bacteria to convert light energy into chemical energy (glucose).",
        "explanation_long": "The balanced equation is: $6\\text{CO}_2 + 6\\text{H}_2\\text{O} + \\text{Light Energy} \\xrightarrow{\\text{Chlorophyll}} \\text{C}_6\\text{H}_{12}\\text{O}_6 + 6\\text{O}_2$."
    },
    # ... (18 more Biology topics assumed here) ...
]

# --------------------------
# --- MATHEMATICS TOPICS ---
# --------------------------
mathematics_topics = [
    {
        "short": "Quadratic Equations",
        "options": ["$\frac{-b \pm \sqrt{b^2-4ac}}{2a}$", "$x = y + 2$", "Area = $\\pi r^2$", "Volume = $lwh$"],
        "answer": "$\frac{-b \pm \sqrt{b^2-4ac}}{2a}$",
        "explanation": "This is the quadratic formula, used to find the roots (solutions) of any quadratic equation of the form $ax^2 + bx + c = 0$.",
        "model": "Solve $2x^2 + 5x - 3 = 0$. Using the formula, $x = \\frac{-5 \pm \sqrt{5^2 - 4(2)(-3)}}{2(2)}$, which simplifies to $x = \\frac{-5 \pm \sqrt{49}}{4}$. Roots are $x=1/2$ and $x=-3$.",
        "explanation_long": "A quadratic equation has at most two solutions. The term $b^2-4ac$ is the discriminant, which determines the nature of the roots (real, complex, or one repeated real root)."
    },
    {
        "short": "Change of Subject Formula",
        "options": ["Isolating a variable on one side", "Finding the area", "Calculating the volume", "Simplifying a fraction"],
        "answer": "Isolating a variable on one side",
        "explanation": "Changing the subject involves using algebraic manipulations to express one variable in terms of others (e.g., making $r$ the subject in $A=\\pi r^2$).",
        "model": "Make $h$ the subject of $V = \\frac{1}{3}\\pi r^2 h$. Multiply by 3: $3V = \\pi r^2 h$. Divide by $\\pi r^2$: $h = \\frac{3V}{\\pi r^2}$.",
        "explanation_long": "This skill is crucial in physics and applied mathematics. Remember to perform the same operation on both sides of the equation to maintain balance."
    },
    {
        "short": "Simultaneous Equations (Linear)",
        "options": ["Finding the common intersection point", "Finding the area", "Finding the derivative", "Finding the integral"],
        "answer": "Finding the common intersection point",
        "explanation": "Simultaneous equations are a set of equations solved together to find values for variables that satisfy all equations (graphically, this is the intersection point).",
        "model": "Solve $x+y=5$ and $2x-y=1$. Using elimination, adding the equations gives $3x=6$, so $x=2$. Substituting $x=2$ into the first equation gives $2+y=5$, so $y=3$. Solution: $(2, 3)$.",
        "explanation_long": "Methods include substitution and elimination. For two linear equations, a unique solution exists if the lines have different gradients."
    },
    {
        "short": "Trigonometry (SOH CAH TOA)",
        "options": ["Relating angles and side lengths", "Calculating volume", "Solving simultaneous equations", "Finding the discriminant"],
        "answer": "Relating angles and side lengths",
        "explanation": "$\\text{SOH CAH TOA}$ are mnemonics for the sine, cosine, and tangent ratios in a right-angled triangle.",
        "model": "Given a right triangle with an angle of $30^{\\circ}$ and the hypotenuse of $10 \\text{ cm}$. Find the opposite side $O$. Using $\\sin(\\theta) = \\frac{\\text{Opposite}}{\\text{Hypotenuse}}$, $O = 10 \\times \\sin(30^{\\circ}) = 10 \\times 0.5 = 5 \\text{ cm}$.",
        "explanation_long": "Sine (SOH) = Opposite/Hypotenuse; Cosine (CAH) = Adjacent/Hypotenuse; Tangent (TOA) = Opposite/Adjacent. This is the foundation for solving problems involving heights and distances."
    },
    {
        "short": "Statistics (Mean, Median, Mode)",
        "options": ["Measures of central tendency", "Measures of dispersion", "Measures of shape", "Measures of correlation"],
        "answer": "Measures of central tendency",
        "explanation": "Mean (average), Median (middle value), and Mode (most frequent value) all describe the center point of a dataset.",
        "model": "Find the median of the data: $2, 5, 1, 8, 4$. First, order the data: $1, 2, 4, 5, 8$. Since there are 5 values (odd), the median is the middle value, which is $4$.",
        "explanation_long": "The **Mean** is best for symmetric data. The **Median** is preferred for skewed data or data with outliers. The **Mode** is most useful for categorical data."
    },
    {
        "short": "Indices and Logarithms",
        "options": ["Inverse operations for powers", "Geometry formulas", "Calculus concepts", "Probability distribution"],
        "answer": "Inverse operations for powers",
        "explanation": "Logarithms (e.g., $\\log_b x$) are the inverse of index/exponential operations (e.g., $b^y$).",
        "model": "Simplify $\\log_2 8 + 3 \\times 2^{-1}$. $\\log_2 8 = 3$ (since $2^3=8$) and $2^{-1} = 1/2$. So, $3 + 3 \\times (1/2) = 3 + 1.5 = 4.5$.",
        "explanation_long": "Key law of indices: $x^m \\times x^n = x^{m+n}$. Key law of logarithms: $\\log(AB) = \\log A + \\log B$. These rules are essential for solving exponential equations."
    },
    {
        "short": "Surds (Rationalization)",
        "options": ["Removing the square root from the denominator", "Adding fractions", "Squaring a number", "Finding the cube root"],
        "answer": "Removing the square root from the denominator",
        "explanation": "Rationalization is the process of eliminating a surd (square root) from the denominator of a fraction to simplify it.",
        "model": "Rationalize $\\frac{1}{\\sqrt{3}}$. Multiply the numerator and denominator by $\\sqrt{3}$: $\\frac{1}{\\sqrt{3}} \\times \\frac{\\sqrt{3}}{\\sqrt{3}} = \\frac{\\sqrt{3}}{3}$.",
        "explanation_long": "If the denominator is a binomial surd (e.g., $a+\\sqrt{b}$), you must multiply by its conjugate ($a-\\sqrt{b}$)."
    },
    {
        "short": "Probability",
        "options": ["Likelihood of an event occurring", "Area under a curve", "Volume of a sphere", "Equation of a line"],
        "answer": "Likelihood of an event occurring",
        "explanation": "Probability is a measure of the chance that a particular event will occur, ranging from 0 (impossible) to 1 (certain).",
        "model": "A bag contains 3 red and 7 blue balls. What is the probability of drawing a red ball? Total outcomes = 10. Favorable outcomes = 3. Probability = $\\frac{3}{10}$ or $0.3$.",
        "explanation_long": "The probability of an event $E$ is given by $P(E) = \\frac{\\text{Number of favorable outcomes}}{\\text{Total number of possible outcomes}}$. For independent events $A$ and $B$, $P(A \\text{ and } B) = P(A) \\times P(B)$."
    },
    {
        "short": "Sequence and Series (Arithmetic Progression)",
        "options": ["Constant difference between successive terms", "Constant ratio between successive terms", "Product of terms", "Sum of all terms"],
        "answer": "Constant difference between successive terms",
        "explanation": "In an Arithmetic Progression (AP), each term is obtained by adding a fixed number (common difference, $d$) to the previous term.",
        "model": "The 5th term of an $\\text{AP}$ is 14 and the 9th term is 26. Find the common difference $d$. $T_9 - T_5 = 4d$. $26 - 14 = 12$. $12 = 4d$, so $d=3$.",
        "explanation_long": "The $n$-th term of an AP is $T_n = a + (n-1)d$, where $a$ is the first term. The sum of $n$ terms is $S_n = \\frac{n}{2}[2a + (n-1)d]$."
    },
    {
        "short": "Circle Theorems",
        "options": ["Geometric properties of circles", "Algebraic solution methods", "Statistical analysis", "Differentiation rules"],
        "answer": "Geometric properties of circles",
        "explanation": "Circle theorems describe relationships between angles, chords, tangents, and radii within a circle (e.g., angle at center is twice angle at circumference).",
        "model": "In a circle, the angle subtended by an arc at the center is $120^{\\circ}$. What is the angle subtended by the same arc at any point on the remaining part of the circumference? It is half the central angle: $120^{\\circ}/2 = 60^{\\circ}$.",
        "explanation_long": "Other key theorems include: the angle in a semicircle is $90^{\\circ}$, and opposite angles of a cyclic quadrilateral sum to $180^{\\circ}$."
    },
    # To ensure 50 questions, the remaining 10 topics will be variants of the core 10
    {"short": "Factorization of Polynomials", "options": ["Breaking expression into product of factors", "Finding area", "Adding terms", "Dividing terms"], "answer": "Breaking expression into product of factors", "explanation": "Factorization is the reverse of expansion, often used to solve equations.", "model": "Factorize $x^2 - 4$. This is a difference of two squares: $(x-2)(x+2)$.", "explanation_long": "Common techniques include factoring by grouping, difference of squares, and sum/difference of cubes."},
    {"short": "Coordinate Geometry (Distance/Midpoint)", "options": ["Using coordinates to find lengths/centers", "Using protractor", "Using compass", "Using ruler only"], "answer": "Using coordinates to find lengths/centers", "explanation": "Coordinate geometry uses algebraic methods to solve geometric problems.", "model": "Find the distance between $(1, 2)$ and $(4, 6)$. Distance $d = \sqrt{(4-1)^2 + (6-2)^2} = \sqrt{3^2 + 4^2} = 5$.", "explanation_long": "Midpoint formula: $(\\frac{x_1+x_2}{2}, \\frac{y_1+y_2}{2})$. Distance formula: $d = \sqrt{(x_2-x_1)^2 + (y_2-y_1)^2}$."},
    {"short": "Set Theory (Union and Intersection)", "options": ["Operations on groups of elements", "Operations on numbers", "Operations on shapes", "Operations on vectors"], "answer": "Operations on groups of elements", "explanation": "Set theory defines operations like Union ($\cup$, 'or') and Intersection ($\cap$, 'and').", "model": "If $A=\{1, 2, 3\}$ and $B=\{2, 3, 4\}$, then $A \\cup B = \{1, 2, 3, 4\}$ and $A \\cap B = \{2, 3\}$.", "explanation_long": "The universal set contains all elements. De Morgan's Laws relate union, intersection, and complements."},
    {"short": "Differentiation (Calculus)", "options": ["Finding the rate of change / gradient", "Finding the area", "Finding the volume", "Finding the perimeter"], "answer": "Finding the rate of change / gradient", "explanation": "Differentiation finds the derivative, which represents the instantaneous rate of change or the gradient of a curve.", "model": "Find the derivative of $y = x^3$. $\\frac{dy}{dx} = 3x^2$.", "explanation_long": "The power rule is $\\frac{d}{dx}(x^n) = nx^{n-1}$. Differentiation is used to find maximum and minimum points."},
    {"short": "Integration (Calculus)", "options": ["Finding the area under a curve / anti-differentiation", "Finding the gradient", "Finding the volume of a line", "Finding the inverse function"], "answer": "Finding the area under a curve / anti-differentiation", "explanation": "Integration is the reverse of differentiation and is used to find areas under curves.", "model": "Integrate $\\int 2x \\, dx$. The result is $x^2 + C$, where $C$ is the constant of integration.", "explanation_long": "The power rule for integration is $\\int x^n \\, dx = \\frac{x^{n+1}}{n+1} + C$. Definite integration gives the exact area between limits."},
    {"short": "Vectors (Addition/Magnitude)", "options": ["Quantities with magnitude and direction", "Quantities with magnitude only", "Simple numbers", "Geometric shapes"], "answer": "Quantities with magnitude and direction", "explanation": "A vector is a quantity with both magnitude (size) and direction (e.g., force, velocity).", "model": "Find the magnitude of vector $\\mathbf{v} = \\begin{pmatrix} 3 \\ 4 \\end{pmatrix}$. Magnitude $|\mathbf{v}| = \\sqrt{3^2 + 4^2} = 5$.", "explanation_long": "Vectors are added head-to-tail. They are important in physics (e.g., resultant forces) and mechanics."},
    {"short": "Geometric Progression (GP)", "options": ["Constant ratio between successive terms", "Constant difference between successive terms", "Sum of all terms", "Difference of terms"], "answer": "Constant ratio between successive terms", "explanation": "In a Geometric Progression (GP), each term is obtained by multiplying the previous term by a fixed number (common ratio, $r$).", "model": "Find the common ratio $r$ of the sequence $2, 6, 18, 54, \\dots$. $r = 6/2 = 3$.", "explanation_long": "The $n$-th term is $T_n = ar^{n-1}$. The sum of the first $n$ terms is $S_n = \\frac{a(r^n - 1)}{r-1}$."},
    {"short": "Inequalities (Linear)", "options": ["Equations involving $<, >, \\le, \\ge$", "Equations involving only $=$", "Equations involving $\\pi$", "Equations involving $\\sqrt{}$"], "answer": "Equations involving $<, >, \\le, \\ge$", "explanation": "Inequalities are used to show a range of values that a variable can take.", "model": "Solve $2x + 1 < 7$. Subtract 1: $2x < 6$. Divide by 2: $x < 3$.", "explanation_long": "The key rule is that when you multiply or divide by a **negative** number, you must reverse the inequality sign."},
    {"short": "Mensuration (Area/Volume)", "options": ["Measurement of geometric shapes", "Measurement of speed", "Measurement of force", "Measurement of density"], "answer": "Measurement of geometric shapes", "explanation": "Mensuration deals with calculating lengths, areas, and volumes of geometric figures.", "model": "Calculate the area of a circle with radius $7 \\text{ cm}$. $A = \\pi r^2 = \\frac{22}{7} \\times 7^2 = 154 \\text{ cm}^2$.", "explanation_long": "You must remember formulas like: Volume of cone $V=\\frac{1}{3}\\pi r^2 h$, Area of triangle $A=\\frac{1}{2}bh$, etc."},
    {"short": "Bearing and Distances", "options": ["Directions measured clockwise from North", "Measurement from East", "Measurement from South", "Measurement from West"], "answer": "Directions measured clockwise from North", "explanation": "Bearings (three-figure bearings) are used to specify direction, measured in degrees clockwise from the North line.", "model": "A bearing of $045^{\\circ}$ means $45^{\\circ}$ clockwise from North. The distance from A to B is $10 \\text{ km}$ on a bearing of $180^{\\circ}$.", "explanation_long": "Back bearings are found by adding or subtracting $180^{\\circ}$. Always draw a diagram with a North line at the starting point."}
]


# --------------------------
# Build all datasets
# --------------------------
physics_obj = build_objective("Physics", physics_topics)
physics_theory = build_theory("Physics", physics_topics)
chemistry_obj = build_objective("Chemistry", chemistry_topics)
chemistry_theory = build_theory("Chemistry", chemistry_topics)
biology_obj = build_objective("Biology", biology_topics)
biology_theory = build_theory("Biology", biology_topics)
mathematics_obj = build_objective("Mathematics", mathematics_topics)
mathematics_theory = build_theory("Mathematics", mathematics_topics)

OBJECTIVE_BANK = {
    "Physics": physics_obj,
    "Chemistry": chemistry_obj,
    "Biology": biology_obj,
    "Mathematics": mathematics_obj
}

THEORY_BANK = {
    "Physics": physics_theory,
    "Chemistry": chemistry_theory,
    "Biology": biology_theory,
    "Mathematics": mathematics_theory
}

# --------------------------
# Helper functions
# --------------------------
def pick_random_obj(subject):
    return random.choice(OBJECTIVE_BANK[subject])

def pick_random_theory(subject):
    return random.choice(THEORY_BANK[subject])

# --------------------------
# Streamlit UI
# --------------------------
st.sidebar.header("Quiz settings")
subject = st.sidebar.selectbox("Choose Subject", ["Physics", "Chemistry", "Biology", "Mathematics"])
qkind = st.sidebar.selectbox("Question Type", ["Objective (A–D)", "Theory"])
max_questions = 20
num_to_generate = st.sidebar.slider("Number of questions:", 1, max_questions, 5)
st.sidebar.markdown("Press **Start Quiz** to generate questions.")

st.write(f"**Selected:** {subject} — {qkind} ({num_to_generate} questions)")
st.write("---")

# Session state for the quiz
for key in ["quiz_started", "quiz_questions", "current_question_index", "score", "attempts", "answers_submitted", "theory_notes"]:
    if key not in st.session_state:
        st.session_state[key] = False if key == "quiz_started" else [] if key == "quiz_questions" else 0 if key in ["current_question_index","score","attempts"] else {}

# --- QUIZ INITIALIZATION ---
def initialize_quiz(subject, qkind, num_questions):
    st.session_state.quiz_started = True
    st.session_state.score = 0
    st.session_state.attempts = 0
    st.session_state.current_question_index = 0
    st.session_state.answers_submitted = {}
    st.session_state.theory_notes = {}
    st.session_state.quiz_start_time = time.time()  # Start the timer
    if qkind.startswith("Objective"):
        bank = OBJECTIVE_BANK[subject]
    else:
        bank = THEORY_BANK[subject]
    st.session_state.quiz_questions = random.sample(bank, min(num_questions, len(bank)))
    st.success(f"Quiz started with {len(st.session_state.quiz_questions)} {qkind} questions for {subject}!")

col1, col2 = st.columns([1,1])
with col1:
    if st.button("Start Quiz"):
        initialize_quiz(subject, qkind, num_to_generate)

with col2:
    if st.button("Reset Quiz"):
        st.session_state.update({
            "quiz_started": False,
            "quiz_questions": [],
            "current_question_index": 0,
            "score": 0,
            "attempts": 0,
            "answers_submitted": {},
            "theory_notes": {},
            "quiz_start_time": None,
            "quiz_elapsed": 0
        })
        st.success("Quiz reset.")

# --------------------------
# Display timer
# --------------------------
if st.session_state.quiz_started:
    display_timer()

# --- CORE QUIZ DISPLAY LOGIC (Unchanged) ---

if not st.session_state.quiz_started or not st.session_state.quiz_questions:
    st.info("Set your options in the sidebar and click **Start Quiz**.")

else:
    q_index = st.session_state.current_question_index
    questions = st.session_state.quiz_questions
    total_q = len(questions)

    if q_index >= total_q:
        st.balloons()
        st.header("🎉 Quiz Finished!")
        if qkind.startswith("Objective"):
            st.success(f"Final Score: **{st.session_state.score}/{total_q}**")
        else:
            st.info(f"You completed all **{total_q} Theory** questions. Review the Model Answers below.")
        st.write("Click 'Start Quiz' again to try a new set of questions.")
        st.write("---")
        
        # --- REVIEW SECTION ---
        st.subheader("📚 Review Your Answers")
        for i, q in enumerate(questions):
            st.markdown(f"**Question {i+1}:** {q['question']}")
            if qkind.startswith("Objective"):
                user_ans = st.session_state.answers_submitted.get(q['id'])
                if user_ans and user_ans['is_correct']:
                    st.success(f"Your Answer: {user_ans['selected_letter']}. {q['options'][user_ans['selected_letter']]} (Correct)")
                elif user_ans:
                    st.error(f"Your Answer: {user_ans['selected_letter']}. {q['options'][user_ans['selected_letter']]}")
                    st.info(f"Correct Answer: {q['correct']}. {q['options'][q['correct']]}")
                else:
                    st.warning("Skipped.")
                with st.expander("Show Explanation"):
                    st.write(q['explanation'])
            else: # Theory
                with st.expander("Show Model Answer and Your Notes"):
                    st.write("### Model Answer")
                    st.write(q['model_answer'])
                    st.write("### Detailed Explanation / Marking Points")
                    st.write(q['explanation'])
                    st.write("---")
                    st.write(f"**Your Notes:** {st.session_state.theory_notes.get(q['id'], 'No notes saved.')}")

    else:
        # Display current question
        q = questions[q_index]
        q_id = q['id']

        st.header(f"Question {q_index + 1} of {total_q}")
        st.markdown(f"**[{q['id']}] {q['subject']}**")
        # Use st.markdown for question text to allow LaTeX rendering (since your model answers use it)
        st.markdown(q["question"])

        if qkind.startswith("Objective"):
            # --- Objective Question Logic ---
            
            if q_id in st.session_state.answers_submitted:
                st.info("You have already answered this question. Click 'Next Question' to continue.")
                
            else:
                choice_options = [f"{k}. {v}" for k, v in q["options"].items()]
                selected_choice = st.radio("Options", options=choice_options, key=f"obj_q_{q_index}")
                
                if st.button("Submit Answer", key=f"submit_obj_{q_index}"):
                    st.session_state.attempts += 1
                    selected_letter = selected_choice.split(".")[0]
                    correct_letter = q["correct"]
                    is_correct = (selected_letter == correct_letter)
                    
                    st.session_state.answers_submitted[q_id] = {
                        "selected_letter": selected_letter,
                        "is_correct": is_correct
                    }

                    if is_correct:
                        st.success("✔ Correct! Well done.")
                        st.session_state.score += 1
                        st.info("Explanation: " + q["explanation"])
                    else:
                        st.error(f"❌ Wrong. The correct answer is **{correct_letter}. {q['options'][correct_letter]}**")
                        st.write("### Detailed Explanation")
                        st.write(textwrap.fill(q["explanation"], width=100))
                        st.write("**Common misconception:**")
                        misconception = generate_misconception(q)
                        st.write(misconception)
                        
                    st.write(f"**Objective Score:** {st.session_state.score} / {st.session_state.attempts}")
                    st.rerun()

        else:
            # --- Theory Question Logic ---
            st.write("---")
            
            user_answer_text = st.session_state.theory_notes.get(q_id, "")
            user_answer = st.text_area("Write your answer here (type in a few sentences/points):", value=user_answer_text, height=180, key=f"theory_q_{q_index}")
            
            st.session_state.theory_notes[q_id] = user_answer

            if st.button("View Model Answer", key=f"submit_theory_{q_index}"):
                st.session_state.attempts += 1
                
                st.markdown("### Model Answer")
                st.markdown(q["model_answer"])
                st.markdown("### Detailed Explanation / Marking Points")
                st.markdown(q["explanation"])
                
                coverage, keywords = simple_coverage_check(user_answer, q["model_answer"])
                st.write("---")
                
                if coverage >= 0.7:
                    st.success(f"Your answer covers most key points ({int(coverage*100)}%).")
                elif coverage >= 0.4:
                    st.warning(f"Your answer covers some points ({int(coverage*100)}%). Consider including: {', '.join(keywords[:4])}")
                else:
                    st.error(f"Your answer is missing many points ({int(coverage*100)}%). Key points to focus on: {', '.join(keywords[:6])}")
                    
                st.write(f"**Attempts:** {st.session_state.attempts} — **Objective Score:** {st.session_state.score} (Theory is manually assessed)")
        
        # --- Navigation ---
        st.write("---")
        nav_col1, nav_col2 = st.columns([1, 1])

        with nav_col1:
            if st.button("Previous Question", disabled=(q_index == 0)):
                st.session_state.current_question_index -= 1
                st.rerun()

        with nav_col2:
            if st.button("Next Question", disabled=(q_index == total_q - 1)):
                st.session_state.current_question_index += 1
                st.rerun()

# --------------------------
# Utility helpers used above (Unchanged)
# --------------------------
def generate_misconception(q):
    """
    Return a short, plausible common-misconception note for the given objective question.
    """
    txt = q["question"].lower()
    if q["subject"] == "Mathematics":
        if "quadratic" in txt:
             return "Misconception: Students often forget to include $\\pm$ when taking the square root, missing one solution."
        if "simultaneous" in txt:
             return "Misconception: Be careful when multiplying an equation to eliminate a variable; ensure you multiply **all** terms on both sides."
        if "trigonometry" in txt:
             return "Misconception: Mixing up SOH, CAH, TOA is common. Always label the sides (Opposite, Adjacent, Hypotenuse) relative to the angle you are using."
    if "force" in txt:
        return "Some learners confuse force with energy. Remember: force causes acceleration, while energy is the capacity to do work."
    
    return "Watch out for mixing definitions. Focus on the key definition or formula used in each topic."

def simple_coverage_check(student_text, model_text):
    """
    Very simple heuristic: split model_text into keywords and check presence in student_text.
    """
    words = re.findall(r"\b[a-zA-Z]{4,}\b", model_text.lower())
    ignore_words = {"which", "what", "that", "this", "then", "have", "with", "from", "into", "like", "they", "them", "such", "only", "also", "work", "body", "rate", "mean", "mole", "name", "find", "show", "give", "term"}
    
    keywords = []
    for w in words:
        if w not in keywords and w not in ignore_words:
            keywords.append(w)
            
    if not keywords:
        return 0.0, []
        
    student_text = student_text.lower()
    matched = [k for k in keywords if k in student_text]
    coverage = len(matched) / len(keywords)
    
    unmatched_keywords = [k for k in keywords if k not in student_text]
    
    return coverage, unmatched_keywords

# --------------------------
# Footer / notes
# --------------------------
st.write("---")
st.write("Notes:")
st.write("- This app now covers Physics, Chemistry, Biology, and Mathematics.")
st.write("- **Quiz Mode:** Move through your selected number of questions, one at a time.")