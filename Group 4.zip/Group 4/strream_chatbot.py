import streamlit as st
import random
from collections import defaultdict
import time

# --- SCALABLE WAEC QUESTION DATABASE ---
# (Copied directly from your chatbot2.py file)
# NOTE: Streamlit automatically renders the LaTeX syntax (e.g., $\frac{x}{3}$)
RAW_WAEC_QUESTIONS = [
    # ---------------------------------
    # 1. ENGLISH LANGUAGE QUESTIONS (Lexis, Structure, and Interpretation)
    # ---------------------------------
    {
        "subject": "English Language",
        "question": "From the options, choose the word that has the opposite meaning to 'negligible' in the sentence: 'The damage was negligible.'",
        "options": ["A. Trivial", "B. Significant", "C. Minor", "D. Avoidable"],
        "answer": "B",
        "explanation": "The word 'negligible' means so small or unimportant as to be not worth considering (trivial or minor). Therefore, its opposite (antonym) is 'significant', meaning important or noteworthy."
    },
    {
        "subject": "English Language",
        "question": "Complete the sentence with the most suitable option: 'Neither John nor his friends ____ present at the meeting.'",
        "options": ["A. was", "B. were", "C. is", "D. has been"],
        "answer": "B",
        "explanation": "This is a question on Concord (subject-verb agreement). When 'neither...nor' is used, the verb agrees with the subject nearest to it. Here, the subject nearest to the blank is 'his friends' (plural), so the plural verb 'were' is correct."
    },
    {
        "subject": "English Language",
        "question": "Which of the following sentences contains a metaphor?",
        "options": ["A. The soldier was as brave as a lion.", "B. The crowd roared like thunder.", "C. Her voice was music to his ears.", "D. She ran quickly down the street."],
        "answer": "C",
        "explanation": "A metaphor is a figure of speech that directly compares two unlike things without using 'like' or 'as'. Saying 'Her voice was music' directly equates her voice to music, implying its beautiful quality. Options A and B use 'as' or 'like', making them similes."
    },
    {
        "subject": "English Language",
        "question": "A group of people working together but having little or no interest in the project is called a ____ of people.",
        "options": ["A. crew", "B. mob", "C. committee", "D. disinterested lot"],
        "answer": "C",
        "explanation": "While 'crew' and 'mob' are group nouns, 'committee' is a specific term for a group of people appointed to perform a function or carry out a project. 'Disinterested lot' is not a standard collective noun."
    },
    {
        "subject": "English Language",
        "question": "Choose the correct question tag: 'You haven't finished your assignment, ____?'",
        "options": ["A. have you", "B. didn't you", "C. isn't it", "D. you have"],
        "answer": "A",
        "explanation": "The rule for question tags is: If the main sentence is negative (haven't finished), the tag must be positive (have you). The verb in the tag must match the auxiliary verb in the sentence ('have')."
    },
    {
        "subject": "English Language",
        "question": "The candidate was asked to **elucidate** his campaign promises.",
        "options": ["A. repeat", "B. withdraw", "C. clarify", "D. shorten"],
        "answer": "C",
        "explanation": "'Elucidate' means to make clear; explain. The closest synonym here is 'clarify'."
    },
    {
        "subject": "English Language",
        "question": "Choose the option that is correctly punctuated: 'The teacher shouted John sit down.'",
        "options": ["A. 'The teacher shouted, John, sit down!'", "B. The teacher shouted 'John, sit down!'", "C. The teacher shouted: 'John, sit down.'", "D. The teacher shouted, 'John, sit down!'"],
        "answer": "D",
        "explanation": "Direct speech must be set off by quotation marks, and the verb of speaking ('shouted') should be separated by a comma. The punctuation (exclamation mark) goes inside the closing quotation mark."
    },
    {
        "subject": "English Language",
        "question": "She is addicted ____ smoking.",
        "options": ["A. with", "B. to", "C. at", "D. by"],
        "answer": "B",
        "explanation": "The correct prepositional phrase is 'addicted to' when referring to a habit or dependence."
    },
    {
        "subject": "English Language",
        "question": "The minister addressed the crowd with great **audacity**.",
        "options": ["A. confidence", "B. arrogance", "C. wisdom", "D. humility"],
        "answer": "B",
        "explanation": "While 'audacity' can sometimes mean bold confidence, in most contexts, especially in public address, it implies excessive boldness, often seen as rude or arrogant. 'Arrogance' is the most fitting synonym here."
    },
    {
        "subject": "English Language",
        "question": "Which word has the same vowel sound as the underlined letters in 'pl**ea**sure'?",
        "options": ["A. Measure", "B. Leave", "C. Sea", "D. Great"],
        "answer": "A",
        "explanation": "The underlined sound in 'pleasure' is the short 'e' sound (/ɛ/), which is the same sound found in 'measure'. The other options have long 'e' or long 'a' sounds."
    },
    {
        "subject": "English Language",
        "question": "The policeman's attempt to stop the thief proved to be a **wild goose chase**.",
        "options": ["A. successful mission", "B. fruitless search", "C. dangerous venture", "D. simple task"],
        "answer": "B",
        "explanation": "The idiom 'a wild goose chase' means a foolish or hopeless and frustrating pursuit of something unattainable; a futile or fruitless search."
    },
    # ---------------------------------
    # 2. MATHEMATICS QUESTIONS (Algebra, Geometry, and Number Bases)
    # ---------------------------------
    {
        "subject": "Mathematics",
        "question": "If $2x - 3 = 7$, what is the value of $x$?",
        "options": ["A. 2", "B. 5", "C. 8", "D. 10"],
        "answer": "B",
        "explanation": "To solve $2x - 3 = 7$:\n1. Add $3$ to both sides: $2x = 7 + 3$, so $2x = 10$.\n2. Divide both sides by $2$: $x = \\frac{10}{2}$.\n3. $x = 5$."
    },
    {
        "subject": "Mathematics",
        "question": "Convert the binary number $1101_2$ to base 10.",
        "options": ["A. 13", "B. 11", "C. 9", "D. 15"],
        "answer": "A",
        "explanation": "To convert $1101_2$ to base 10, multiply each digit by the power of 2 corresponding to its position:\n$1 \\times 2^3 + 1 \\times 2^2 + 0 \\times 2^1 + 1 \\times 2^0$\n$= 1 \\times 8 + 1 \\times 4 + 0 \\times 2 + 1 \\times 1$\n$= 8 + 4 + 0 + 1 = 13$."
    },
    {
        "subject": "Mathematics",
        "question": "Find the area of a circle with a radius of $7$ cm (Use $\\pi = \\frac{22}{7}$).",
        "options": ["A. $44\\text{ cm}^2$", "B. $154\\text{ cm}^2$", "C. $22\\text{ cm}^2$", "D. $49\\text{ cm}^2$"],
        "answer": "B",
        "explanation": "The formula for the area ($A$) of a circle is $A = \\pi r^2$.\nGiven $r = 7$ cm and $\\pi = \\frac{22}{7}$.\n$A = \\frac{22}{7} \\times 7^2 = \\frac{22}{7} \\times 49 = 22 \\times 7$.\n$A = 154\\text{ cm}^2$."
    },
    {
        "subject": "Mathematics",
        "question": "What is the next term in the sequence: $2, 5, 10, 17, 26, \\dots$",
        "options": ["A. 37", "B. 35", "C. 33", "D. 40"],
        "answer": "A",
        "explanation": "This sequence is formed by adding increasing odd numbers:\n$2 + 3 = 5$\n$5 + 5 = 10$\n$10 + 7 = 17$\n$17 + 9 = 26$\nThe next number to add is $11$.\n$26 + 11 = 37$."
    },
    {
        "subject": "Mathematics",
        "question": "If $\\log_2(x) = 4$, what is the value of $x$?",
        "options": ["A. 8", "B. 16", "C. 4", "D. 2"],
        "answer": "B",
        "explanation": "The equation $\\log_b(x) = y$ is equivalent to $b^y = x$.\nFor $\\log_2(x) = 4$, we have $2^4 = x$.\n$x = 2 \\times 2 \\times 2 \\times 2 = 16$."
    },
    {
        "subject": "Mathematics",
        "question": "A student scored $70$ in an exam which was $40\%$ of the total mark. What was the total mark?",
        "options": ["A. 175", "B. 280", "C. 140", "D. 200"],
        "answer": "A",
        "explanation": "Let $T$ be the total mark.\n$40\\%$ of $T$ is $70$.\n$0.40 \\times T = 70$\n$T = \\frac{70}{0.40} = \\frac{700}{4}$\n$T = 175$."
    },
    {
        "subject": "Mathematics",
        "question": "Find the average (mean) of the numbers $4, 6, 8, 10$.",
        "options": ["A. 6", "B. 7", "C. 8", "D. 9"],
        "answer": "B",
        "explanation": "The average is the sum of the numbers divided by the count of the numbers.\nSum $= 4 + 6 + 8 + 10 = 28$.\nCount $= 4$.\nAverage $= \\frac{28}{4} = 7$."
    },
    {
        "subject": "Mathematics",
        "question": "What is the probability of picking an even number from the set of integers $\{1, 2, 3, 4, 5, 6, 7, 8\}$?",
        "options": ["A. $\\frac{1}{8}$", "B. $\\frac{3}{8}$", "C. $\\frac{1}{2}$", "D. $\\frac{3}{4}$"],
        "answer": "C",
        "explanation": "Total numbers in the set: $8$.\nEven numbers: $\{2, 4, 6, 8\}$ (4 numbers).\nProbability $= \\frac{\\text{Number of favorable outcomes}}{\\text{Total number of outcomes}} = \\frac{4}{8} = \\frac{1}{2}$."
    },
    {
        "subject": "Mathematics",
        "question": "Solve the inequality: $5x - 2 < 18$",
        "options": ["A. $x < 3$", "B. $x > 4$", "C. $x < 4$", "D. $x > 3$"],
        "answer": "C",
        "explanation": "To solve $5x - 2 < 18$:\n1. Add $2$ to both sides: $5x < 18 + 2$, so $5x < 20$.\n2. Divide both sides by $5$: $x < \\frac{20}{5}$.\n3. $x < 4$."
    },
    {
        "subject": "Mathematics",
        "question": "The hypotenuse of a right-angled triangle is $13$ cm, and one of its other sides is $5$ cm. Find the length of the third side.",
        "options": ["A. 8 cm", "B. 12 cm", "C. 18 cm", "D. $\\sqrt{194}$ cm"],
        "answer": "B",
        "explanation": "Use the Pythagorean theorem: $a^2 + b^2 = c^2$, where $c$ is the hypotenuse.\n$5^2 + b^2 = 13^2$\n$25 + b^2 = 169$\n$b^2 = 169 - 25 = 144$\n$b = \\sqrt{144} = 12$ cm."
    },
    # ---------------------------------
    # 3. PHYSICS QUESTIONS (Mechanics, Electricity, and Heat)
    # ---------------------------------
    {
        "subject": "Physics",
        "question": "Which of the following is a derived SI unit?",
        "options": ["A. Kilogram (kg)", "B. Second (s)", "C. Ampere (A)", "D. Newton (N)"],
        "answer": "D",
        "explanation": "Derived units are units of measurement that are combinations of the seven base SI units. The Newton (N) is the unit of force, defined as $\\text{kg} \cdot \\text{m}/\\text{s}^2$. Kilogram, Second, and Ampere are base SI units."
    },
    {
        "subject": "Physics",
        "question": "A body starts from rest and accelerates uniformly at $2 \\text{ m/s}^2$ for $5$ seconds. What is its final velocity?",
        "options": ["A. $10 \\text{ m/s}$", "B. $2.5 \\text{ m/s}$", "C. $7 \\text{ m/s}$", "D. $20 \\text{ m/s}$"],
        "answer": "A",
        "explanation": "Use the first equation of motion: $v = u + at$.\n$u$ (initial velocity) $= 0 \\text{ m/s}$ (starts from rest).\n$a$ (acceleration) $= 2 \\text{ m/s}^2$.\n$t$ (time) $= 5 \\text{ s}$.\n$v = 0 + (2 \\times 5) = 10 \\text{ m/s}$."
    },
    {
        "subject": "Physics",
        "question": "The phenomenon responsible for the production of echoes is:",
        "options": ["A. Refraction", "B. Diffraction", "C. Reflection", "D. Interference"],
        "answer": "C",
        "explanation": "An echo is caused by the reflection of sound waves from a hard surface back to the listener. Reflection occurs when a wave hits a boundary between two different media and remains in the original medium."
    },
    {
        "subject": "Physics",
        "question": "What is the relationship between potential difference $(V)$, current $(I)$, and resistance $(R)$ in a circuit?",
        "options": ["A. $V = I + R$", "B. $V = I \\times R$", "C. $V = \\frac{I}{R}$", "D. $V = \\frac{R}{I}$"],
        "answer": "B",
        "explanation": "This is Ohm's Law. It states that the voltage (potential difference, $V$) across a resistor is directly proportional to the current ($I$) flowing through it, where the constant of proportionality is the resistance ($R$). Thus, $V = IR$."
    },
    {
        "subject": "Physics",
        "question": "Which instrument is used to measure electric current in a circuit?",
        "options": ["A. Voltmeter", "B. Ammeter", "C. Galvanometer", "D. Ohmmeter"],
        "answer": "B",
        "explanation": "An Ammeter is designed to measure the current (measured in Amperes, A) flowing through a circuit and must be connected in series. A Voltmeter measures potential difference (voltage), and an Ohmmeter measures resistance."
    },
    {
        "subject": "Physics",
        "question": "The specific latent heat of fusion of a substance is the heat required to change a unit mass of the substance from:",
        "options": ["A. Liquid to gas at its boiling point.", "B. Solid to liquid at its melting point.", "C. Liquid to solid at its freezing point.", "D. Solid to gas directly."],
        "answer": "B",
        "explanation": "Fusion refers to melting. The specific latent heat of fusion is the energy required to change $1 \\text{ kg}$ of a solid completely into a liquid without any change in temperature (i.e., at its melting point)."
    },
    {
        "subject": "Physics",
        "question": "Two equal forces of $5\\text{ N}$ act perpendicularly to each other. What is the magnitude of the resultant force?",
        "options": ["A. $5\\text{ N}$", "B. $10\\text{ N}$", "C. $7.07\\text{ N}$", "D. $25\\text{ N}$"],
        "answer": "C",
        "explanation": "When two forces, $F_1$ and $F_2$, act perpendicularly, the resultant force ($R$) is found using the Pythagorean theorem: $R = \\sqrt{F_1^2 + F_2^2}$.\n$R = \\sqrt{5^2 + 5^2} = \\sqrt{25 + 25} = \\sqrt{50}$.\n$R \\approx 7.07\\text{ N}$."
    },
    {
        "subject": "Physics",
        "question": "Which part of the eye is responsible for controlling the amount of light that enters?",
        "options": ["A. Retina", "B. Cornea", "C. Iris", "D. Lens"],
        "answer": "C",
        "explanation": "The Iris is the colored part of the eye that surrounds the pupil. It is a muscular diaphragm that automatically adjusts the size of the pupil to control the amount of light reaching the retina."
    },
    {
        "subject": "Physics",
        "question": "The total resistance of two resistors, $R_1$ ($3\\Omega$) and $R_2$ ($6\\Omega$), connected in parallel is:",
        "options": ["A. $9\\Omega$", "B. $18\\Omega$", "C. $2\\Omega$", "D. $1.5\\Omega$"],
        "answer": "C",
        "explanation": "For parallel resistors, the reciprocal of the total resistance ($R_T$) is the sum of the reciprocals of the individual resistances:\n$\\frac{1}{R_T} = \\frac{1}{R_1} + \\frac{1}{R_2} = \\frac{1}{3} + \\frac{1}{6}$\n$\\frac{1}{R_T} = \\frac{2}{6} + \\frac{1}{6} = \\frac{3}{6} = \\frac{1}{2}$\n$R_T = 2\\Omega$."
    },
    {
        "subject": "Physics",
        "question": "A simple machine has a mechanical advantage of $4$. If the effort applied is $20\\text{ N}$, what is the load?",
        "options": ["A. $5\\text{ N}$", "B. $80\\text{ N}$", "C. $24\\text{ N}$", "D. $16\\text{ N}$"],
        "answer": "B",
        "explanation": "Mechanical Advantage ($\\text{MA}$) is defined as the ratio of the Load ($L$) to the Effort ($E$): $\\text{MA} = \\frac{L}{E}$.\n$4 = \\frac{L}{20}$\n$L = 4 \\times 20 = 80\\text{ N}$."
    },
]

# --- Helper Functions ---

def organize_questions(raw_data):
    """Organizes raw data into a dictionary indexed by subject."""
    organized = defaultdict(list)
    for q in raw_data:
        organized[q['subject']].append(q)
    return organized

def initialize_state():
    """Initializes the session state variables."""
    if 'app_state' not in st.session_state:
        st.session_state.app_state = "MENU"
        st.session_state.score = 0
        st.session_state.current_question_index = 0
        st.session_state.questions_to_ask = []
        st.session_state.chosen_subject = None
        st.session_state.answer_submitted = False
        st.session_state.user_choice = None

def reset_quiz():
    """Resets the state to go back to the main menu."""
    st.session_state.app_state = "MENU"
    st.session_state.score = 0
    st.session_state.current_question_index = 0
    st.session_state.questions_to_ask = []
    st.session_state.chosen_subject = None
    st.session_state.answer_submitted = False
    st.session_state.user_choice = None

# --- UI Functions ---

def show_menu(questions_by_subject):
    """Displays the main subject selection menu."""
    st.header("WAEC Objective Practice Bot")
    st.markdown("Select a subject to begin your practice quiz.")

    subject_map = {}
    sorted_subjects = sorted(questions_by_subject.keys())
    for i, subject in enumerate(sorted_subjects):
        key = str(i + 1)
        subject_map[key] = subject
    
    # Create a list for the selectbox
    subject_options = [f"[{key}] {subject} ({len(questions_by_subject[subject])} questions)" 
                       for key, subject in subject_map.items()]
    
    # Add a placeholder
    display_choice = st.selectbox(
        "Available Subjects:",
        ["Select a subject..."] + subject_options,
        index=0
    )

    if display_choice != "Select a subject...":
        # Extract the key (e.g., "[1]")
        selected_key = display_choice.split(']')[0][1:]
        chosen_subject = subject_map.get(selected_key)
        
        if chosen_subject and st.button(f"Start Quiz for {chosen_subject}"):
            # User clicked "Start Quiz", set up the quiz state
            st.session_state.chosen_subject = chosen_subject
            questions = list(questions_by_subject[chosen_subject]) # Make a copy
            random.shuffle(questions)
            st.session_state.questions_to_ask = questions
            st.session_state.current_question_index = 0
            st.session_state.score = 0
            st.session_state.answer_submitted = False
            st.session_state.app_state = "QUIZ"
            st.rerun() # Rerun the script to enter the "QUIZ" state

def show_quiz_question():
    """Displays the current quiz question and handles the logic."""
    if st.session_state.current_question_index >= len(st.session_state.questions_to_ask):
        # Quiz is over
        st.session_state.app_state = "RESULTS"
        st.rerun()
        return

    # Get the current question
    q = st.session_state.questions_to_ask[st.session_state.current_question_index]
    total_questions = len(st.session_state.questions_to_ask)
    question_number = st.session_state.current_question_index + 1

    st.subheader(f"Quiz: {st.session_state.chosen_subject}")
    st.markdown(f"**Question {question_number} / {total_questions}**")
    
    # Using st.markdown to render LaTeX in the question
    st.markdown(f"### {q['question']}")
    
    st.write("---")

    # Display feedback if an answer has been submitted
    if st.session_state.answer_submitted:
        user_answer = st.session_state.user_choice
        correct_answer = q['answer']
        
        if user_answer == correct_answer:
            st.success("✅ Correct! Fantastic work.")
        else:
            st.error(f"❌ Incorrect. The correct answer was {correct_answer}.")
            st.info("**Detailed Explanation:**")
            # Use st.markdown to render LaTeX in the explanation
            st.markdown(q['explanation'])
        
        # Button to move to the next question
        if st.button("Next Question"):
            st.session_state.current_question_index += 1
            st.session_state.answer_submitted = False
            st.session_state.user_choice = None
            st.rerun()
            
    else:
        # Display the options as a radio button list
        # We only need the letter for the check, but we display the full option
        # We use a key to ensure the widget is unique per question
        option_choice = st.radio(
            "Select your answer:",
            q['options'],
            key=f"q_{question_number}"
        )
        
        # Submit button
        if st.button("Submit Answer"):
            # The choice is "A. Trivial", so we split to get "A"
            st.session_state.user_choice = option_choice.split('.')[0]
            st.session_state.answer_submitted = True
            
            # Update score if correct
            if st.session_state.user_choice == q['answer']:
                st.session_state.score += 1
            
            st.rerun() # Rerun to show the feedback

def show_results():
    """Displays the final quiz results."""
    st.title("Quiz Finished - Your Results")
    st.write("---")
    
    total_questions = len(st.session_state.questions_to_ask)
    score = st.session_state.score
    
    st.subheader(f"Subject: {st.session_state.chosen_subject}")
    st.subheader(f"Your Final Score: **{score} / {total_questions}**")
    
    if total_questions > 0:
        percentage = round((score / total_questions) * 100, 2)
        st.metric(label="Percentage", value=f"{percentage}%")
    
    # Display encouragement
    if percentage >= 80:
        st.balloons()
        st.success("EXCELLENT! You demonstrated a strong grasp of the subject.")
    elif percentage >= 50:
        st.info("GOOD EFFORT. Review the questions you missed for better understanding.")
    else:
        st.warning("KEEP PRACTICING. Focus on understanding the explanations for core concepts.")
        
    st.write("---")
    
    # Button to restart the quiz (go back to menu)
    if st.button("Practice Another Subject"):
        reset_quiz()
        st.rerun()

# --- Main Application ---
def main():
    st.set_page_config(page_title="WAEC Practice Bot", layout="centered")
    
    # Load all questions once
    questions_by_subject = organize_questions(RAW_WAEC_QUESTIONS)
    
    # Initialize state
    initialize_state()
    
    # Simple state machine
    if st.session_state.app_state == "MENU":
        show_menu(questions_by_subject)
    elif st.session_state.app_state == "QUIZ":
        show_quiz_question()
    elif st.session_state.app_state == "RESULTS":
        show_results()

if __name__ == "__main__":
    main()