# ===== IMPORTS AND DEPENDENCIES =====
import os
import json
import re
import numpy as np
from datetime import datetime
from typing import List, Dict, Any, Optional
import PyPDF2
import pytesseract
from PIL import Image
import fitz  # PyMuPDF
import cv2
import requests
from bs4 import BeautifulSoup
import io
import base64
from sentence_transformers import SentenceTransformer
import faiss
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import openai
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# ===== DEEPSEEK INTEGRATION =====
class DeepSeekIntegration:
    def __init__(self):
        self.api_key = os.getenv('DEEPSEEK_API_KEY')
        self.base_url = os.getenv('DEEPSEEK_BASE_URL', 'https://api.deepseek.com/v1')
        self.chat_model = os.getenv('CHAT_MODEL', 'deepseek-chat')
        self.embedding_model = os.getenv('EMBEDDING_MODEL', 'deepseek-embedding-v2')
        
        # Configure OpenAI client for DeepSeek API
        self.client = openai.OpenAI(
            api_key=self.api_key,
            base_url=self.base_url
        )
        
    def generate_chat_response(self, messages: List[Dict], temperature: float = 0.3, max_tokens: int = 2000) -> Dict:
        """Generate response using DeepSeek chat model"""
        try:
            response = self.client.chat.completions.create(
                model=self.chat_model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=False
            )
            
            return {
                'content': response.choices[0].message.content,
                'usage': {
                    'prompt_tokens': response.usage.prompt_tokens,
                    'completion_tokens': response.usage.completion_tokens,
                    'total_tokens': response.usage.total_tokens
                },
                'model': response.model
            }
            
        except Exception as e:
            return {
                'content': f"I apologize, but I encountered an error: {str(e)}",
                'usage': {'prompt_tokens': 0, 'completion_tokens': 0, 'total_tokens': 0},
                'model': self.chat_model,
                'error': True
            }
    
    def generate_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings using DeepSeek embedding model"""
        try:
            response = self.client.embeddings.create(
                model=self.embedding_model,
                input=texts
            )
            
            return [data.embedding for data in response.data]
            
        except Exception as e:
            print(f"Embedding error: {e}")
            # Fallback to local model if embedding fails
            return self._fallback_embeddings(texts)
    
    def _fallback_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Simple fallback embedding generator"""
        import numpy as np
        embeddings = []
        for text in texts:
            # Simple hash-based embedding for fallback
            embedding = [hash(text) % 1000 / 1000.0 for _ in range(384)]
            embeddings.append(embedding)
        return embeddings
    
    def stream_response(self, messages: List[Dict], temperature: float = 0.3) -> Any:
        """Stream response for real-time interaction"""
        try:
            response = self.client.chat.completions.create(
                model=self.chat_model,
                messages=messages,
                temperature=temperature,
                stream=True,
                max_tokens=2000
            )
            return response
        except Exception as e:
            print(f"Streaming error: {e}")
            return None

# ===== DOCUMENT PROCESSING LAYER =====
class DocumentProcessor:
    def __init__(self, chatbot):
        self.chatbot = chatbot
    
    def process_pdf(self, file_path: str, metadata: Dict = None) -> List[Dict]:
        """Process PDF documents with OCR for scanned PDFs"""
        chunks = []
        
        try:
            # Try text extraction first
            doc = fitz.open(file_path)
            full_text = ""
            
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                text = page.get_text()
                
                if text.strip():  # Text-based PDF
                    full_text += f"\nPage {page_num + 1}:\n{text}"
                else:  # Scanned PDF - use OCR
                    pix = page.get_pixmap()
                    img_data = pix.tobytes("png")
                    image = Image.open(io.BytesIO(img_data))
                    text = pytesseract.image_to_string(image)
                    full_text += f"\nPage {page_num + 1} (OCR):\n{text}"
            
            doc.close()
            
            # Extract metadata
            doc_metadata = self.extract_pdf_metadata(file_path)
            if metadata:
                doc_metadata.update(metadata)
            
            # Chunk the text
            chunks = self.chunk_document(full_text, doc_metadata)
            
        except Exception as e:
            print(f"Error processing PDF: {e}")
        
        return chunks
    
    def process_image(self, file_path: str, metadata: Dict = None) -> List[Dict]:
        """Process scanned images using OCR"""
        try:
            image = Image.open(file_path)
            text = pytesseract.image_to_string(image)
            
            doc_metadata = {
                'source_type': 'image',
                'filename': os.path.basename(file_path),
                'processed_date': datetime.now().isoformat()
            }
            if metadata:
                doc_metadata.update(metadata)
            
            return self.chunk_document(text, doc_metadata)
            
        except Exception as e:
            print(f"Error processing image: {e}")
            return []
    
    def process_html(self, file_path: str, metadata: Dict = None) -> List[Dict]:
        """Process HTML documents"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                soup = BeautifulSoup(f.read(), 'html.parser')
                
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
                
            text = soup.get_text()
            lines = (line.strip() for line in text.splitlines())
            text = '\n'.join(line for line in lines if line)
            
            doc_metadata = {
                'source_type': 'html',
                'filename': os.path.basename(file_path)
            }
            if metadata:
                doc_metadata.update(metadata)
            
            return self.chunk_document(text, doc_metadata)
            
        except Exception as e:
            print(f"Error processing HTML: {e}")
            return []
    
    def process_epub(self, file_path: str, metadata: Dict = None) -> List[Dict]:
        """Process EPUB documents"""
        # Simplified EPUB processing - in production, use ebooklib
        try:
            # Placeholder for EPUB processing
            text = f"EPUB content from {file_path}"
            
            doc_metadata = {
                'source_type': 'epub',
                'filename': os.path.basename(file_path)
            }
            if metadata:
                doc_metadata.update(metadata)
            
            return self.chunk_document(text, doc_metadata)
            
        except Exception as e:
            print(f"Error processing EPUB: {e}")
            return []
    
    def process_text(self, file_path: str, metadata: Dict = None) -> List[Dict]:
        """Process plain text documents"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
            
            doc_metadata = {
                'source_type': 'text',
                'filename': os.path.basename(file_path)
            }
            if metadata:
                doc_metadata.update(metadata)
            
            return self.chunk_document(text, doc_metadata)
            
        except Exception as e:
            print(f"Error processing text: {e}")
            return []
    
    def extract_pdf_metadata(self, file_path: str) -> Dict:
        """Extract metadata from PDF files"""
        metadata = {}
        try:
            with open(file_path, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(f)
                doc_info = pdf_reader.metadata
                
                if doc_info:
                    metadata.update({
                        'title': getattr(doc_info, 'title', ''),
                        'author': getattr(doc_info, 'author', ''),
                        'subject': getattr(doc_info, 'subject', ''),
                        'creator': getattr(doc_info, 'creator', '')
                    })
        except:
            pass
        
        metadata.update({
            'filename': os.path.basename(file_path),
            'processed_date': datetime.now().isoformat()
        })
        
        return metadata
    
    def chunk_document(self, text: str, metadata: Dict, chunk_size: int = 512, overlap: int = 50) -> List[Dict]:
        """Split document into meaningful chunks with sliding window"""
        chunks = []
        
        # Clean text
        text = self.clean_text(text)
        
        # Split into paragraphs or sentences
        paragraphs = re.split(r'\n\s*\n', text)
        
        for para in paragraphs:
            if len(para.strip()) < 10:  # Skip very short paragraphs
                continue
                
            # Further split long paragraphs
            sentences = re.split(r'[.!?]+', para)
            current_chunk = ""
            
            for sentence in sentences:
                sentence = sentence.strip()
                if not sentence:
                    continue
                    
                if len(current_chunk) + len(sentence) < chunk_size:
                    current_chunk += sentence + ". "
                else:
                    if current_chunk:
                        chunks.append(self.create_chunk(current_chunk, metadata))
                    current_chunk = sentence + ". "
            
            if current_chunk:
                chunks.append(self.create_chunk(current_chunk, metadata))
        
        return chunks
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize text"""
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        # Remove special characters but keep basic punctuation
        text = re.sub(r'[^\w\s.,!?;:()\-+]', '', text)
        return text.strip()
    
    def create_chunk(self, text: str, metadata: Dict) -> Dict:
        """Create a standardized chunk object"""
        return {
            'id': f"chunk_{len(self.chatbot.vector_db['metadata'])}",
            'text': text,
            'metadata': metadata.copy(),
            'embedding': None,
            'created_at': datetime.now().isoformat()
        }

# ===== INGESTION LAYER =====
class IngestionLayer:
    def __init__(self, chatbot):
        self.chatbot = chatbot
        self.supported_formats = ['.pdf', '.epub', '.html', '.txt', '.jpg', '.jpeg', '.png', '.tiff']
        self.document_processor = DocumentProcessor(chatbot)
    
    def upload_document(self, file_path: str, metadata: Dict = None) -> bool:
        """Accept and process uploaded documents"""
        try:
            file_ext = os.path.splitext(file_path)[1].lower()
            
            if file_ext not in self.supported_formats:
                print(f"Unsupported format: {file_ext}")
                return False
            
            # Process document based on format
            processor_method = getattr(self.document_processor, f'process_{file_ext[1:]}', self.document_processor.process_text)
            chunks = processor_method(file_path, metadata)
            
            if chunks:
                self.chatbot.index_chunks(chunks)
                return True
                
        except Exception as e:
            print(f"Error processing document: {e}")
            return False
        
        return False
    
    def process_teacher_upload(self, file_path: str, curriculum_info: Dict) -> bool:
        """Special processing for teacher uploads with curriculum tagging"""
        metadata = {
            'upload_type': 'teacher',
            'curriculum': curriculum_info.get('curriculum', 'general'),
            'grade_level': curriculum_info.get('grade_level', 'unknown'),
            'subject': curriculum_info.get('subject', 'science'),
            'topic': curriculum_info.get('topic', 'general'),
            'upload_date': datetime.now().isoformat(),
            'teacher_id': curriculum_info.get('teacher_id', 'anonymous')
        }
        
        return self.upload_document(file_path, metadata)

# ===== INDEXING AND RETRIEVAL LAYER =====
class RetrievalLayer:
    def __init__(self, chatbot):
        self.chatbot = chatbot
    
    def index_chunks(self, chunks: List[Dict]):
        """Index chunks in vector database"""
        texts = [chunk['text'] for chunk in chunks]
        
        # Create embeddings using DeepSeek
        embeddings = self.chatbot.deepseek.generate_embeddings(texts)
        
        # Add to vector DB
        for i, (chunk, embedding) in enumerate(zip(chunks, embeddings)):
            chunk['embedding'] = embedding
            self.chatbot.vector_db['index'].add(np.array([embedding]))
            self.chatbot.vector_db['metadata'].append(chunk)
        
        # Update TF-IDF
        self.update_tfidf()
        
        # Save to disk
        self.chatbot.save_vector_db()
    
    def update_tfidf(self):
        """Update TF-IDF matrix for hybrid search"""
        texts = [chunk['text'] for chunk in self.chatbot.vector_db['metadata']]
        if texts:
            self.tfidf_matrix = self.chatbot.tfidf_vectorizer.fit_transform(texts)
            self.documents = texts
    
    def retrieve(self, query: str, top_k: int = 5, use_reranking: bool = True) -> List[Dict]:
        """Retrieve relevant chunks using hybrid search"""
        # Vector similarity search
        query_embedding = self.chatbot.deepseek.generate_embeddings([query])[0]
        D, I = self.chatbot.vector_db['index'].search(np.array([query_embedding]), top_k * 2)
        
        vector_results = []
        for score, idx in zip(D[0], I[0]):
            if idx < len(self.chatbot.vector_db['metadata']):
                vector_results.append({
                    'chunk': self.chatbot.vector_db['metadata'][idx],
                    'score': score,
                    'type': 'vector'
                })
        
        # TF-IDF search (if available)
        tfidf_results = []
        if self.tfidf_matrix is not None and self.documents:
            query_vec = self.chatbot.tfidf_vectorizer.transform([query])
            similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
            top_tfidf_indices = similarities.argsort()[-top_k:][::-1]
            
            for idx in top_tfidf_indices:
                if idx < len(self.chatbot.vector_db['metadata']):
                    tfidf_results.append({
                        'chunk': self.chatbot.vector_db['metadata'][idx],
                        'score': similarities[idx],
                        'type': 'tfidf'
                    })
        
        # Combine and rerank
        all_results = vector_results + tfidf_results
        if use_reranking:
            return self.rerank_results(query, all_results, top_k)
        else:
            return sorted(all_results, key=lambda x: x['score'], reverse=True)[:top_k]
    
    def rerank_results(self, query: str, results: List[Dict], top_k: int) -> List[Dict]:
        """Rerank results using cross-encoder or heuristic methods"""
        scored_results = []
        for result in results:
            score = result['score']
            
            # Adjust score based on chunk quality
            chunk_text = result['chunk']['text']
            chunk_length = len(chunk_text.split())
            
            # Prefer chunks of reasonable length
            if 20 <= chunk_length <= 200:
                length_score = 1.0
            else:
                length_score = 0.7
            
            # Boost score for teacher-uploaded content
            source_boost = 1.2 if result['chunk']['metadata'].get('upload_type') == 'teacher' else 1.0
            
            final_score = score * length_score * source_boost
            scored_results.append((final_score, result))
        
        # Return top-k results
        scored_results.sort(key=lambda x: x[0], reverse=True)
        return [result for score, result in scored_results[:top_k]]

# ===== GENERATION LAYER WITH DEEPSEEK =====
class GenerationLayer:
    def __init__(self, chatbot):
        self.chatbot = chatbot
        self.deepseek = DeepSeekIntegration()
        self.step_templates = {
            'problem_solving': """
            You are an expert science tutor. Solve this problem step by step with clear explanations.

            PROBLEM: {question}

            RELEVANT CONTEXT:
            {context}

            INSTRUCTIONS:
            1. Analyze the problem carefully
            2. Explain which scientific principles apply
            3. Show calculations step by step
            4. Verify your answer
            5. Provide the final answer clearly

            Remember to be educational and clear.
            """,
            
            'concept_explanation': """
            You are a science educator. Explain this concept comprehensively.

            CONCEPT: {question}

            RELEVANT CONTEXT:
            {context}

            STRUCTURE YOUR EXPLANATION:
            1. Clear definition and key principles
            2. Real-world examples and applications  
            3. Related formulas and laws
            4. Common misconceptions to avoid
            5. Practical significance

            Make it engaging and easy to understand.
            """,
            
            'quiz_question': """
            Create an educational quiz question about this topic.

            TOPIC: {question}

            RELEVANT CONTEXT:
            {context}

            FORMAT REQUIREMENTS:
            Question: [Clear, challenging question]
            Options: 
            A) [Plausible distractor]
            B) [Correct answer]
            C) [Plausible distractor] 
            D) [Plausible distractor]
            Answer: B) [Exact answer text]
            Explanation: [Brief educational explanation]

            Make it thought-provoking but fair.
            """
        }
    
    def generate_response(self, query: str, context_chunks: List[Dict], response_type: str = 'problem_solving', show_steps: bool = True) -> Dict:
        """Generate response using DeepSeek with retrieved context"""
        try:
            # Prepare context
            context_text = self.prepare_context(context_chunks)
            
            # Select and format prompt
            if response_type == 'quick_answer' or not show_steps:
                prompt = f"Answer concisely: {query}\n\nRelevant information:\n{context_text}"
            else:
                template = self.step_templates.get(response_type, self.step_templates['problem_solving'])
                prompt = template.format(question=query, context=context_text)
            
            # Create messages for DeepSeek
            messages = [
                {
                    "role": "system", 
                    "content": "You are an expert science tutor and educator. Provide accurate, educational, and clear explanations. Always cite relevant scientific principles and verify your reasoning."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ]
            
            # Call DeepSeek API
            deepseek_response = self.deepseek.generate_chat_response(messages)
            response_content = deepseek_response['content']
            
            # Post-process response
            processed_response = self.post_process_response(response_content, context_chunks, query, deepseek_response)
            
            return processed_response
            
        except Exception as e:
            return {
                'answer': f"I apologize, but I encountered an error while processing your question: {str(e)}",
                'steps': [],
                'sources': [],
                'confidence': 0.0,
                'safety_checked': False,
                'model_info': {'model': 'error', 'tokens': 0}
            }
    
    def prepare_context(self, context_chunks: List[Dict]) -> str:
        """Prepare context from retrieved chunks with source attribution"""
        if not context_chunks:
            return "No specific context available. Use your general science knowledge."
        
        context_parts = ["RELEVANT SOURCES:"]
        for i, result in enumerate(context_chunks):
            chunk = result['chunk']
            source_info = f"Source: {chunk['metadata'].get('filename', 'Unknown')}"
            if 'page' in chunk['metadata']:
                source_info += f" (Page {chunk['metadata']['page']})"
            if 'title' in chunk['metadata']:
                source_info += f" - {chunk['metadata']['title']}"
            
            context_parts.append(f"[Source {i+1}] {source_info}")
            context_parts.append(f"Content: {chunk['text']}\n")
        
        return "\n".join(context_parts)
    
    def post_process_response(self, response: str, context_chunks: List[Dict], original_query: str, deepseek_response: Dict) -> Dict:
        """Post-process and validate the DeepSeek response"""
        # Extract steps if they exist
        steps = self.extract_steps(response)
        
        # Verify numerical calculations
        verified = self.verify_numerical_calculations(response, context_chunks)
        
        # Extract sources
        sources = [chunk['chunk']['metadata'] for chunk in context_chunks]
        
        # Check for hallucinations
        hallucination_score = self.detect_hallucinations(response, context_chunks)
        
        # Model information
        model_info = {
            'model': deepseek_response.get('model', 'deepseek-chat'),
            'tokens': deepseek_response.get('usage', {}).get('total_tokens', 0),
            'has_error': deepseek_response.get('error', False)
        }
        
        return {
            'answer': response,
            'steps': steps,
            'sources': sources,
            'confidence': min(verified['confidence'], 1.0 - hallucination_score),
            'safety_checked': verified['is_correct'],
            'numerical_verification': verified,
            'hallucination_score': hallucination_score,
            'model_info': model_info
        }
    
    def extract_steps(self, response: str) -> List[str]:
        """Extract step-by-step instructions from response"""
        steps = []
        # Look for numbered steps
        step_patterns = [
            r'\d+\.\s*(.*?)(?=\n\d+\.|\n\n|$)',
            r'Step\s*\d+:\s*(.*?)(?=\nStep\s*\d+:|$)',
            r'[•\-]\s*(.*?)(?=\n[•\-]|\n\n|$)' 
        ]
        
        for pattern in step_patterns:
            matches = re.findall(pattern, response, re.DOTALL)
            if matches:
                steps.extend([match.strip() for match in matches if len(match.strip()) > 10])
                if steps:  # If we found meaningful steps, use them
                    break
        
        # If no clear steps found, split by paragraphs for longer explanations
        if not steps and len(response) > 200:
            paragraphs = [p.strip() for p in response.split('\n\n') if p.strip()]
            steps = paragraphs[:5]  # Limit to first 5 paragraphs
        
        return steps if steps else [response]
    
    def verify_numerical_calculations(self, response: str, context_chunks: List[Dict]) -> Dict:
        """Verify numerical calculations in the response"""
        # Extract calculations and results
        calculations = re.findall(r'[\d\.]+\s*[\+\-\*\/]\s*[\d\.]+\s*=\s*[\d\.]+', response)
        results = re.findall(r'[Ff]inal [Aa]nswer:\s*([\d\.]+)', response)
        
        verification_results = []
        for calc in calculations:
            try:
                # Extract the calculation part (before =)
                calc_part = calc.split('=')[0].strip()
                expected_result = eval(calc_part)
                actual_result = float(calc.split('=')[1].strip())
                
                verification_results.append({
                    'calculation': calc,
                    'expected': expected_result,
                    'actual': actual_result,
                    'verified': abs(expected_result - actual_result) < 0.001
                })
            except:
                verification_results.append({
                    'calculation': calc,
                    'expected': None,
                    'actual': None,
                    'verified': False
                })
        
        # Simple verification logic
        is_correct = all(result['verified'] for result in verification_results) if verification_results else True
        confidence = 0.9 if is_correct else 0.6
        
        return {
            'is_correct': is_correct,
            'confidence': confidence,
            'calculations_checked': verification_results
        }
    
    def detect_hallucinations(self, response: str, context_chunks: List[Dict]) -> float:
        """Detect potential hallucinations in the response"""
        if not context_chunks:
            return 0.0  # No context, can't detect hallucinations
        
        # Extract key scientific terms from response
        science_terms = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', response)
        context_text = " ".join([chunk['chunk']['text'] for chunk in context_chunks])
        
        # Check if key terms appear in context
        unique_terms = []
        for term in science_terms:
            if len(term) > 3 and term.lower() not in ['the', 'this', 'that', 'with', 'from']:
                if term not in context_text:
                    unique_terms.append(term)
        
        hallucination_score = len(unique_terms) / max(len(science_terms), 1)
        return min(hallucination_score, 1.0)

# ===== MAIN SCIENCE CHATBOT CLASS =====
class ScienceChatbot:
    def __init__(self, config_path: str = "config.json"):
        self.config = self.load_config(config_path)
        self.deepseek = DeepSeekIntegration()
        self.setup_components()
        self.user_sessions = {}
        self.teacher_mode = False
        
    def load_config(self, config_path: str) -> Dict:
        """Load configuration from JSON file"""
        default_config = {
            "vector_db_path": "data/vector_db",
            "documents_path": "data/documents", 
            "chunk_size": 512,
            "chunk_overlap": 50,
            "top_k_retrieval": 5,
            "rerank_top_k": 3,
            "embedding_model": "deepseek-embedding-v2",
            "llm_model": "deepseek-chat",
            "safety_threshold": 0.8,
            "max_steps_per_problem": 10,
            "deepseek_api_key": os.getenv('DEEPSEEK_API_KEY'),
            "deepseek_base_url": os.getenv('DEEPSEEK_BASE_URL')
        }
        
        try:
            with open(config_path, 'r') as f:
                user_config = json.load(f)
                default_config.update(user_config)
        except FileNotFoundError:
            print(f"Config file not found, using defaults")
            
        return default_config
    
    def setup_components(self):
        """Initialize all system components with DeepSeek"""
        # Use DeepSeek for embeddings
        self.embedding_model = self.deepseek
        
        # Vector database
        self.vector_db = self.setup_vector_db()
        
        # TF-IDF for hybrid search
        self.tfidf_vectorizer = TfidfVectorizer()
        self.tfidf_matrix = None
        self.documents = []
        
        # Document processors
        self.document_processors = {
            'pdf': self.process_pdf,
            'epub': self.process_epub, 
            'html': self.process_html,
            'image': self.process_image,
            'txt': self.process_text
        }
        
        # Initialize layers
        self.ingestion_layer = IngestionLayer(self)
        self.retrieval_layer = RetrievalLayer(self)
        self.generation_layer = GenerationLayer(self)
        
        print("✅ DeepSeek AI integration initialized")
    
    def setup_vector_db(self):
        """Initialize or load FAISS vector database"""
        index_path = os.path.join(self.config["vector_db_path"], "faiss.index")
        metadata_path = os.path.join(self.config["vector_db_path"], "metadata.json")
        
        if os.path.exists(index_path):
            index = faiss.read_index(index_path)
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
        else:
            # Create new index
            dimension = 384  # Default dimension for fallback
            index = faiss.IndexFlatIP(dimension)
            metadata = []
            
        return {"index": index, "metadata": metadata}
    
    def save_vector_db(self):
        """Save vector database to disk"""
        os.makedirs(self.config["vector_db_path"], exist_ok=True)
        index_path = os.path.join(self.config["vector_db_path"], "faiss.index")
        metadata_path = os.path.join(self.config["vector_db_path"], "metadata.json")
        
        faiss.write_index(self.vector_db["index"], index_path)
        with open(metadata_path, 'w') as f:
            json.dump(self.vector_db["metadata"], f, indent=2)
    
    def index_chunks(self, chunks: List[Dict]):
        """Delegate to retrieval layer"""
        self.retrieval_layer.index_chunks(chunks)
    
    # Delegate document processing methods
    def process_pdf(self, file_path: str, metadata: Dict = None) -> List[Dict]:
        return DocumentProcessor(self).process_pdf(file_path, metadata)
    
    def process_image(self, file_path: str, metadata: Dict = None) -> List[Dict]:
        return DocumentProcessor(self).process_image(file_path, metadata)
    
    def process_html(self, file_path: str, metadata: Dict = None) -> List[Dict]:
        return DocumentProcessor(self).process_html(file_path, metadata)
    
    def process_epub(self, file_path: str, metadata: Dict = None) -> List[Dict]:
        return DocumentProcessor(self).process_epub(file_path, metadata)
    
    def process_text(self, file_path: str, metadata: Dict = None) -> List[Dict]:
        return DocumentProcessor(self).process_text(file_path, metadata)

# ===== UI/UX LAYER =====
class ScienceChatbotUI:
    def __init__(self, chatbot):
        self.chatbot = chatbot
        self.current_session = None
        self.teacher_mode = False
        
    def start_session(self, user_id: str = "default"):
        """Start a new user session"""
        self.current_session = {
            'user_id': user_id,
            'start_time': datetime.now(),
            'conversation_history': [],
            'quiz_mode': False,
            'show_steps': True,
            'challenge_level': 'medium'
        }
        self.chatbot.user_sessions[user_id] = self.current_session
        
        print("🔬 Welcome to the DeepSeek Science Chatbot!")
        print("Features:")
        print("- Upload PDFs, images, textbooks")
        print("- Step-by-step problem solving") 
        print("- Interactive quizzes")
        print("- Teacher/admin mode")
        print("- DeepSeek AI powered responses")
        print("\nType 'help' for commands or ask a science question!")
    
    def process_command(self, user_input: str):
        """Process user input and return response"""
        if not self.current_session:
            self.start_session()
        
        # Handle special commands
        if user_input.lower() in ['help', '?']:
            return self.show_help()
        elif user_input.lower().startswith('upload '):
            return self.handle_upload(user_input[7:])
        elif user_input.lower() == 'teacher mode':
            return self.toggle_teacher_mode()
        elif user_input.lower() == 'quiz mode':
            return self.toggle_quiz_mode()
        elif user_input.lower() == 'show steps':
            return self.toggle_show_steps()
        elif user_input.lower() == 'sources':
            return self.show_recent_sources()
        elif user_input.lower() == 'history':
            return self.show_history()
        
        # Process as a question
        return self.answer_question(user_input)
    
    def answer_question(self, question: str) -> Dict:
        """Answer a science question using the full pipeline"""
        # Retrieve relevant context
        context_chunks = self.chatbot.retrieval_layer.retrieve(
            question, 
            top_k=self.chatbot.config["top_k_retrieval"],
            use_reranking=True
        )
        
        # Determine response type
        if self.current_session['quiz_mode']:
            response_type = 'quiz_question'
        elif any(word in question.lower() for word in ['calculate', 'solve', 'find', 'compute']):
            response_type = 'problem_solving'
        else:
            response_type = 'concept_explanation'
        
        # Generate response
        response = self.chatbot.generation_layer.generate_response(
            question,
            context_chunks,
            response_type,
            self.current_session['show_steps']
        )
        
        # Update session history
        self.current_session['conversation_history'].append({
            'question': question,
            'response': response,
            'timestamp': datetime.now()
        })
        
        return response
    
    def show_help(self) -> Dict:
        """Show help information"""
        help_text = """
🤖 DEEPSEEK SCIENCE CHATBOT COMMANDS:

📚 BASIC USAGE:
- Ask any science question
- "calculate [problem]" - Get step-by-step solutions
- "explain [concept]" - Detailed explanations

🎯 SPECIAL MODES:
- "teacher mode" - Enable teacher features
- "quiz mode" - Generate quiz questions  
- "show steps" - Toggle step-by-step solutions

📁 DOCUMENT MANAGEMENT:
- "upload [filepath]" - Add PDFs, images, textbooks
- "sources" - Show recent sources used
- "history" - View conversation history

🔧 ADMIN:
- "stats" - System statistics
- "help" - Show this message

Example questions:
- "Explain quantum entanglement"
- "Calculate the force needed to lift 50kg"
- "What is photosynthesis?"
        """
        
        return {
            'answer': help_text,
            'steps': [],
            'sources': [],
            'confidence': 1.0,
            'safety_checked': True,
            'model_info': {'model': 'help', 'tokens': 0}
        }
    
    def handle_upload(self, file_path: str) -> Dict:
        """Handle document uploads"""
        if self.teacher_mode:
            curriculum_info = {
                'curriculum': 'custom',
                'grade_level': 'high_school',
                'subject': 'science',
                'teacher_id': self.current_session['user_id']
            }
            success = self.chatbot.ingestion_layer.process_teacher_upload(file_path, curriculum_info)
        else:
            success = self.chatbot.ingestion_layer.upload_document(file_path)
        
        if success:
            return {
                'answer': f"✅ Successfully uploaded and processed: {file_path}",
                'steps': [],
                'sources': [],
                'confidence': 1.0,
                'safety_checked': True,
                'model_info': {'model': 'upload', 'tokens': 0}
            }
        else:
            return {
                'answer': f"❌ Failed to process: {file_path}",
                'steps': [],
                'sources': [],
                'confidence': 0.0,
                'safety_checked': True,
                'model_info': {'model': 'upload', 'tokens': 0}
            }
    
    def toggle_teacher_mode(self) -> Dict:
        """Toggle teacher mode"""
        self.teacher_mode = not self.teacher_mode
        status = "enabled" if self.teacher_mode else "disabled"
        
        return {
            'answer': f"👨‍🏫 Teacher mode {status}",
            'steps': [],
            'sources': [],
            'confidence': 1.0,
            'safety_checked': True,
            'model_info': {'model': 'system', 'tokens': 0}
        }
    
    def toggle_quiz_mode(self) -> Dict:
        """Toggle quiz mode"""
        self.current_session['quiz_mode'] = not self.current_session['